-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.1.41-3ubuntu12.6


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema todo
--

CREATE DATABASE IF NOT EXISTS todo;
USE todo;

--
-- Definition of table `todo`.`roles`
--

DROP TABLE IF EXISTS `todo`.`roles`;
CREATE TABLE  `todo`.`roles` (
  `login` varchar(30) NOT NULL,
  `rol` varchar(30) NOT NULL,
  PRIMARY KEY (`login`,`rol`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `todo`.`roles`
--

/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
LOCK TABLES `roles` WRITE;
INSERT INTO `todo`.`roles` VALUES  ('espe','registrado'),
 ('struts','pro'),
 ('struts','registrado');
UNLOCK TABLES;
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;


--
-- Definition of table `todo`.`tareas`
--

DROP TABLE IF EXISTS `todo`.`tareas`;
CREATE TABLE  `todo`.`tareas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(100) NOT NULL,
  `prioridad` varchar(20) NOT NULL,
  `vencimiento` date NOT NULL,
  `login` varchar(30) NOT NULL,
  `comentario` text,
  `aviso` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tarea_esde_usuario` (`login`) USING BTREE,
  CONSTRAINT `tarea_esde_usuario` FOREIGN KEY (`login`) REFERENCES `usuarios` (`login`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `todo`.`tareas`
--

/*!40000 ALTER TABLE `tareas` DISABLE KEYS */;
LOCK TABLES `tareas` WRITE;
INSERT INTO `todo`.`tareas` VALUES  (1,'Aprender Struts','Maxima','2010-12-15','struts','aprender acciones, ActionForms, validacion de datos y pruebas..uff...mucha cosa es',10),
 (2,'Devolverle el cortacespedes al vecino','Baja','2010-12-19','struts','si no me lo pide quizas no me acuerde',3),
 (3,'Entregar papeles en hacienda','Alta','2010-12-21','struts','hablar con el asesor',2),
 (4,'Terminar los ejercicios de Struts','Maxima','2010-12-21','espe','son muy dificiles!!',3);
UNLOCK TABLES;
/*!40000 ALTER TABLE `tareas` ENABLE KEYS */;


--
-- Definition of table `todo`.`usuarios`
--

DROP TABLE IF EXISTS `todo`.`usuarios`;
CREATE TABLE  `todo`.`usuarios` (
  `login` varchar(30) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `todo`.`usuarios`
--

/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
LOCK TABLES `usuarios` WRITE;
INSERT INTO `todo`.`usuarios` VALUES  ('espe','espe'),
 ('struts','mola');
UNLOCK TABLES;
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
