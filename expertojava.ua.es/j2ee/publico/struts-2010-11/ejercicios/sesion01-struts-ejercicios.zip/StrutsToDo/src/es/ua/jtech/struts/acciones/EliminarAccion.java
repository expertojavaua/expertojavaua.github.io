package es.ua.jtech.struts.acciones;

import javax.servlet.http.*;
import org.apache.struts.action.*;
import es.ua.jtech.struts.dao.*;
import es.ua.jtech.struts.domain.*;

public class EliminarAccion extends Action {
	   public ActionForward execute(
	            ActionMapping mapping,
	            ActionForm form,
	            HttpServletRequest request,
	            HttpServletResponse response)
	            throws Exception {
		   
		   //Obtener el usuario actual
		   Usuario u = (Usuario)request.getSession().getAttribute("usuario");
		   //¿Se ha pulsado cancelar?
		   if (isCancelled(request)) {
			   return mapping.findForward("OK");
			   
		   }		   
		   //Eliminar la tarea
		   TareaDAO miDao = TareaDAO.getInstance();
		   try {
			   miDao.eliminar(Integer.parseInt(request.getParameter("id")), u.getLogin());
		   }
		   catch(DAOException de) {
			   return mapping.findForward("error");
		   }
		   
		   return mapping.findForward("OK");
	   }
}
