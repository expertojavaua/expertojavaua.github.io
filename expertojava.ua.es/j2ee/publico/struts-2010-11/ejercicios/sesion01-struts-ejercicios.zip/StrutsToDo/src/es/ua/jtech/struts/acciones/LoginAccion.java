package es.ua.jtech.struts.acciones;

import javax.servlet.http.*;
import org.apache.struts.action.*;
import es.ua.jtech.struts.dao.*;
import es.ua.jtech.struts.domain.Usuario;

public class LoginAccion extends Action {
	   public ActionForward execute(
	            ActionMapping mapping,
	            ActionForm form,
	            HttpServletRequest request,
	            HttpServletResponse response)
	            throws Exception {
		   
		   String result;
		   
		   if (request.isUserInRole("registrado")) {
			   UsuarioDAO dao = UsuarioDAO.getInstance();
			   Usuario u = dao.getUsuario(request.getUserPrincipal().getName());
			   request.getSession().setAttribute("usuario", u);
			   result = "OK";
		   }
		   else 
			   result = "error";
		   return mapping.findForward(result);				   
	   }
}
