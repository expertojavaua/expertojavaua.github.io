package es.ua.jtech.struts.dao;

public class DAOException extends Exception {
	
	private static final long serialVersionUID = -2929331353444305594L;

	DAOException(String mensaje, Exception e) {
		super(mensaje, e);
	}
}
