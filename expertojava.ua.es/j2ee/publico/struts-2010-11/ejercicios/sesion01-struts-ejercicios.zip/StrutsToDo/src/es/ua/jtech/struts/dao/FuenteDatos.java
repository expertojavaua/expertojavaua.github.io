package es.ua.jtech.struts.dao;

import java.sql.*;
import javax.sql.*;
import javax.naming.*;

/**
 * Sirve para obtener conexiones de la base de datos, usando un pool para hacerlo
 * eficiente
 * @author otto
 *
 */
public class FuenteDatos {
	private static DataSource ds = null;
	
	/**
	 * Obtiene una conexi�n de la base de datos
	 * @return la conexi�n
	 * @throws NamingException si hay alg�n problema con la configuraci�n.
	 * @throws SQLException si hay alg�n problema con la base de datos en s�.
	 */
	public static Connection getConnection() throws NamingException, SQLException {
	   if (ds==null) {
		   Context contextoInicial =new InitialContext();
		   Context contextoEntorno = (Context) contextoInicial.lookup("java:comp/env");
		   ds = (DataSource) contextoEntorno.lookup("jdbc/ToDo");
	   }
	   return ds.getConnection();
	}

}