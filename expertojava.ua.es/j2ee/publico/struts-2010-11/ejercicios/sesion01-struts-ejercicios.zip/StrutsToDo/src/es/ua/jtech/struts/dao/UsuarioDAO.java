package es.ua.jtech.struts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import es.ua.jtech.struts.domain.Usuario;

public class UsuarioDAO {
	private static UsuarioDAO singleton = null;
	private static final String SQL_LOGIN ="select * from usuarios where login=? and password=?";
	private static final String SQL_GETUSER ="select * from usuarios where login=?";
	
	
	private UsuarioDAO() {
	}
	
	public static UsuarioDAO getInstance() {
		if (singleton == null)
			singleton = new UsuarioDAO();
		return singleton;
	}
	
	public Usuario login(String login, String password) throws DAOException {
		Connection con = null;
		PreparedStatement ps;
		ResultSet rs;
		
		try {
			con = FuenteDatos.getConnection();
			ps = con.prepareStatement(SQL_LOGIN);
			ps.setString(1, login);
			ps.setString(2, password);
			rs = ps.executeQuery();
			if (rs.next()) {
				return crearDesdeRegistro(rs);
			}
			else
				return null;
		}
		catch (Exception e) {
			System.out.println(e);
			throw new DAOException("error con la b.d.", e);
		}
		finally {
			try {
				if (con!=null)
					con.close();
			}
			catch(SQLException sqle) {
				throw new DAOException("error al cerrar la conexión", sqle);
			}
		}
	}

	public Usuario getUsuario(String login) throws DAOException {
		Connection con = null;
		PreparedStatement ps;
		ResultSet rs;
		
		try {
			con = FuenteDatos.getConnection();
			ps = con.prepareStatement(SQL_GETUSER);
			ps.setString(1, login);
			rs = ps.executeQuery();
			if (rs.next()) {
				return crearDesdeRegistro(rs);
			}
			else
				return null;
		}
		catch (Exception e) {
			System.out.println(e);
			throw new DAOException("error con la b.d.", e);
		}
		finally {
			try {
				if (con!=null)
					con.close();
			}
			catch(SQLException sqle) {
				throw new DAOException("error al cerrar la conexión", sqle);
			}
		}
	}

	
	
	private Usuario crearDesdeRegistro(ResultSet rs) throws SQLException {
		Usuario u;

		u = new Usuario();
		u.setLogin(rs.getString("login"));
		u.setPassword(rs.getString("password"));

		return u;
	}

}
