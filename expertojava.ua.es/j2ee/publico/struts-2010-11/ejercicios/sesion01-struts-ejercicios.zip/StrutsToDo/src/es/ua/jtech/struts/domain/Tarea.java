package es.ua.jtech.struts.domain;

import java.util.Date;

/**
 * Contiene toda la informaci�n sobre una tarea pendiente (ToDO)
 * implementa el interfaz comparable �nicamente para que se puedan sacar listados
 * ordenados. Esto en una implementaci�n real posiblemente no se har�a as�, las tareas
 * se sacar�an de la base de datos ya ordenadas.
 * @author otto
 */
public class Tarea {
	public enum Prioridad {Maxima, Alta, Media, Baja}
	
	/**
	 * Identificador �nico para la tarea
	 */
	int id;
	
	/**
	 * descripci�n de la tarea (1 l�nea m�ximo)
	 */
	private String descripcion;
	/**
	 * Prioridad
	 */
	private Prioridad prioridad;
	/**
	 * Fecha l�mite para realizar la tarea
	 */
	private Date vencimiento;
	
	/**
	 * Comentario adicional
	 */
	private String comentario;

	/**
	 * Sonar� una alarma cuando falten estos d�as para que se venza la tarea
	 */
	private int aviso;
	
	
	public Tarea() {
		
	}
	
	public Tarea(int id, String descripcion, Prioridad prioridad, Date vencimiento, int aviso) {
		this.id = id;
		this.descripcion = descripcion;
		this.prioridad = prioridad;
		this.vencimiento = vencimiento;
		this.aviso = aviso;
	}
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}
	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	/**
	 * @return the prioridad
	 */
	public Prioridad getPrioridad() {
		return prioridad;
	}
	/**
	 * @param prioridad the prioridad to set
	 */
	public void setPrioridad(Prioridad prioridad) {
		this.prioridad = prioridad;
	}
	/**
	 * @return the vencimiento
	 */
	public Date getVencimiento() {
		return vencimiento;
	}
	/**
	 * @param vencimiento the vencimiento to set
	 */
	public void setVencimiento(Date vencimiento) {
		this.vencimiento = vencimiento;
	}

	/**
	 * @return the comentario
	 */
	public String getComentario() {
		return comentario;
	}

	/**
	 * @param comentario the comentario to set
	 */
	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

	public int getAviso() {
		return aviso;
	}

	public void setAviso(int aviso) {
		this.aviso = aviso;
	}
	
	
	

}
