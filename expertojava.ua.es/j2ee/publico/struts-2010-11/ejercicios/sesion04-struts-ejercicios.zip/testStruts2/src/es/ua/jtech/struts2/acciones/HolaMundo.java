package es.ua.jtech.struts2.acciones;

public class HolaMundo {
	private static String mensaje = "Hola, soy una accion de Struts 2";
	
	public String execute() throws Exception {
		return "success";
	}

	public String getMensaje() {
		return mensaje;
	}
	
}
