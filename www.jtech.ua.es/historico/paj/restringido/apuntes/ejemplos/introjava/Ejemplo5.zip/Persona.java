
/**
  * Ejemplo de herencias y clases abstractas
  */
public abstract class Persona
{	  
	/**
	  * Devuelve la clase a la que pertenecen las personas
	  */
	public String clase() 
	{ 
		return "mamiferos"; 
	} 

	/**
	  * Devuelve el genero de la persona
	  */
	public abstract String genero();

	/**
	  * Devuelve la edad de la persona
	  */
	public abstract String edad();
}
