import java.io.*;

public class Ej1 {

	public static void leeFichero(String filename) {
		int c;

		// Flujo de datos de entrada. Establecer el tipo de flujo adecuado.

		???????????? in = null;

		try {
			in = /* Insertar aqui la creaci�n del flujo de datos */;

			// Lee el fichero caracter a caracter

			while( (c=in.read()) != -1 ) {
				System.out.print((char)c);
			}

			in.close();

		} catch(IOException e) { 
			System.err.println("Error en la E/S");
		}
	}

	public static void main(String [] args) {

		if(args.length!=1) {
			System.out.println("Uso: java Ej1 nombre_fichero");
			System.exit(1);
		}

		leeFichero(args[0]);
	}
}
