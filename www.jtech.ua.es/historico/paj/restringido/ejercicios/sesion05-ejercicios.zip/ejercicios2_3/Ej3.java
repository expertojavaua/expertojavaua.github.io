
import es.*;

public class Ej3 {

	EntradaConsola in;

	public Ej3() {

		in = new EntradaConsola();

		leeEntrada();
	}

	public void leeEntrada() {

		String texto = null;

		while( (texto = in.readLine()) != null) {
			System.out.println("Ha escrito \"" + texto + "\"");
		}

	}

	public static void main(String [] args) {

		Ej3 prueba = new Ej3();

		prueba.leeEntrada();

	}
}