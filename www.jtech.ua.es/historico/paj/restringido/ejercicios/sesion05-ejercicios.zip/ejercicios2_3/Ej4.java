
import usuarios.*;
import es.*;

public class Ej4 {

	EntradaConsola in;

	AccesoUsuarios usuarios;

	public Ej4(String filename) {

		in = new EntradaConsola();

		usuarios = new AccesoFicheroUsuarios(filename);

		menu();

	}

	private void menu() {

		String texto = "Elija una opcion:\n" + 
				"\t1. Entrar al chat\n" +
				"\t2. Registrar nuevo usuario\n" +
				"\t0. Salir\n";
		String resp;

		resp = in.promptLine(texto);

		if(resp.trim().equals("1")) {
			entrar();
		} else if(resp.trim().equals("2")) {
			registrar();
		} else if(resp.trim().equals("0")) {
			System.exit(0);
		} else {
			menu();
		}

	}

	private void entrar() {

		String login = in.promptLine("Login: ");
		String password = in.promptLine("Password: ");

		if(usuarios.valida(login, password)) {
			System.out.println("Entrando ...");
			System.exit(0);
		} else {
			System.out.println("Login y password incorrectos");
			menu();
		}
	}

	private void registrar() {

		String login = in.promptLine("Login: ");
		String password = in.promptLine("Password: ");

		try {
			usuarios.registra(login, password);
		} catch(LoginInvalidoException e) {
			System.out.println(e.getMessage());
		}

		menu();
	}

	public static void main(String [] args) {

		if(args.length!=1) {
			System.err.println("Uso: java Ej4 <fichero_usuarios>");
			System.exit(1);
		}

		new Ej4(args[0]);

	}
}