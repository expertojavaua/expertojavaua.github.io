package es;

import java.io.*;

public class EntradaConsola 
{

	BufferedReader in;

	public EntradaConsola() {
		in = new BufferedReader( /* Crear a partir de la entrada estandar */ );
	}

	// -----------------------------------------------------------------------------
	//  Pide datos al usuario (muestra un mensaje y lee una linea de la entrada)
	// -----------------------------------------------------------------------------

	public String promptLine(String message) {
		System.out.print(message);
		return readLine();
	}

	// -----------------------------------------------------------------------------
	//  Lee una linea de la entrada
	// -----------------------------------------------------------------------------

	public String readLine() {

		/* Capturar excepcion necesaria */

			return /* Lectura de una l�nea */ null;

		/* Capturar excepcion necesaria */
	}
}