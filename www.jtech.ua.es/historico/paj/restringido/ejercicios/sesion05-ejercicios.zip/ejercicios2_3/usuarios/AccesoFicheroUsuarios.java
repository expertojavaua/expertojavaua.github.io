package usuarios;

import java.io.*;
import java.util.*;

/**
  * La clase <code>AccesoFicheroUsuarios</code> se encargar� de acceder al fichero con los
  * datos de los usuarios.
  */
public class AccesoFicheroUsuarios implements AccesoUsuarios 
{
	// Caracter que se utiliza para separar los datos en el fichero
	private final static char SEPARADOR = ':';

	// Nombre del fichero de datos de usuarios
	String filename;

	// Lista de usuarios registrados
	Vector listaUsuarios;

	/**
	  * Crea un objeto <code>AccesoFicheroUsuarios</code> que se encargar� de acceder
          * al fichero filename con los datos de los usuarios.
	  * @param filename Nombre del fichero con los datos de los usuarios
	  */
	public AccesoFicheroUsuarios(String filename) 
	{
		this.filename = filename;

		listaUsuarios = leeFichero(filename);
	}

	/**
	  * Comprueba si el login y el password son validos (est�n registrados en el Vector)
	  * @param login Login del usuario a validar
	  * @param password Password a validar
	  * @return true si el login y password son correctos, o false en otro caso.
	  */
	public boolean valida(String login, String password) 
	{
		Usuario aux = busca(login.trim());

		if(aux != null) 
		{
			if( aux.password.equals(password.trim()) ) 
			{
				return true;
			}
		}

		return false;
	}

	/**
	  * A�ade un nuevo usuario (login y password) al Vector y al fichero de usuarios
	  * @param login Login del usuario a registrar
	  * @param password Password del usuario a registrar
	  */
	public void registra(String login, String password) throws LoginInvalidoException 
	{
		Usuario aux = busca(login.trim());

		if(aux!=null) 
		{
			throw new LoginInvalidoException("El usuario " + 
						aux.login + " ya esta registrado");
		}
		if(login.trim().equals("")) {
			throw new LoginInvalidoException("El login no puede estar vacio");
		}

		aux = new Usuario(login.trim(), password.trim());
		listaUsuarios.addElement(aux);
		escribeFichero(filename, listaUsuarios);
	}

	// ---------------------------------------------------------------------------------
	//  Busca un determinado login en el Vector de usuarios
	// ---------------------------------------------------------------------------------

	private Usuario busca(String login) {
		Usuario aux = null;

		for(int i=0;i<listaUsuarios.size();i++) 
		{
			aux = (Usuario)listaUsuarios.elementAt(i);

			if( aux.login.equals(login) )
			{
				return aux;
			}
		}

		return null;		
	}

	// ---------------------------------------------------------------------------------
	//  Lee el fichero de usuarios y nos devuelve un Vector con los datos leidos
	// ---------------------------------------------------------------------------------

	private Vector leeFichero(String filename)
	{
		Vector lista = new Vector();
		String login, password;

		try {
			FileReader in = new FileReader(filename);

			StreamTokenizer st = new StreamTokenizer(in);

			/* Establecer caracteres de cadena y caracteres separadores */

			while(st.nextToken() != StreamTokenizer.TT_EOF)
			{
				login = st.sval;
				System.out.println("Login: " + login); // Linea para probar la lectura. Eliminar despu�s

				st.nextToken();
				password = st.sval;
				System.out.println("Password: " + password); // Linea para probar la lectura. Eliminar despu�s

				lista.addElement(new Usuario(login, password));
			}

			in.close();

		} catch(FileNotFoundException e1) {
			System.err.println("No se encuentra el fichero " + filename);
		} catch(IOException e2) {
			System.err.println("Error leyendo el fichero " + filename);
		} finally {
			return lista;
		}
	}

	// ---------------------------------------------------------------------------------
	//  Escribe el Vector de usuarios en el fichero en disco
	// ---------------------------------------------------------------------------------

	private void escribeFichero(String filename, Vector lista)
	{
		PrintWriter out = null;
		Usuario aux = null;

		try {
			out = /* Crear PrintWriter para escribir en el fichero filename */ null;

			// Imprime los datos de los usuarios en el fichero

			for(int i=0;i<lista.size();i++)
			{
				aux = (Usuario)lista.elementAt(i);

				out.println(aux.login + SEPARADOR + aux.password);
			}

		} catch(Exception e1) {
			System.err.println("Error escribiendo en el fichero " + filename);
		} finally {
			out.close();
		}


	}

	// ---------------------------------------------------------------------------------
	//  Clase que encapsula los datos de los usuarios
	// ---------------------------------------------------------------------------------

	class Usuario {
		public String login;
		public String password;

		public Usuario(String login, String password) {
			this.login = login;
			this.password = password;
		}
	}
}