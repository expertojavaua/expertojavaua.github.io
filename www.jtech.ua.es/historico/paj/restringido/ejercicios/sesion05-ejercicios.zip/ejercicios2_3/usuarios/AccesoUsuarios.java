package usuarios;

/** 
  * La interfaz <code>AccesoUsuarios</code> debe ser implementada por las clases que
  * se utilicen para realizar el acceso de los usuarios. Cada implementaci�n podr�
  * obtener los datos de distintas fuentes: fichero, BD, etc ...
  */
public interface AccesoUsuarios {

	/**
	  * Comprueba si el login y el password son validos
	  * @param login Login del usuario a validar
	  * @param password Password a validar
	  * @return true si el login y password son correctos, o false en otro caso.
	  */
	public boolean valida(String login, String password);

	/**
	  * A�ade un nuevo usuario (login y password) a la BD de usuarios
	  * @param login Login del usuario a registrar
	  * @param password Password del usuario a registrar
	  */
	public void registra(String login, String password) throws LoginInvalidoException;

}