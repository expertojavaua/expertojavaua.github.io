import java.awt.*;
import java.awt.event.*;
import chat.ClienteChat;
import usuarios.*;
import java.net.*;
import java.io.*;

/**
  * Aplicacion para chat
  */
public class AplicChat extends Frame
{
	/**
	  * Direccion IP del servidor
	  */
	TextField txtIP;

	/**
	  * Cliente de chat 
	  */
	ClienteChat chat;
	
	/**
	  * Constructor
	  */
	public AplicChat()
	{
		init();
	}
	
	/**
	  * Metodo para inicializar los componentes
	  */
	public void init()
	{
		setLayout(new BorderLayout());
		
		/******** Panel superior para validar el usuario y conectar *********/
		
		Panel panelSup = new Panel();
		panelSup.setLayout(new GridLayout(1, 3));
		
		// Conexion al servidor
		
		Label lblIP = new Label ("IP Servidor:");
		txtIP = new TextField();
		panelSup.add(lblIP);
		panelSup.add(txtIP);

		// Boton de conexion con el servidor
	
		Button btnConectar = new Button ("Conectar");
		btnConectar.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try {
					chat = new ClienteChat(txtIP.getText());
				} catch(UnknownHostException e1) {
					System.out.println("Host desconocido\n");
				} catch(IOException e2) {
					System.out.println("Error al conectar con el servidor\n");
				}
			}
		});
		panelSup.add(btnConectar);

		
		// Login y Password del usuario
		// ... Colocad aqui vuestro codigo
		




		add (panelSup, BorderLayout.NORTH);

		/******** Panel central con el buffer del chat *********/

		// ... Colocad aqui vuestro codigo
	

		/******** Panel inferior para enviar mensajes al chat *********/

		// ... Colocad aqui vuestro codigo
		
	}
	
	/**
	  * Main
	  */
	public static void main (String[] args)
	{
		AplicChat ac = new AplicChat();
		ac.setSize(400, 300);
		ac.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
		ac.show();
	}
}