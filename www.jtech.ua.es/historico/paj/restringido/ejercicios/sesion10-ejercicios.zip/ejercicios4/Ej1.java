
import java.sql.*;

public class Ej1 {

	Connection con;

	public Ej1() {

			/* Cargar driver */

			con = /* establecer conexion */

		listaUsuarios();

	}

	private void listaUsuarios() {

		String query = "SELECT * FROM usuarios";

		/* Ejecutar query y mostrar resultados */
	}

	public static void main(String [] args) {

		new Ej1();

	}
}