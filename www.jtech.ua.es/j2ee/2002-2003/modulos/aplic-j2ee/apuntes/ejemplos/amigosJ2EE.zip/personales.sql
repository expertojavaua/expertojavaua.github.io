# MySQL-Front Dump 2.5
#
# Host: localhost   Database: personales
# --------------------------------------------------------
# Server version 3.23.37

CREATE DATABASE personales;
USE personales;


#
# Table structure for table 'usuarios'
#

DROP TABLE IF EXISTS usuarios;
CREATE TABLE usuarios (
  login varchar(12) NOT NULL default '',
  password varchar(12) NOT NULL default '',
  fechaNac date NOT NULL default '0000-00-00',
  localidad varchar(20) NOT NULL default '',
  descripcion text NOT NULL,
  sexo char(1) NOT NULL default '',
  PRIMARY KEY  (login),
  UNIQUE KEY login (login),
  KEY login_2 (login)
) TYPE=MyISAM;



#
# Dumping data for table 'usuarios'
#

INSERT INTO usuarios (login, password, fechaNac, localidad, descripcion, sexo) VALUES("Ginebra", "Ginebra", "1970-01-01", "Alicante", "Simp�tica, divertida, atractiva y sobre todo modesta", "m");
INSERT INTO usuarios (login, password, fechaNac, localidad, descripcion, sexo) VALUES("Pepe", "Pepe", "1950-01-01", "Alicante", "Soy nuevo en Alicante y me gustar�a conocer a gente. Si quieres, puedes dejarme alg�n mensaje", "h");
INSERT INTO usuarios (login, password, fechaNac, localidad, descripcion, sexo) VALUES("Lala", "Lala", "1960-05-01", "Alicante", "no s� qu� poner!!!", "m");
INSERT INTO usuarios (login, password, fechaNac, localidad, descripcion, sexo) VALUES("pingg", "pingg", "1970-09-07", "Alicante", "hasta las narices", "h");
