package HelloWorldSLBean;

import java.rmi.*;
import javax.ejb.*;

public interface HelloWorld extends EJBObject
{
    public String hi() throws RemoteException;
}
