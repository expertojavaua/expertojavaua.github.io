package HelloWorldSLBean;

import javax.ejb.*;

public class HelloWorldBean implements SessionBean
{
    private SessionContext context;

    public String hi()  {
        String ret = new String("Hola; soy Domingo");
	return ret;
    }

    public HelloWorldBean() {}

    public void ejbCreate() throws CreateException  { }
    public void setSessionContext(SessionContext theContext) {
       this.context = theContext;
    }

    public void ejbActivate()  { }
    public void ejbPassivate()  { }
    public void ejbRemove()   { }
}

