package HelloWorldSLBean;

import java.rmi.*;
import javax.ejb.*;

public interface HelloWorldHome extends EJBHome
{
    public HelloWorld create() throws RemoteException, CreateException;
}
