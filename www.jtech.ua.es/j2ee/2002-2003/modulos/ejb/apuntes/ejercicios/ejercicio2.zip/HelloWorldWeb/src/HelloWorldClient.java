import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;
import java.rmi.RemoteException;
import java.util.Properties;
import HelloWorldSLBean.HelloWorldHome;
import HelloWorldSLBean.HelloWorld;

public class HelloWorldClient {
    public static void main(String [] args) {
        try {
            Context jndiContext = getInitialContext();
            Object ref = jndiContext.lookup("HelloWorld");
            HelloWorldHome home = (HelloWorldHome)
				PortableRemoteObject.narrow(ref,HelloWorldHome.class);   
            HelloWorld helloWorld = home.create();
            System.out.println("Voy a llamar al bean");
            String str = helloWorld.hi();
            System.out.println(str);
            System.out.println("He llamado al bean");

        } catch (java.rmi.RemoteException re){re.printStackTrace();}
          catch (javax.naming.NamingException ne){ne.printStackTrace();}
          catch (javax.ejb.CreateException ce){ce.printStackTrace();}
    }

    public static Context getInitialContext() 
        throws javax.naming.NamingException {
           Properties p = new Properties();
	   p.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");  
	   p.put(Context.PROVIDER_URL, "t3://localhost:7001");
           return new javax.naming.InitialContext(p);
    }
}
