drop table customer;

create table customer
(id int primary key,  
last_name varchar(20),  
first_name varchar(20),  
has_good_credit boolean);

exit;
