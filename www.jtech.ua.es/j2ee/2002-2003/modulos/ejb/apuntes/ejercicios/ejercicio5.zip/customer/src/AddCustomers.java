import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import javax.naming.Context;
import javax.naming.NamingException;
import java.util.Properties;
import java.lang.String;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.Integer;
import java.util.StringTokenizer;

public class AddCustomers {

    public static void main(String [] args) {
	String str;

	try {
            // obtain CustomerHome
            Context jndiContext = getInitialContext();
            Object obj = jndiContext.lookup("CustomerHomeRemote");
            CustomerHomeRemote home = (CustomerHomeRemote) 
				PortableRemoteObject.narrow(obj, CustomerHomeRemote.class);
	    do {
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		str = "";
		System.out.print("> (numero nombre apellido) : ");
		str = in.readLine();
		if (!str.equals("exit")) {
		    try {
			StringTokenizer st = new StringTokenizer(str);
			Integer id = new Integer(st.nextToken());
			String firstName = st.nextToken();
			String lastName = st.nextToken();
			CustomerRemote customer = home.create(id);
			customer.setFirstName(firstName);
			customer.setLastName(lastName);
			customer.setHasGoodCredit(true);
		    } catch (java.rmi.RemoteException ex) {
			System.out.println("Se ha producido una excepcion remota");
		    }
		}
	    } while(!str.equals("exit"));

        } catch (java.rmi.RemoteException re){re.printStackTrace();}
          catch (Throwable t){t.printStackTrace();}
   }
    
    public static Context getInitialContext() 
                          throws javax.naming.NamingException {
		Properties p = new Properties();
		p.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");  
		p.put(Context.PROVIDER_URL, "t3://localhost:7001");
		return new InitialContext(p);
    }
}
