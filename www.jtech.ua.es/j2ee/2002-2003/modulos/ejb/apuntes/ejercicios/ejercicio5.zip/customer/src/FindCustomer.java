import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import javax.naming.Context;
import javax.naming.NamingException;
import java.util.Properties;
import java.lang.String;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.Integer;
import java.util.StringTokenizer;

public class FindCustomer {

    public static void main(String [] args) {
	String str;

	try {
            // obtain CustomerHome
            Context jndiContext = getInitialContext();
            Object obj = jndiContext.lookup("CustomerHomeRemote");
            CustomerHomeRemote home = (CustomerHomeRemote) 
				PortableRemoteObject.narrow(obj, CustomerHomeRemote.class);
	    do {
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		str = "";
		System.out.print("> (apellido) : ");
		str = in.readLine();
		if (!str.equals("exit")) {
		    try {
			String lastName = str;
			CustomerRemote customer = home.findByLastName(str);
			String fname = customer.getFirstName();
			System.out.println("Nombre: "+fname);
		    } catch (javax.ejb.ObjectNotFoundException ex) {
			System.out.println("No se ha encontrado el customer");
		    }
		}
	    } while(!str.equals("exit"));

        } catch (java.rmi.RemoteException re){re.printStackTrace();}
          catch (Throwable t){t.printStackTrace();}
   }
    
    public static Context getInitialContext() 
                          throws javax.naming.NamingException {
		Properties p = new Properties();
		p.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");  
		p.put(Context.PROVIDER_URL, "t3://localhost:7001");
		return new InitialContext(p);
    }
}
