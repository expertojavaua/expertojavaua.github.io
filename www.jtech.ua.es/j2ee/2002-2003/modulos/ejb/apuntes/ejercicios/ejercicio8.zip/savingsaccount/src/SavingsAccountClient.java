import java.util.*;
import java.math.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;
import java.util.Properties;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.ObjectNotFoundException;
import javax.ejb.RemoveException;


public class SavingsAccountClient {

   public static void main(String[] args) {
       int numBeans = 20;
       SavingsAccount [] accounts = new SavingsAccount[numBeans];

       try {

           Context jndiContext = getInitialContext();
           Object objref = jndiContext.lookup("SavingsAccountEJB");
	   SavingsAccountHome home = (SavingsAccountHome) PortableRemoteObject.narrow(objref, SavingsAccountHome.class);

	   // creo 10 cuentas de Domingo Gallardo
	   for (int i=0; i<numBeans/2; i++) {
	       accounts [i] = findOrCreateAccount("i"+i, "Domingo", "Gallardo", new BigDecimal((double) i * 1000), home);
	   }

	   // creo 10 cuentas de Francisco Perez
	   for (int i=numBeans/2; i<numBeans; i++) {
	       accounts [i] = findOrCreateAccount("i"+i, "Francisco", "Perez", new BigDecimal ((double) i * 1000), home);
	   }
	   
	   // imprimo el balance de las cuentas
	   for (int i=0; i<numBeans; i++) {
	       log("Cuenta: "+accounts[i].getId()+
		   " de "+accounts[i].getFirstName()+
		   " "+accounts[i].getLastName()+
		   " tiene un balance de "+accounts[i].getBalance());
	   }

	   log("\nBuscando cuentas de Gallardo...");

           Collection c = home.findByLastName("Gallardo");
           Iterator it=c.iterator();

           while (it.hasNext()) {
              SavingsAccount account = (SavingsAccount)it.next();
              String id = (String)account.getId();
              BigDecimal amount = account.getBalance(); 
              log("\n"+id + ": " + amount);
	      account.credit(new BigDecimal("5000"));
              amount = account.getBalance(); 
              log("He ingresado 5000. Ahora queda: " + amount);
	   }

	   log("\nBuscando cuentas de Perez...");

           c = home.findByLastName("Perez");
           it=c.iterator();

           while (it.hasNext()) {
              SavingsAccount account = (SavingsAccount)it.next();
              String id = (String)account.getId();
              BigDecimal amount = account.getBalance(); 
              log("\n"+id + ": " + amount);
	      account.debit(new BigDecimal("5000"));
              amount = account.getBalance(); 
              log("He sacado 5000. Ahora queda: " + amount);
	   }

	   log("\nBuscando cuentas entre 10000 y 20000 ...");

           c = home.findInRange(new BigDecimal("7000.00"), 
               new BigDecimal("15000.00"));

           it=c.iterator();

           while (it.hasNext()) {
              SavingsAccount account = (SavingsAccount)it.next();
              String id = (String)account.getId();
              BigDecimal amount = account.getBalance(); 
	      String name = account.getLastName();
              System.out.println(id + " " + name + ": " + amount);
           }

	   log("\nCargando gastos a las cuentas de menos de 10000 ...");

           home.chargeForLowBalance(new BigDecimal("10000.00"), 
              new BigDecimal("1.00"));

	   // imprimo el balance de las cuentas
	   for (int i=0; i<numBeans; i++) {
	       log("Cuenta: "+accounts[i].getId()+
		   " de "+accounts[i].getFirstName()+
		   " "+accounts[i].getLastName()+
		   " tiene un balance de "+accounts[i].getBalance());
	   }

           System.exit(0);

       } catch (Exception ex) {
           System.err.println("Caught an exception." );
           ex.printStackTrace();
       }
   } 

   public static Context getInitialContext() 
        throws javax.naming.NamingException {
           Properties p = new Properties();
	   p.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");  
	   p.put(Context.PROVIDER_URL, "t3://localhost:7001");
           return new javax.naming.InitialContext(p);
    }

    private static SavingsAccount findOrCreateAccount(String id, String nombre, String apellido, BigDecimal balance, SavingsAccountHome home)
	throws CreateException, RemoteException, FinderException
    {
	try {
	    log("Intentando encontrar la cuenta con identificador: "+id);
	    return (home.findByPrimaryKey(id));
	} catch (ObjectNotFoundException onfe) {
	    log("No encontrado; lo creo");
	    return (home.create(id, nombre, apellido, balance));
	} 
    }

    private static void log(String s) {
	System.out.println(s);
    }

} 
