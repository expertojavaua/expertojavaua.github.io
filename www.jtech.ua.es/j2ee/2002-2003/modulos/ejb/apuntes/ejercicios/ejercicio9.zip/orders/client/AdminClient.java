// AdminClient.java
import java.util.*;
import java.text.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import javax.ejb.CreateException;

public class AdminClient {

	public static void main(String[] args) {
		DecimalFormat money = new DecimalFormat("$###,###.00");
		SimpleDateFormat dateformat = new SimpleDateFormat("MMM dd, yyyy");
		try {
			Context initial = new InitialContext();
			Object objref = initial.lookup("java:comp/env/ejb/CustomerSession");
			System.out.println("lookup successful");

			// Get a home interface object
			CustomerSessionHome home = 
				(CustomerSessionHome)PortableRemoteObject.narrow(objref, 
							  CustomerSessionHome.class);

			CustomerSession mysession = home.create();
			int count = mysession.getTotalCustomers();
			System.out.println("Total customers in database = " + count);

			// Get all the customers
			Collection customers = mysession.getCustomers();
			System.out.println("customer collection size = " + customers.size());
			Iterator i = customers.iterator();
			while (i.hasNext()) {
				CustomerVO cust = (CustomerVO)i.next();
				System.out.println(cust.getName() +
					"\t" + cust.getPassword() +
					"\t" + cust.getEmail());
				if (mysession.getOrdersPending(cust.getName())) {
				// print any orders associated with customer
					Collection orders = mysession.getOrders(cust.getName());
					if (orders.size() > 0) {
						System.out.println("Orders for Customer " + cust.getName());
					}
					Iterator t = orders.iterator();
					while (t.hasNext()) {
						OrderVO myorder = (OrderVO)t.next();
						System.out.println("\t" + money.format(myorder.getTotalAmount()) + 
							"\t" + dateformat.format(myorder.getOrderDate().getTime()) +
							"\t" + dateformat.format(myorder.getShipDate().getTime()));
						System.out.println("\tOrder Status = " + myorder.getOrderStatus());
						Iterator items = myorder.getLineItems().iterator();
						while (items.hasNext()) {
							LineItemVO myItem = (LineItemVO) items.next();
							System.out.println("\t" + myItem.getTitle()
									+ "\t" + myItem.getQuantity());
						}
					}
					System.out.println("_______________________________________\n");
				}
			}
			Calendar now = new GregorianCalendar();
			mysession.shipOrdersByDate(now);

		} catch (Exception ex) {
			System.err.println("Caught an unexpected exception." );
			System.err.println(ex.getMessage());
		} finally {
			System.exit(0);
		}
   } 
} // AdminClient
