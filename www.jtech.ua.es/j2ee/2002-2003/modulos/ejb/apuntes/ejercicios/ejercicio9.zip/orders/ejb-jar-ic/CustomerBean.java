// CustomerBean.java

import java.util.*;
import javax.ejb.*;
import javax.naming.*;

public abstract class CustomerBean implements EntityBean {

	// EntityBean variables
	private EntityContext context;

	// Access methods for persistent fields

	public abstract String getCustomerID();
	public abstract void setCustomerID(String id);

	public abstract String getName();
	public abstract void setName(String name);

	public abstract String getPassword();
	public abstract void setPassword(String password);

	public abstract String getEmail();
	public abstract void setEmail(String email);

	public abstract boolean getOrdersPending();
	public abstract void setOrdersPending(boolean pending);

	// Access methods for relationship fields
	
	public abstract Collection getOrders();
	public abstract void setOrders(Collection orders);

	// Select methods
	public abstract Collection ejbSelectTotalCustomers()
		throws FinderException;

	// Business methods

	public void addOrder(OrderLocal order) {
		System.out.println("CustomerBean addOrder");
		try {
			Collection orders = getOrders();
			orders.add(order);
		} catch (Exception ex) {
			throw new EJBException(ex.getMessage());
		}
	}

	public void dropOrder(OrderLocal order) {
		System.out.println("CustomerBean dropOrder");
		try {
			Collection orders = getOrders();
			orders.remove(order);
		} catch (Exception ex) {
			throw new EJBException(ex.getMessage());
		}
	}

	// EJB Home Methods
	public int ejbHomeGetTotalCustomers() throws FinderException {
		System.out.println("ejbHomeGetTotalCustomers");
		return ejbSelectTotalCustomers().size();
	}

	// EntityBean methods

	public String ejbCreate(String customerName,
		String password, String email) throws CreateException {

		System.out.println("CustomerBean: ejbCreate, name=" + customerName);
		String newKey = DBUtil.dbGetKey();
		setCustomerID(newKey);
		setName(customerName);
		setPassword(password);
		setEmail(email);
		setOrdersPending(false);
		return newKey;
	}


	public void setEntityContext(EntityContext context) {
		this.context = context;
		System.out.println("CustomerBean: setEntityContext");
	}

	public void unsetEntityContext() {
		System.out.println("CustomerBean: unsetEntityContext");
		context = null;
	}

	public void ejbActivate() { }

	public void ejbPassivate() { }

	public void ejbLoad() {
		System.out.println("CustomerBean: ejbLoad");
	}

	public void ejbStore() {
		System.out.println("CustomerBean: ejbStore");
	}

	public void ejbPostCreate(String customerName,
		String password, String email) { }

	public void ejbRemove() { 
		System.out.println("CustomerBean: ejbRemove");
	}

} // CustomerBean 
