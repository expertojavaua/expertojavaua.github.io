// CustomerIdentityException.java
// Application Exception
public class CustomerIdentityException extends Exception {

   public CustomerIdentityException() { }

   public CustomerIdentityException(String msg) {
      super(msg);
   }
}
