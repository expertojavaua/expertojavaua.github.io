// CustomerLocal.java

import javax.ejb.EJBLocalObject;
import java.util.*;

public interface CustomerLocal extends EJBLocalObject {
	
	// access methods for persistent fields
	public String getCustomerID();
	public String getName();
	public String getPassword();
	public void setPassword(String newPassword);
	public String getEmail();
	public void setEmail(String newEmail);
	public boolean getOrdersPending();
	public void setOrdersPending(boolean pending);

	// access methods for relationship fields
	public Collection getOrders();
	
	// business methods
	public void addOrder(OrderLocal order);
	public void dropOrder(OrderLocal order);
}
