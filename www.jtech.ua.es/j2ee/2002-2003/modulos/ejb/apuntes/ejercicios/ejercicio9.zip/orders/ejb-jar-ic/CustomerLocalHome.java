// CustomerLocalHome.java

import java.util.Collection;
import javax.ejb.*;

public interface CustomerLocalHome extends EJBLocalHome {
	
	// Create method
	public CustomerLocal create(String name, String password,
		String email) throws CreateException;
	
	// Finder methods
	public CustomerLocal findByPrimaryKey(String customerID)
		throws FinderException;

	// Custom finder methods
	public Collection findByCustomerName(String name)
		throws FinderException;
	
	// Return all Customer EJBs in the database
	public Collection findAll()
		throws FinderException;
	
	// Home methods
	// Return the number of Customers in the database
	public int getTotalCustomers()
		throws FinderException;
}
