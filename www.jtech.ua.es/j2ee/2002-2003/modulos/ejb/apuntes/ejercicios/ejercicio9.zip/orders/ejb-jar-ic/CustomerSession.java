// CustomerSession.java

import javax.ejb.*;
import java.rmi.RemoteException;
import java.util.*;

public interface CustomerSession extends EJBObject {
 
   public int getTotalCustomers() 
			throws FinderException, RemoteException;

	public void createCustomer(CustomerVO customer) 
			throws CreateException, FinderException, RemoteException;
	
	public void changePassword(String name, String password) 
			throws CustomerIdentityException, CustomerException, 
			FinderException, RemoteException;
	
	public void changeEmail(String name, String email) 
			throws CustomerIdentityException, CustomerException, 
			FinderException, RemoteException;
	
	public void identifyCustomer(String name, String password) 
			throws CustomerIdentityException, 
			FinderException, RemoteException;
	
	public boolean getOrdersPending(String name)
			throws CustomerIdentityException, 
			FinderException, RemoteException;

	public Collection getOrders(String name)
			throws CustomerIdentityException, 
			FinderException, RemoteException;

	public void createOrder(OrderVO order)
		throws CreateException, CustomerIdentityException,
		FinderException, RemoteException;

	public Collection buildItems(Collection items)
		throws RemoteException;
	
	public Collection getCustomers()
		throws FinderException, RemoteException;

	public void shipOrdersByDate(Calendar orderDate)
		throws FinderException, RemoteException;
}
