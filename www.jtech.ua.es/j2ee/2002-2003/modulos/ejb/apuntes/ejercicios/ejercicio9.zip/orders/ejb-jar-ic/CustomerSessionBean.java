// CustomerSessionBean.java

import java.rmi.RemoteException; 
import javax.ejb.*;
import javax.naming.*;
import java.util.*;

public class CustomerSessionBean implements SessionBean {

	// initialize in ejbCreate()

	private CustomerLocalHome customerHome;
	private OrderLocalHome orderHome;
	private LineItemLocalHome lineItemHome;

	// Business methods

	// Return the number of Customers in the database

   public int getTotalCustomers() throws FinderException {
		return customerHome.getTotalCustomers();
	}

	// Create a new Customer in the CustomerDB
	// verify that the name is unique and the password
	// is non-empty. 

	public void createCustomer(CustomerVO customer) 
			throws CreateException, FinderException {
		if (customer.getName() == null || customer.getPassword() == null
				|| customer.getEmail() == null) {
			throw new CreateException("Customer data is null");
		}
		if (customer.getName().equals("") || customer.getPassword().equals("")
				|| customer.getEmail().equals("")) {
			throw new CreateException("Customer fields cannot be empty.");
		}
		Collection c = customerHome.findByCustomerName(customer.getName());
		if (c.size() == 0) {
			customerHome.create(
				customer.getName(), 
				customer.getPassword(),
				customer.getEmail());
		}
		else {
			throw new CreateException("Customer name already in use.");
		}
	}
	
	// Change the password for the customer.
	// Make sure customer is in the database
	// Throws CustomerIdentityException if no match.
	// Throws CustomerException for other problems.

	public void changePassword(String name, String password) 
			throws CustomerIdentityException, CustomerException, 
			FinderException {
		if (password.equals("")) {
			throw new CustomerException("Password cannot be empty");
		}
		Collection c = customerHome.findByCustomerName(name);
		if (c.size() == 1) {
			Iterator i=c.iterator();
			CustomerLocal cust = (CustomerLocal)i.next();
			cust.setPassword(password);
		}
		else {
			throw new CustomerIdentityException(
						"Cannot find customer " + name);
		}
	}
	
	// Change the email for the customer.
	// Make sure customer is in the database
	// Throws CustomerIdentityException if no match.
	// Throws CustomerException for other problems.

	public void changeEmail(String name, String email) 
			throws CustomerIdentityException, CustomerException, 
			FinderException {
		if (email.equals("")) {
			throw new CustomerException("Email cannot be empty");
		}
		Collection c = customerHome.findByCustomerName(name);
		if (c.size() == 1) {
			Iterator i=c.iterator();
			CustomerLocal cust = (CustomerLocal)i.next();
			cust.setEmail(email);
		}
		else {
			throw new CustomerIdentityException(
						"Cannot find customer " + name);
		}
	}
	
	// Given a customer name, make sure the password
	// matches the customer's name in the database
	// Throws CustomerIdentityException if no match.

	public void identifyCustomer(String name, String password) 
			throws CustomerIdentityException, FinderException {
		Collection c = customerHome.findByCustomerName(name);
		if (c.size() == 1) {
			Iterator i=c.iterator();
			CustomerLocal cust = (CustomerLocal)i.next();
			if (!cust.getPassword().equals(password)) {
				throw new CustomerIdentityException(
						"Incorrect Password for customer " + name);
			}
		}
		else {
			throw new CustomerIdentityException(
						"Cannot find customer " + name);
		}
	}
	
	// Given the customer 'name', return the ordersPending field.
	// Throw CustomerIdentityException if customer
	// cannot be found.

	public boolean getOrdersPending(String name) 
			throws CustomerIdentityException, FinderException {
		Collection c = customerHome.findByCustomerName(name);
		if (c.size() == 1) {
			Iterator i=c.iterator();
			CustomerLocal cust = (CustomerLocal)i.next();
			return cust.getOrdersPending();
		}
		else {
			throw new CustomerIdentityException(
						"Cannot find customer " + name);
		}
	}

	// given the customer name,
	// return ArrayList of OrderVOs
	// for that customer

	public Collection getOrders(String name)
			throws CustomerIdentityException, FinderException {
		
		Collection c = customerHome.findByCustomerName(name);
		if (c.size() == 1) {
			Iterator i=c.iterator();
			CustomerLocal cust = (CustomerLocal)i.next();

			// return an ArrayList of OrderVOs
			ArrayList orderList = new ArrayList();
			
			Collection a = cust.getOrders();
			i = a.iterator();
			while (i.hasNext()) {
				OrderLocal orderEJB = (OrderLocal)i.next();

				// get orderEJB's ArrayList of LineItem EJBs
				// and put them in a new ArrayList of LineItemVOs

				ArrayList lineItems = new ArrayList();
				Iterator lineIt = orderEJB.getLineItems().iterator();
				while (lineIt.hasNext()) {
					LineItemLocal item = (LineItemLocal) lineIt.next();
					lineItems.add(new LineItemVO(item.getTitle(), item.getQuantity()));
				}
				
				// convert OrderEJB longs to Calendar objects
				Calendar orderDate = new GregorianCalendar();
				orderDate.setTime(new Date(orderEJB.getOrderDate()));
				Calendar shipDate = new GregorianCalendar();
				shipDate.setTime(new Date(orderEJB.getShipDate()));

				// create OrderVO object and add to orderlist ArrayList
				OrderVO order = 
					new OrderVO(orderEJB.getTotalAmount(),
						orderEJB.getOrderStatus(),
						orderDate,
						shipDate,
						cust.getName(),
						lineItems);
				orderList.add(order);
			}

			return orderList;
		}
		else {
			throw new CustomerIdentityException(
						"Cannot find customer " + name);
		}
	}

	// Ship all Order EJBs with an orderDate that
	// is equal to or earlier than argument orderDate
	
	public void shipOrdersByDate(Calendar orderDate)
			throws FinderException {
		// convert Calendar object to long
		long when = orderDate.getTime().getTime();
		
		// use finder to get orders
		try {
		Collection orders = 
			orderHome.findByOrderDatePrevious(when, 
				OrderLocalHome.InProcess);
		
		Iterator i = orders.iterator();
		System.out.println("Found " + orders.size() + " orders");
		
		// use today's date for the ship date
		Date now = new Date();
		while (i.hasNext()) {
			System.out.println("getting order EJB");
			OrderLocal orderEJB = (OrderLocal)i.next();
			System.out.println("calling shipOrder");
			orderEJB.shipOrder(now.getTime());
			System.out.println("return from shipOrder");
			System.out.println("OrderID = " + orderEJB.getOrderID());
			System.out.println("Shipped order for " + orderEJB.getCustomer().getName());
		}
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new EJBException(
					"shipOrdersByDate: " + ex.getMessage());
		}
	}

	// Get the shoppingList of RecordingVOs and build
	// an ArrayList of LineItemVOs with no duplicates.
	// Increment the quantity when we find duplicates.
	public Collection buildItems(Collection items) {
		try {
			ArrayList itemList = new ArrayList();
			Iterator i = items.iterator();
			while (i.hasNext()) {
				RecordingVO r = (RecordingVO) i.next();
				LineItemVO thisItem = new LineItemVO(r.getTitle(), 1);
				// is LineItemVO already in itemList?
				int index = itemList.indexOf(thisItem);
				if (index < 0) { 
					// not a duplicate;
					// just add this one
					itemList.add(thisItem);
				}
				else {
					// Duplicate LineItemVO--
					// Get the duplicate & increment quantity
					LineItemVO l = (LineItemVO) itemList.get(index);
					int q = l.getQuantity() + 1;
					l.setQuantity(q);
					// Replace LineItemVO with updated quantity field
					itemList.set(index, l);
				}
			}
			return itemList;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new EJBException(
					"buildItems: " + ex.getMessage());
		}
	}

	public void createOrder(OrderVO order)
			throws CustomerIdentityException, CreateException, 
			FinderException {
		
		Collection c = customerHome.findByCustomerName(order.getCustomerName());
		if (c.size() == 1) {

			// get CustomerEJB
			Iterator i = c.iterator();
			CustomerLocal cust = (CustomerLocal)i.next();
			try {

				// get the LineItemVO Collection
				Collection items = order.getLineItems();
				System.out.println("There are " + items.size() + " line items");
				if (items.isEmpty()) {
					throw new CreateException("createOrder: LineItems cannot be empty.");
				}

				// create OrderEJB
				OrderLocal myorder = orderHome.create(
					order.getTotalAmount(),
					order.getOrderStatus(),
					
					// convert Calendar objects to longs
					order.getOrderDate().getTime().getTime(),
					order.getShipDate().getTime().getTime(),
					cust);
				
				// create LineItemEJBs

				Iterator lineIt = items.iterator();
				while (lineIt.hasNext()) {
					LineItemVO lineItem = (LineItemVO) lineIt.next();
					LineItemLocal myLineItem = lineItemHome.create(
						lineItem.getTitle(),
						lineItem.getQuantity(),
						myorder);
					System.out.println("created LineItem for " + lineItem.getTitle());
				}
				cust.setOrdersPending(true);
			}
			catch (Exception ex) {
				System.out.println(ex.getMessage());
				ex.printStackTrace();
				throw new EJBException("CustomerSessionBean: createOrder");
			}
		}
		else {
			throw new CustomerIdentityException(
						"Cannot find customer " + order.getCustomerName());
		}
	}
		
	// Get all the customers in the customer database:
	// Return an ArrayList of CustomerVOs

	public Collection getCustomers() throws FinderException {
			
		// return an ArrayList of CustomerVOs
		ArrayList customerList = new ArrayList();
			
		Collection a = customerHome.findAll();
		Iterator i = a.iterator();
		while (i.hasNext()) {
			CustomerLocal customerEJB = (CustomerLocal)i.next();
			
			CustomerVO customer = 
				new CustomerVO(customerEJB.getName(),
					customerEJB.getPassword(),
					customerEJB.getEmail());
			customerList.add(customer);
		}

		return customerList;
	}
   
   // EJB Methods
	public CustomerSessionBean() {}
   
	public void ejbCreate() {
		try {
			Context initial = new InitialContext();
			System.out.println("CustomerSession ejbCreate()");
			
			// Find LocalHome Interface to CustomerEJB
			Object objref = initial.lookup("java:comp/env/ejb/Customer");
			System.out.println("Customer lookup successful");
			customerHome = (CustomerLocalHome)objref;
			System.out.println("got reference to CustomerLocalHome interface");

			// Find LocalHome Interface to OrderEJB
			objref = initial.lookup("java:comp/env/ejb/Order");
			System.out.println("Order lookup successful");
			orderHome = (OrderLocalHome)objref;
			System.out.println("got reference to OrderLocalHome interface");
			
			// Find LocalHome Interface to LineItemEJB
			objref = initial.lookup("java:comp/env/ejb/LineItem");
			System.out.println("LineItem lookup successful");
			lineItemHome = (LineItemLocalHome)objref;
			System.out.println("got reference to LineItemLocalHome interface");
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new EJBException(ex.getMessage());
		}
		System.out.println("CustomerSessionBean: ejbCreate");
	}

   public void ejbRemove() {}
   public void ejbActivate() {}
   public void ejbPassivate() {}
   public void setSessionContext(SessionContext sc) {}

} // CustomerSessionBean
