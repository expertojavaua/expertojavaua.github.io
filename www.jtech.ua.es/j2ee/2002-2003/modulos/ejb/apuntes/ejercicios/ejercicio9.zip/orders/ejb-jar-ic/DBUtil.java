// DBUtil.java
import COM.cloudscape.util.KeyGen;

public class DBUtil {

	// Cloudscape propriety routine to generate
	// primary key
	public static String dbGetKey() {
		System.out.println("getting new primary key");
		return KeyGen.getUniversalKeyStringValue();
	}
}
