// LineItemBean.java

import java.util.*;
import javax.ejb.*;
import javax.naming.*;

public abstract class LineItemBean implements EntityBean {

	// EntityBean variables
	private EntityContext context;

	// Access methods for persistent fields

	public abstract String getLineItemID();
	public abstract void setLineItemID(String id);

	public abstract String getTitle();
	public abstract void setTitle(String title);

	public abstract int getQuantity();
	public abstract void setQuantity(int quantity);
	
	// access methods for relationship fields

	public abstract OrderLocal getOrder();
	public abstract void setOrder(OrderLocal order);

	// EntityBean methods

	public String ejbCreate(String title,
		int quantity, OrderLocal order) throws CreateException {

		System.out.println("LineItemBean: ejbCreate");
		String newKey = 
				DBUtil.dbGetKey();
		setLineItemID(newKey);
		setTitle(title);
		setQuantity(quantity);
		return newKey;
	}

	public void ejbPostCreate(String title, int quantity, OrderLocal order) { 
		setOrder(order);
	}

	public void setEntityContext(EntityContext context) {
		this.context = context;
	}

	public void unsetEntityContext() {
		context = null;
	}

	public void ejbActivate() { }

	public void ejbPassivate() { }

	public void ejbLoad() {
		System.out.println("LineItemBean ejbLoad");
	}

	public void ejbStore() {
		System.out.println("LineItemBean ejbStore");
	}

	public void ejbRemove() { 
		System.out.println("LineItemBean ejbRemove");
	}

} // LineItemBean 
