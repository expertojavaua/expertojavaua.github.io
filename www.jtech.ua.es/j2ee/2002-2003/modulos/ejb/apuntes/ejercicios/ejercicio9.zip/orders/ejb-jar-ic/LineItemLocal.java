// LineItemLocal.java

import javax.ejb.*;

public interface LineItemLocal extends EJBLocalObject {

	// access methods for persistent fields
	public String getLineItemID();
	public String getTitle();
	public int getQuantity();
	public void setQuantity(int quantity);

	// access methods for relationship fields
	public OrderLocal getOrder();
	public void setOrder(OrderLocal order);
}
