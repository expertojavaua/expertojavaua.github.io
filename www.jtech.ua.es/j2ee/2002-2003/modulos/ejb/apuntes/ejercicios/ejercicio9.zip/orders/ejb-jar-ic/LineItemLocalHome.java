// LineItemLocalHome.java
import javax.ejb.*;
import java.util.*;

public interface LineItemLocalHome extends EJBLocalHome {

    public LineItemLocal create(String title,
			int quantity, OrderLocal order) throws CreateException;
    
    public LineItemLocal findByPrimaryKey(String id)
        throws FinderException;

    // custom finder method
	 public Collection findByTitle(String title)
        throws FinderException;
}
