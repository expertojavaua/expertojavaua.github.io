// LineItemVO.java
import java.util.*;

public class LineItemVO implements java.io.Serializable
{
	private String title;
	private int quantity;

	public LineItemVO(String title, int quantity)
	{
		setTitle(title);
		setQuantity(quantity);
	}
	
	// getters
	public String getTitle() { return title; }
	public int getQuantity() { return quantity; }

	// setters
	public void setTitle(String title) { this.title = title; }
	public void setQuantity(int quantity) { this.quantity = quantity; }
	
	public boolean equals(Object lineItem) {
		return (title.equals(((LineItemVO)lineItem).getTitle()));
	}
}
