// OrderBean.java
import java.util.*;
import javax.ejb.*;

public abstract class OrderBean implements EntityBean {

	// EntityBean variables
	private EntityContext context;

	// Access methods for persistent fields

	public abstract String getOrderID();
	public abstract void setOrderID(String id);

	public abstract double getTotalAmount();
	public abstract void setTotalAmount(double amount);

	public abstract int getOrderStatus();
	public abstract void setOrderStatus(int status);

	public abstract long getOrderDate();
	public abstract void setOrderDate(long date);

	public abstract long getShipDate();
	public abstract void setShipDate(long date);

	// Access methods for relationship fields

	public abstract CustomerLocal getCustomer();
	public abstract void setCustomer(CustomerLocal customer);

	public abstract Collection getLineItems();
	public abstract void setLineItems(Collection lineItems);

	// Business methods
	public void shipOrder(long shipDate) {
		setShipDate(shipDate);
		setOrderStatus(OrderLocalHome.Shipped);
	}

	// EntityBean methods

	public String ejbCreate(double totalAmount,
		int orderStatus, long orderDate, long shipDate,
		CustomerLocal customer)
		throws CreateException {

		System.out.println("OrderBean: ejbCreate");
		String newKey = 
				DBUtil.dbGetKey();
		setOrderID(newKey);
		setTotalAmount(totalAmount);
		setOrderStatus(orderStatus);
		setOrderDate(orderDate);
		setShipDate(shipDate);
		return newKey;
	}

	public void ejbPostCreate(double totalAmount,
		int orderStatus, long orderDate, long shipDate,
		CustomerLocal customer) { 

		setCustomer(customer);
	}


	public void setEntityContext(EntityContext context) {
		this.context = context;
	}

	public void unsetEntityContext() {
		context = null;
	}

	public void ejbActivate() { }

	public void ejbPassivate() { }

	public void ejbLoad() { }

	public void ejbStore() { }

	public void ejbRemove() { }

} // OrderBean 
