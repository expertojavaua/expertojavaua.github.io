// OrderLocal.java
import java.util.*;
import javax.ejb.*;

public interface OrderLocal extends EJBLocalObject {

	// Access methods for persistent data fields
	public String getOrderID();
	public double getTotalAmount();
	public int getOrderStatus();
	public long getOrderDate();
	public long getShipDate();
	public void setOrderStatus(int status);

	// Access methods for relationship fields
	public CustomerLocal getCustomer();
	public Collection getLineItems();

	// Business methods
	public void shipOrder(long shipDate);
}
