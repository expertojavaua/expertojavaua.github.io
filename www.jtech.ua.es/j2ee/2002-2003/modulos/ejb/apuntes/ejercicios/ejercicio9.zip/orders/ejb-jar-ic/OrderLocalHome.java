// OrderLocalHome.java

import java.util.*;
import javax.ejb.*;

public interface OrderLocalHome extends EJBLocalHome {

	public static final int InProcess = 1;
	public static final int Shipped = 2;
	public static final int Closed = 3;
    
	public OrderLocal create(double totalAmount,
		int orderStatus, long orderDate, long shipDate,
		CustomerLocal customer) throws CreateException;

	public OrderLocal findByPrimaryKey(String id)
		throws FinderException;

	public Collection findByOrderDatePrevious(
		long orderDate, int orderStatus)
		throws FinderException;
}
