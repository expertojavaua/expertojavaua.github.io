// OrderVO.java
import java.util.*;

public class OrderVO implements java.io.Serializable
{
	private double totalAmount;
	private int orderStatus;
	private Calendar orderDate;
	private Calendar shipDate;
	private String customerName;
	private Collection lineItems;

	public OrderVO(double amount, int status, Calendar orderDate,
			Calendar shipDate, String name, Collection lineItems)
	{
		setTotalAmount(amount);
		setOrderStatus(status);
		setOrderDate(orderDate);
		setShipDate(shipDate);
		setCustomerName(name);
		setLineItems(lineItems);
	}
	
	// getters
	public double getTotalAmount() { return totalAmount; }
	public int getOrderStatus() { return orderStatus; }
	public Calendar getOrderDate() { return (Calendar)orderDate.clone(); }
	public Calendar getShipDate() { return (Calendar)shipDate.clone(); }
	public String getCustomerName() { return customerName; }
	public Collection getLineItems() { return lineItems; }

	// setters
	public void setTotalAmount(double amount) { totalAmount = amount; }
	public void setOrderStatus(int status) { orderStatus = status; }
	public void setOrderDate(Calendar d) {
		orderDate = (GregorianCalendar)new GregorianCalendar(
			d.get(Calendar.YEAR),
			d.get(Calendar.MONTH),
			d.get(Calendar.DATE)); }
	public void setShipDate(Calendar d) {
		shipDate = (GregorianCalendar)new GregorianCalendar(
			d.get(Calendar.YEAR),
			d.get(Calendar.MONTH),
			d.get(Calendar.DATE)); }
	public void setCustomerName(String name) { customerName = name; }
	
	public void setLineItems(Collection items) {
		lineItems = items;
	}
}
