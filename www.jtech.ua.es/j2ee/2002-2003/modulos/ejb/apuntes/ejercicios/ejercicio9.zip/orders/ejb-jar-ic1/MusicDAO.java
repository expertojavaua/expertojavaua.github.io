// MusicDAO.java
import java.util.ArrayList;
import MusicDAOSysException;
import RecordingVO;

// Abstract class for Music Data Access Object

public interface MusicDAO {
	public ArrayList dbLoadMusicList() throws MusicDAOSysException;
	public ArrayList dbLoadTrackList(RecordingVO rec) 
			throws MusicDAOSysException;
}
