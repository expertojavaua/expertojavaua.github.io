// MusicDAOFactory.java
import javax.naming.NamingException;
import javax.naming.InitialContext;
import MusicDAOSysException;

public class MusicDAOFactory {

	// Instantiate a subclass that implements the abstract
	// MusicDAO interface.
	// Obtain subclass name from the deployment descriptor

	public static MusicDAO getDAO() throws MusicDAOSysException {
		
		MusicDAO musicDAO = null;
		String musicDAOClass = "java:comp/env/MusicDAOClass";
		String className = null;
		
		try {
			InitialContext ic = new InitialContext();
			// Lookup value of environment entry for DAO classname
			// Value is set in deployment descriptor
			className = (String) ic.lookup(musicDAOClass);

			// Instantiate class, which will provide implementation
			// for the MusicDAO interface
			musicDAO = (MusicDAO) Class.forName(className).newInstance();
		} catch (Exception ex) {
			throw new MusicDAOSysException("MusicDAOFactory.getDAO: " +
				"NamingException for <" + className + "> DAO class : \n" 
				+ ex.getMessage());
		} 
		return musicDAO;
	}
}
