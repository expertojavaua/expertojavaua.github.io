// MusicDAOSysException.java
// System Exception
import java.lang.RuntimeException;

public class MusicDAOSysException extends RuntimeException {

// MusicDAOSysException extends standard RuntimeException.
// Thrown by MusicDAO subclasses when there is an
// unrecoverable system error (typically SQLException)

	public MusicDAOSysException(String msg) {
		super(msg);
	}

	public MusicDAOSysException() {
		super();
	}
}
