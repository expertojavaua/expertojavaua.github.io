// MusicIterator.java
import javax.ejb.EJBObject;
import java.rmi.RemoteException;
import java.util.*;

public interface MusicIterator extends EJBObject, ValueListIterator {

   public ArrayList getTrackList(RecordingVO rec) throws NoTrackListException,
		RemoteException;
	
} // MusicIterator
