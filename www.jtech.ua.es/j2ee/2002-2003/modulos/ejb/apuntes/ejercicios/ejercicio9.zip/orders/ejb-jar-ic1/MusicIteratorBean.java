// MusicIteratorBean.java
import java.rmi.RemoteException;
import javax.ejb.*;
import javax.naming.*;
import java.util.*;

public class MusicIteratorBean implements SessionBean {
	
	// State variables
	private MusicPageLocal pageBean = null;
	private int currentIndex;
	private int previousStart;
	private int pageSize;
	private int arraySize;
	
	// Business methods

   public ArrayList getTrackList(RecordingVO rec) 
			throws NoTrackListException {
		
		try {
			return pageBean.getTrackList(rec);
		} catch(Exception ex) {
			throw new EJBException(ex.getMessage());
		}
	}
	
	public int getSize()
	{ return arraySize; }

	public int setPageSize(int numberOfElements) {
		int oldSize = pageSize;
		if (numberOfElements < 1 ) 
			{ pageSize = 1; }
		else if (numberOfElements > arraySize)
			{ pageSize = arraySize; }
		else 
			{ pageSize = numberOfElements; }
		return oldSize;
	}

	public int getPageSize() { return pageSize; }
	
	public ArrayList previousPage() 
	{
		// Return the previous page to the client
		// Perform some basic sanity checks
		// on the parameters
		try {
			currentIndex = previousStart - pageSize;
			if (currentIndex < 0) currentIndex = 0;
			int newIndex = currentIndex;
			previousStart = currentIndex;
			if (previousStart == 0) previousStart = -1;
			currentIndex += pageSize;
			if (currentIndex > arraySize) currentIndex = arraySize;
			return pageBean.getPage(newIndex, pageSize);
		} catch(Exception ex) {
			throw new EJBException(ex.getMessage());
		}
	}

	public ArrayList nextPage() 
	{
		// Return the next page to the client
		// Perform some basic sanity checks
		// on the parameters
		try {
			int newIndex = currentIndex;
			previousStart = currentIndex;
			currentIndex += pageSize;
			if (currentIndex > arraySize) currentIndex = arraySize;
			return pageBean.getPage(newIndex, pageSize);
		} catch(Exception ex) {
			throw new EJBException(ex.getMessage());
		}
	}

	public void resetIndex() {
		currentIndex = 0;
		previousStart = 0;
	}

	public boolean hasMoreElements() {
			return (currentIndex < arraySize);
	}

	public boolean hasPreviousElements() {
		return (previousStart >=0);
	}

	// EJB Methods

	public MusicIteratorBean() {}
	
	// We must initialize all of
	// the state variables here
	public void ejbCreate() {
		try {
			Context initial = new InitialContext();
			Object objref = initial.lookup("java:comp/env/ejb/MusicPage");
			System.out.println("lookup successful");
			MusicPageLocalHome pageHome = (MusicPageLocalHome)objref;
			System.out.println("got reference to MusicPageLocalHome interface");
			pageBean = pageHome.create();
			System.out.println("created MusicPageBean");
			arraySize = pageBean.getSize();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new EJBException(ex.getMessage());
		}
		// set page size from ValueListIterator default
		pageSize = ValueListIterator.defaultPageSize;
		currentIndex = 0;
		previousStart = 0;
		System.out.println("MusicIteratorBean:ejbCreate()");
	}
	
	public void ejbRemove() {}
	public void ejbActivate() {}
	public void ejbPassivate() {}
	public void setSessionContext(SessionContext sc) {}
} // MusicIteratorBean
