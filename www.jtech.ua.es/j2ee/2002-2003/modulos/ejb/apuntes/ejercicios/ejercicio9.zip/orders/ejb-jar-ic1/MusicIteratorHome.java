// MusicIteratorHome.java
import java.io.Serializable;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;

public interface MusicIteratorHome extends EJBHome {

    MusicIterator create() throws RemoteException, CreateException;
}
