// MusicPageBean.java
import java.util.*;
import javax.ejb.*;
import javax.naming.*;

public class MusicPageBean implements SessionBean {
	
	// Instance data field MusicDAO object 
	// to access database.
	// MusicDAO object is instantiated in ejbCreate()
	// and provides implementation of the MusicDAO interface
	// for the particular database we're using.
	private MusicDAO dao;

	// class-wide ArrayList that holds all
	// the recordings
	private ArrayList musicList;
	
	// Business methods

	public int getSize() { return musicList.size(); }

	public ArrayList getPage(int currentIndex, int pageSize) {
		// perform a sanity check on the arguments
		if (currentIndex > musicList.size()) currentIndex = musicList.size();
		else if (currentIndex < 0) currentIndex = 0;
		if (pageSize <= 0) pageSize = 1;
		else if (pageSize > musicList.size()) pageSize = musicList.size();

		// create the sublist
		ArrayList page = new ArrayList();

		// initialize an iterator to point to the correct element
		ListIterator current = musicList.listIterator(currentIndex);
		int i = 0;

		// grab the elements for the desired page size
		while (current.hasNext() && i < pageSize) {
			page.add(current.next());
			i++;
		}
		return page;
	}

	public ArrayList getTrackList(RecordingVO rec) 
		throws NoTrackListException {

		ArrayList trackList;
		try {
			// Encapsulate database calls in MusicDAO
			trackList = dao.dbLoadTrackList(rec);
		} catch (MusicDAOSysException ex) {
			throw new EJBException("getTrackList: " + ex.getMessage());
		}
		if (trackList.size() == 0) {
			throw new NoTrackListException(
				"No Track List found for RecordingID " + rec.getRecordID());
		}
		return trackList;
	}

	// EJB methods

	public void ejbCreate() {
		try {
			// The MusicDAOFactory class returns an implementation
			// of the MusicDAO interface
			dao = MusicDAOFactory.getDAO();

			// initialize the shared music ArrayList
			musicList = dao.dbLoadMusicList();
			System.out.println("MusicPageBean:ejbCreate(): initialized musicList from DAO object");
		}
		catch (MusicDAOSysException ex) {
			ex.printStackTrace();
			throw new EJBException(ex.getMessage());
		}
	}

	public MusicPageBean() {}
	public void ejbRemove() {}
	public void ejbActivate() {}
	public void ejbPassivate() {}
	public void setSessionContext(SessionContext sc) {}

} // MusicPageBean
