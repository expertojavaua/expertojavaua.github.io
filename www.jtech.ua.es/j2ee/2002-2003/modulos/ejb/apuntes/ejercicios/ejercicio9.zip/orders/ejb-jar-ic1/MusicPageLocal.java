// MusicPageLocal.java
import javax.ejb.EJBLocalObject;
import java.util.*;

public interface MusicPageLocal extends EJBLocalObject {
 
   public ArrayList getTrackList(RecordingVO rec) 
			throws NoTrackListException;
	public int getSize();
	public ArrayList getPage(int currentIndex, int pageSize);

}
