// MusicPageLocalHome.java
import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;

public interface MusicPageLocalHome extends EJBLocalHome {

    MusicPageLocal create() throws CreateException;
}
