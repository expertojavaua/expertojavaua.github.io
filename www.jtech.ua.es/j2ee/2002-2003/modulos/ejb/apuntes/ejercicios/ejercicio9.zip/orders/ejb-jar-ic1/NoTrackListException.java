// NoTrackListException.java
// Application Exception
public class NoTrackListException extends Exception {

   public NoTrackListException() { }

   public NoTrackListException(String msg) {
      super(msg);
   }
}
