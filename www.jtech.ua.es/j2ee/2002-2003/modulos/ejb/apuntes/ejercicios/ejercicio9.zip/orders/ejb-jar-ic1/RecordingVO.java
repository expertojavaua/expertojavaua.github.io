// RecordingVO.java

	public class RecordingVO implements java.io.Serializable
	{
		private int recordID;
		private String title;
		private String artistName;
		private String musicCategory;
		private String label;
		private int numberOfTracks;

		public RecordingVO( int recordID, String title, String artistName,
			String musicCategory, String label, int numberOfTracks)
		{
			this.recordID = recordID;
			this.title = title;
			this.artistName = artistName;
			this.musicCategory = musicCategory;
			this.label = label;
			this.numberOfTracks = numberOfTracks;
		}

		public int getRecordID() { return recordID; }
		public String getTitle() { return title; }
		public String getArtistName() { return artistName; }
		public String getMusicCategory() { return musicCategory; }
		public String getLabel() { return label; }
		public int getNumberOfTracks() { return numberOfTracks; }

		// Implement equals; convenient way to determine if
		// 2 RecordingVO objects represent the same recording.
		// Used by Java Collection classes to indicate successful
		// removal from Collection.
		public boolean equals(Object rec) {
			return (recordID == ((RecordingVO)rec).recordID);
		}
}
