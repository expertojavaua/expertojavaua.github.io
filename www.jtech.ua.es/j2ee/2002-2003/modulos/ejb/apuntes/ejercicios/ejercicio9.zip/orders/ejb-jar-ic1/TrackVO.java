// TrackVO.java
public class TrackVO implements java.io.Serializable
{
   private int trackNumber;
   private String title;
   private String trackLength;

   public TrackVO(
      int trackNumber,
      String title, 
      String trackLength) {
         this.trackNumber = trackNumber;
         this.title = title;
         this.trackLength = trackLength;
    }

    public String getTitle() { return title; }
    public String getTrackLength() { return trackLength; }
    public int getTrackNumber() { return trackNumber; }
}
