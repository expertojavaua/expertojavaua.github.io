// ValueListIterator.java
import java.rmi.RemoteException;
import java.util.*;

public interface ValueListIterator {

	static final int defaultPageSize = 10;
	
	public int getSize() throws RemoteException;
	public int setPageSize(int numberOfElements) throws RemoteException;
	public int getPageSize() throws RemoteException;
	public ArrayList previousPage() throws RemoteException;
	public ArrayList nextPage() throws RemoteException;
	public void resetIndex() throws RemoteException;
	public boolean hasMoreElements() throws RemoteException;
	public boolean hasPreviousElements()throws RemoteException;

} // ValueListIterator
