// MusicCart.java
import javax.ejb.EJBObject;
import java.rmi.RemoteException;
import java.util.*;

public interface MusicCart extends EJBObject {
 
   public void addRecording(RecordingVO album) throws RemoteException;
   public void removeRecording(RecordingVO album) throws ShoppingException,
   				RemoteException;
	public void clearShoppingList() throws RemoteException;
   public ArrayList getShoppingList() throws RemoteException;
	public CustomerVO getCustomer() throws RemoteException;
}
