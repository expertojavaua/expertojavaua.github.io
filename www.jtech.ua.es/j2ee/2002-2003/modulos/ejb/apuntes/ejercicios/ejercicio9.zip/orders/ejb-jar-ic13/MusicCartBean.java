// MusicCartBean.java
import javax.ejb.*;
import javax.naming.*;
import java.rmi.RemoteException; 
import java.util.*;

public class MusicCartBean implements SessionBean {
	
	// EJB state variables
	CustomerVO customer;
	ArrayList shoppingList;
   
	// create() methods implmentation
	// from the EJBHome interface
	// Methods ejbCreate() should initialize the
	// state variables

	public void ejbCreate(String person) throws CreateException {
		if (person == null || person.equals("")) {
			throw new CreateException("Name cannot be null or empty.");
		}
		else {
			customer = new CustomerVO(person, "NoPassword", "NoEmail");
		}
		shoppingList = new ArrayList();
	}

	// Implementation for create(CustomerVO cust)
	public void ejbCreate(CustomerVO cust) throws CreateException {
		if (cust.getName() == null) {
			throw new CreateException("Name cannot be null.");
		}
		if (cust.getPassword() == null || cust.getPassword().equals("")) {
			throw new CreateException("Password cannot be null or empty.");
		}
		if (cust.getEmail() == null || cust.getEmail().equals("")) {
			throw new CreateException("Email cannot be null or empty.");
		}
		customer = cust;
		shoppingList = new ArrayList();
	}

	// Business methods implementation

	public CustomerVO getCustomer() {
		return customer;
	}

	public void addRecording(RecordingVO album) {
		shoppingList.add(album);
	}

	// ShoppingException is an application exception
	public void removeRecording(RecordingVO album) throws ShoppingException 
	{
		if (shoppingList.contains(album)) {
			shoppingList.remove(shoppingList.indexOf(album));
		}
		else {
			throw new ShoppingException(album.getTitle() + " not in cart.");
		}
	}

	// clear the shopping list
	public void clearShoppingList() {
		shoppingList.clear();
	}

	public ArrayList getShoppingList() {
		return shoppingList;
	}

	// EJB Methods
	public MusicCartBean() {}
	public void ejbRemove() {}
	public void ejbActivate() {}
	public void ejbPassivate() {}
	public void setSessionContext(SessionContext sc) {}

} // MusicCartBean
