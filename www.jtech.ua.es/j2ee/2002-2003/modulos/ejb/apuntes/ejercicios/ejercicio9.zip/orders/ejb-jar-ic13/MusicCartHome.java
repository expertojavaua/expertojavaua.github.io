// MusicCartHome.java
import java.io.Serializable;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;

public interface MusicCartHome extends EJBHome {

	MusicCart create(String person) throws 
		RemoteException, CreateException;
	MusicCart create(CustomerVO customer) throws 
		RemoteException, CreateException;
}
