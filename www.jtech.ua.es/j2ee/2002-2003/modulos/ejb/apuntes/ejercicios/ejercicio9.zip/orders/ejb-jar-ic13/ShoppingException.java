// ShoppingException.java

public class ShoppingException extends Exception {

   public ShoppingException() { }

   public ShoppingException(String msg) {
      super(msg);
   }
}
