drop table Tracks;
drop table Recordings;
drop table "Music Categories";
drop table "Recording Artists";

create table "Music Categories"
(MusicCategoryID integer constraint pk_MusicCategoryID primary key,
MusicCategory varchar(20));

create table "Recording Artists"
(RecordingArtistID integer constraint pk_RecordingArtistID primary key,
RecordingArtistName varchar(36),
Notes varchar(200));

create table Recordings
(RecordingID integer constraint pk_RecordingID primary key,
RecordingTitle varchar(50),
RecordingArtistID integer,
MusicCategoryID integer,
RecordingLabel varchar(36),
Format varchar(20),
NumberofTracks smallint,
Notes varchar(200),
constraint fk_RecordingArtistID
foreign key (RecordingArtistID)
references "Recording Artists"(RecordingArtistID),
constraint fk_MusicCategoryID
foreign key (MusicCategoryID)
references "Music Categories"(MusicCategoryID));

create table Tracks
(TrackID integer constraint pk_TrackID primary key,
TrackNumber smallint,
TrackTitle varchar(100),
TrackLength varchar(10),
RecordingID integer,
constraint fk_RecordingID
foreign key (RecordingID)
references Recordings(RecordingID));


insert into "Recording Artists"
values (1, 'The Philadelphia Orchestra', '');
insert into "Recording Artists"
values (2, 'Indigo Girls', '');
insert into "Recording Artists"
values (3, 'John Lennon', '');
insert into "Recording Artists"
values (4, 'Karla Bonoff', '');
insert into "Recording Artists"
values (5, 'Paul Simon', '');
insert into "Recording Artists"
values (6, 'Gin Blossoms', '');
insert into "Recording Artists"
values (8, 'Steely Dan', '');
insert into "Recording Artists"
values (9, 'It''s a Beautiful Day', '');
insert into "Recording Artists"
values (7, 'Beatles', '');

insert into "Music Categories"
values (1, 'Classical');
insert into "Music Categories"
values (2, 'Rock');
insert into "Music Categories"
values (3, 'Jazz');
insert into "Music Categories"
values (4, 'Rap');
insert into "Music Categories"
values (5, 'Country');
insert into "Music Categories"
values (6, 'Musical Theatre');
insert into "Music Categories"
values (7, 'Blues');

insert into Recordings
values (1, 'Orff: Carmina Burana', 1, 1, 'Sony Classical', '', 11, '');
insert into Recordings
values (2, 'Rites of Passage', 2, 2, 'Epic', '', 13, '');
insert into Recordings
values (3, 'Imagine', 3, 2, 'Warner Brothers', '', 21, '');
insert into Recordings
values (4, 'Karla Bonoff', 4, 2, 'Columbia', '', 10, '');
insert into Recordings
values (5, 'Graceland', 5, 2, 'Warner Brothers', '', 11, '');
insert into Recordings
values (6, 'Congratulations I''m Sorry', 6, 2, 'A&M Records', '', 13, '');
insert into Recordings
values (7, 'Sgt. Pepper''s Lonely Hearts Club Band', 
7, 2, 'EMI Records', '', 12, '');

insert into Tracks
values (1, 1, 'O Fortuna', '2:44', 1); 
insert into Tracks
values (2, 2, 'Fortune plango vulnera', '2:39', 1); 
insert into Tracks
values (3, 3, 'Veris leta facies', '3:26', 1); 
insert into Tracks
values (4, 4, 'Omnia Sol temperat', '1:47', 1); 
insert into Tracks
values (5, 5, 'Ecce gratum', '2:35', 1); 
insert into Tracks
values (6, 6, 'Tanz', '1:36', 1); 
insert into Tracks
values (7, 7, 'Floret silva', '3:15', 1); 
insert into Tracks
values (8, 8, 'Chramet, gip die varwe mir', '3:11', 1); 
insert into Tracks
values (9, 9, 'Reie', '1:49', 1); 
insert into Tracks
values (10, 10, 'Swazhie get umbe', '2:31', 1); 
insert into Tracks
values (11, 11, 'Were deu werlt alle min', '0:55', 1); 

insert into Tracks
values (12, 1, 'Three Hits', '', 2); 
insert into Tracks
values (13, 2, 'Galileo', '', 2); 
insert into Tracks
values (14, 3, 'Ghost', '', 2); 
insert into Tracks
values (15, 4, 'Joking', '', 2); 
insert into Tracks
values (16, 5, 'Jonas & Ezekial', '', 2); 
insert into Tracks
values (17, 6, 'Love Will Come To You', '', 2); 
insert into Tracks
values (18, 7, 'Romeo and Juliet', '', 2); 
insert into Tracks
values (19, 8, 'Virginia Woolf', '', 2); 
insert into Tracks
values (20, 9, 'Chickenman', '', 2); 
insert into Tracks
values (21, 10, 'Airplane', '', 2); 
insert into Tracks
values (22, 11, 'Nashville', '', 2); 
insert into Tracks
values (23, 12, 'Let It Be Me', '', 2); 
insert into Tracks
values (24, 13, 'Cedar Tree', '', 2); 

insert into Tracks
values (25, 1, 'Real Love', '2:30', 3); 
insert into Tracks
values (26, 2, 'Twist and Shout', '2:32', 3); 
insert into Tracks
values (27, 3, 'Help', '2:17', 3); 
insert into Tracks
values (28, 4, 'In My Life', '2:25', 3); 
insert into Tracks
values (29, 5, 'Strawberry Fields Forever', '4:06', 3); 
insert into Tracks
values (30, 6, 'A Day in the Life', '5:00', 3); 
insert into Tracks
values (31, 7, 'Revolution', '3:21', 3); 
insert into Tracks
values (32, 8, 'The Ballad of John & Yoko', '2:58', 3); 
insert into Tracks
values (33, 9, 'Julia', '2:57', 3); 
insert into Tracks
values (34, 10, 'Don''t Let Me Down', '3:30', 3); 
insert into Tracks
values (35, 11, 'Give Peace A Chance', '3:30', 3); 
insert into Tracks
values (36, 12, 'How?', '3:37', 3); 
insert into Tracks
values (37, 13, 'Imagine (Rehearsal)', '1:26', 3); 
insert into Tracks
values (38, 14, 'God', '4:04', 3); 
insert into Tracks
values (39, 15, 'Mother', '5:15', 3); 
insert into Tracks
values (40, 16, 'Stand By Me', '3:30', 3); 
insert into Tracks
values (41, 17, 'Jealous Guy', '4:10', 3); 
insert into Tracks
values (42, 18, 'Woman', '3:32', 3); 
insert into Tracks
values (43, 19, 'Beautiful Boy', '3:54', 3); 
insert into Tracks
values (44, 20, '(Just Like) Starting Over', '4:05', 3); 
insert into Tracks
values (45, 21, 'Imagine', '3:00', 3); 


insert into Tracks
values (46, 6, 'Isn''t It Always Love', '3:06', 4); 
insert into Tracks
values (47, 7, 'If He''s Ever Near', '3:15', 4); 
insert into Tracks
values (48, 8, 'Flying High', '3:27', 4); 
insert into Tracks
values (49, 9, 'Falling Star', '4:27', 4); 
insert into Tracks
values (50, 10, 'Rose In My Garden', '4:44', 4); 
insert into Tracks
values (51, 1, 'Someone To Lay Down Beside Me', '4:03', 4); 
insert into Tracks
values (52, 2, 'I Can''t Hold On', '3:42', 4); 
insert into Tracks
values (53, 3, 'Lose Again', '3:40', 4); 
insert into Tracks
values (54, 5, 'Faces In The Wind', '3:04', 4); 
insert into Tracks
values (55, 4, 'Home', '4:17', 4); 

insert into Tracks
values (56, 3, 'I Know What I Know', '3:13', 5); 
insert into Tracks
values (57, 4, 'Gumboots', '2:42', 5); 
insert into Tracks
values (58, 5, 'Diamonds On The Soles Of Her Feet', '5:34', 5); 
insert into Tracks
values (59, 6, 'You Can Call Me Al', '4:39', 5); 
insert into Tracks
values (60, 7, 'Under African Skies', '3:34', 5); 
insert into Tracks
values (61, 8, 'Homeless', '3:45', 5); 
insert into Tracks
values (62, 9, 'Crazy Love Vol. II', '4:17', 5); 
insert into Tracks
values (63, 10, 'That Was Your Mother', '2:51', 5); 
insert into Tracks
values (64, 11, 'All Around The World or The Myth of FingerPrints', '3:15', 5); 
insert into Tracks
values (65, 1, 'The  Boy  in the Bubble', '3:59', 5); 
insert into Tracks
values (66, 2, 'Graceland', '4:48', 5); 


insert into Tracks
values (67, 3, 'Follow You Down', '4:30', 6); 
insert into Tracks
values (68, 4, 'Not Only Numb', '3:06', 6); 
insert into Tracks
values (69, 5, 'As Long As It Matters', '4:31', 6); 
insert into Tracks
values (70, 6, 'Perfectly Still', '4:05', 6); 
insert into Tracks
values (71, 7, '7TH Inning Stretch', '0:14', 6); 
insert into Tracks
values (72, 8, 'My Car', '4:17', 6); 
insert into Tracks
values (73, 9, 'Virginia', '4:02', 6); 
insert into Tracks
values (74, 10, 'Whitewash', '3:19', 6); 
insert into Tracks
values (75, 11, 'I Can''t Figure You Out', '3:13', 6); 
insert into Tracks
values (76, 12, 'Memphis Time', '3:14', 6); 
insert into Tracks
values (77, 13, 'Competition Smile', '3:38', 6); 
insert into Tracks
values (78, 1, 'Day Job', '3:52', 6); 
insert into Tracks
values (79, 2, 'Highwire', '2:24', 6); 


insert into Tracks
values (80, 3, 'Lucy In The Sky With Diamonds', '', 7); 
insert into Tracks
values (81, 4, 'Getting Better', '', 7); 
insert into Tracks
values (82, 5, 'Fixing A Hole', '', 7); 
insert into Tracks
values (83, 6, 'She''s Leaving Home', '', 7); 
insert into Tracks
values (84, 7, 'Being For The Benefit Of Mr. Kite!', '', 7); 
insert into Tracks
values (85, 9, 'When I''m Sixty-Four', '', 7); 
insert into Tracks
values (86, 8, 'Within You Without You', '', 7); 
insert into Tracks
values (87, 10, 'Lovely Rita', '', 7); 
insert into Tracks
values (91, 11, 'Sgt. Pepper''s Lonely Hearts Club Band (Reprise)', '', 7); 
insert into Tracks
values (88, 12, 'A Day In The Life', '', 7); 
insert into Tracks
values (89, 1, 'Sgt. Pepper''s Lonely Hearts Club Band', '', 7); 
insert into Tracks
values (90, 2, 'With a Little Help From My Friends', '', 7); 


exit;
