package roomBooking;

import java.awt.*;
import roomBooking.RoomPackage.*;

public class ClientApplet
    extends java.applet.Applet 
{
    private RoomBookingClient client;

    /** override init method of Class Applet */
    public void init() 
    {
        // create a RoomBookingClient client -
        // using the applet constructor
        client = new RoomBookingClient( this );

        // initialiase the GUI
        client.init_GUI( this );

        // initialise the Naming Service
        client.init_from_ns();

        // view existing bookings
        client.view();
    }
}
