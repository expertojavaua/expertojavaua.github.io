package roomBooking;

import org.omg.CORBA.*;

/**
 * MeetingFactoryImpl.java
 *
 * @author Gerald Brose, Andreas Vogel, Keith Duddy
 *
 * (C) John Wiley, Inc. 2000
 */

class MeetingFactoryImpl 
    extends MeetingFactoryPOA 
{
//      // constructor
//      MeetingFactoryImpl(ORB orb) 
//      {
//  	this.orb = orb;	
//      }
  
    // method
    public Meeting createMeeting(String purpose, String participants ) 
    {
        MeetingImpl meetingImpl = new MeetingImpl(purpose, participants);
	try
	{
	    org.omg.CORBA.Object obj = _poa().servant_to_reference(meetingImpl);
	    Meeting meeting = MeetingHelper.narrow(obj);
	    return meeting; 
	}
	catch( SystemException se )
	{
	}
	catch( UserException ue )
	{}
	return null;
    }
}
