package roomBooking;

import java.io.*;
import org.omg.CORBA.*;
import org.omg.PortableServer.*;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;

public class MeetingFactoryServer 
{

    public static void main(String[] args) 
    {
        String str_name, context_name;

       // if( args.length != 0 ) {
       //	    System.out.println("Usage: java MeetingFactoryServer");
       //	    System.exit( 1 );
       //	}

	// the stringified names we want to use
	context_name = "BuildingApplications";
        str_name = context_name + "/MeetingFactory";

        try {
	    //initialise ORB
	    ORB orb = ORB.init( args, null );

            // initialise and activate POA
	    POA poa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
	    poa.the_POAManager().activate();

	    // create the MeetingFactory object
	    MeetingFactoryImpl meeting_factory = new MeetingFactoryImpl();

	    // export the object reference
	    org.omg.CORBA.Object meeting_factory_obj = 
		poa.servant_to_reference(meeting_factory);

            // register with the CORBA Naming Service
	    NamingContextExt root = 
		NamingContextExtHelper.narrow( 
			 orb.resolve_initial_references("NameService")
			 );

	    try
	    {
		// make sure our context exists, if the 
		// name server has been running for a while
		// someone may have already set up the context earlier
		root.bind_new_context( root.to_name( context_name ));
	    }
	    catch( AlreadyBound ab )
	    { 
		// ok, we ignore that
	    }

	    // bind our new meeting factory
	    try
	    {
		root.bind( root.to_name(str_name), meeting_factory_obj );
	    }
	    catch( AlreadyBound ab )
	    { 
		System.err.println("A meeting factory is already bound, exiting...");
		System.exit(1);
	    }
	    // enter event loop
	    orb.run();
        }
	catch(Exception e) 
	{
	    e.printStackTrace();
        }
    }
}
