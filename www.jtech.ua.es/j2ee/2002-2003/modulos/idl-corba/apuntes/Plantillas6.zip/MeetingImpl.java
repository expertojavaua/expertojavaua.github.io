package roomBooking;

import org.omg.CORBA.*;

/**
 * MeetingImpl.java
 *
 * @author Gerald Brose, Andreas Vogel, Keith Duddy
 *
 * (C) John Wiley, Inc. 2000
 */

class MeetingImpl 
    extends MeetingPOA {

    private String purpose;
    private String participants;

    /** constructor */

    MeetingImpl( String purpose, String participants) 
    {
	// initialise private variables
	this.purpose = purpose;
	this.participants = participants;
    }
  
    // attributes
    public String purpose() {
	return purpose;
    }

    public String participants() {
	return participants;
    }

    /** deactivates the object */
    public void destroy() 
    {
	try
	{
	    _poa().deactivate_object( _poa().servant_to_id(this));
	}
	catch( Exception e )
	{
	    // ignore
	}
    }
}
