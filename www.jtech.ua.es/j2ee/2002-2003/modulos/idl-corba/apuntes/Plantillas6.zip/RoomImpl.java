package roomBooking;

/**
 * RoomImpl.java
 */

import org.omg.CORBA.*;
import roomBooking.RoomPackage.*;

public class RoomImpl 
    extends RoomPOA 
{

    private String name;
    private Meeting[] meetings;

    // constructor
    public RoomImpl( String name ) 
    {
        this.name = name;
        meetings = new Meeting[ Room.MaxSlots ];
    }
    
    // attributes
    public String name() 
    {
        return name; 
    }
        
    // operations
    public Meeting[] view() 
    {
        return meetings;
    }

    public void book( Slot slot,
                      Meeting meeting )
        throws SlotAlreadyTaken 
    {
 
        if( meetings[ slot.value() ] == null ) 
        {
            meetings[ slot.value() ] = meeting;
        }
        else 
        {
            throw new SlotAlreadyTaken();
        }        
        return;
    }

    public void cancelBooking( Slot slot )
        throws NoMeetingInThisSlot 
    {

        System.err.println("cancel " + slot );
        if( meetings[slot.value()] != null  ) {
            meetings[slot.value()].destroy();
            meetings[slot.value()] = null;
        }
        else 
        {
            throw new NoMeetingInThisSlot();
        }
    }
}
