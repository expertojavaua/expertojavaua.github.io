package roomBooking;

import java.io.*;
import org.omg.CORBA.*;
import org.omg.PortableServer.*;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;
import roomBooking.*;

public class RoomServer 
{
    public static void main(String[] args) 
    {
        String context_name, str_name;

//        if( args.length != 1 ) {
//            System.out.println("Usage: vbj com.wiley.compbooks.brose.chapter8.roomBookingImpl.RoomServer room_name");
//            System.exit( 1 );
//	}

        context_name = new String("BuildingApplications/Rooms");

        try {
	    //init
	    ORB orb = ORB.init( args, null );
	    POA poa = POAHelper.narrow( orb.resolve_initial_references( "RootPOA"));
	    poa.the_POAManager().activate();

	    // create the Room object and
	    // export the object reference
	    org.omg.CORBA.Object room_obj = 
		poa.servant_to_reference( new RoomImpl( args[0] ) );

            // register with naming service
            str_name = context_name + "/" + args[0];

	    NamingContextExt root = 
		NamingContextExtHelper.narrow( 
			 orb.resolve_initial_references("NameService")
			 );

	    try
	    {
		// make sure the "rooms" context is  bound
		root.bind_new_context( root.to_name( context_name ));
	    }
	    catch( AlreadyBound ab )
	    { 
		// does not matter .
	    }
	    catch( NotFound nf )
	    {
                System.err.println("Context " + context_name + " not found, start MeetingFactoryServer first.");
                System.err.println("exiting ...");
            }

            root.bind( root.to_name( str_name), room_obj );

	    // wait for requests
	    orb.run();
        }
	catch( AlreadyBound already_bound ) {
	    System.err.println("Room " + context_name + args[0] +
                " already bound.");
	    System.err.println("exiting ...");
        }
	catch(UserException ue) {
            ue.printStackTrace();
        }
	catch(SystemException se) {
	    System.err.println(se);
        }
    }
}
