import java.io.*;
import java.net.*;
import chat.*;
import es.*;
import usuarios.*;

/**
  * Ejemplo de chat
  */
public class EjemploChat implements Runnable 
{
	/* Cliente de chat */
	ClienteChat chat;

	/* Elemento para gestionar la entrada desde teclado */
	EntradaConsola in;

	/* Hilo para recibir mensajes del servidor */
	Thread t;

	/* Constructor
	   - ip: IP del servidor al que conectar
	 */
	public EjemploChat(String ip) 
	{
		try {
			chat = new ClienteChat(ip);
		} catch(UnknownHostException e1) {
			System.out.println("Host desconocido");
			System.exit(1);
		} catch(IOException e2) {
			System.out.println("Error al conectar con el servidor");
			System.exit(1);
		}

		in = new EntradaConsola();

		menu();
	}

	/* Funcion principal del hilo */
	public void run() 
	{
		String msg = null;

		// Recibe los mensajes del servidor

		try {
			while( (msg=chat.recibeMensaje()) != null ) 
			{
				System.out.println(msg);
			}
		} catch(IOException e) {
			System.err.println("Error en la E/S");
			System.exit(1);
		}
	}

	/* Funcion para chatear */
	private void chat() 
	{
		String msg = null;

		// Inicia el hilo para recibir mensajes del servidor

		t = new Thread(this);
		t.start();

		// Bucle para enviar mensajes al servidor

		while( (msg=in.readLine()) != null ) 
		{
			chat.enviaMensaje(msg);
		}
	}

	/* Funcion para mostrar el menu principal */
	private void menu() 
	{
		String texto = "Elija una opcion:\n" + 
				"\t1. Entrar al chat\n" +
				"\t2. Registrar nuevo usuario\n" +
				"\t0. Salir\n";
		String resp;

		resp = in.promptLine(texto);

		if(resp.trim().equals("1")) {
			entrar();
		} else if(resp.trim().equals("2")) {
			registrar();
		} else if(resp.trim().equals("0")) {
			System.exit(0);
		} else {
			menu();
		}

	}

	/* Funcion para entrar al chat */
	private void entrar() 
	{
		// Toma el login y password del usuario

		String login = in.promptLine("Login: ");
		String password = in.promptLine("Password: ");

		// Trata de validar los datos. Si no puede vuelve a mostrar el menu

		try {
			chat.loginUsuario(login, password);
		} catch(LoginInvalidoException e1) {
			System.err.println(e1.getMessage());
			menu();
			return;
		} catch(IOException e2) {
			System.err.println("Error en la E/S");
			System.exit(1);
		}

		chat();
	}

	/* Funcion para registrar los datos de un nuevo usuario */
	private void registrar() 
	{
		// Toma los datos del usuario

		String login = in.promptLine("Login: ");
		String password = in.promptLine("Password: ");

		// Trata de registrar los datos. Si hay error lanza una excepcion

		try {
			chat.registraUsuario(login, password);
		} catch(LoginInvalidoException e1) {
			System.err.println(e1.getMessage());
		} catch(IOException e2) {
			System.err.println("Error en la E/S");
		}

		menu();
	}

	/* Funcion principal */
	public static void main(String [] args) 
	{
		if(args.length != 1) {
			System.err.println("Uso: java EjemploChat ip_servidor");
			System.exit(1);
		}

		new EjemploChat(args[0]);
	}
}
