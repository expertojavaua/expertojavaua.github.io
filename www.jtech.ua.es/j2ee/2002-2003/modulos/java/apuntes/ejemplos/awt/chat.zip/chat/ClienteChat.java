package chat;

import java.io.*;
import java.net.*;
import usuarios.*;
import es.*;

/**
  * Ejemplo de cliente de chat
  */
public class ClienteChat 
{
	/* Socket para conectar con el servidor */
	ConexionSocket socket;

	/* Constructor. Conecta con la IP dada 
	   - ip: IP del servidor al que conectar
	 */	
	public ClienteChat(String ip) throws UnknownHostException, IOException 
	{
		socket = new ConexionSocket(ip, ServidorChat.PUERTO_CHAT);
	}

	/* Recibe un mensaje del servidor
	   Devuelve el mensaje recibido
	 */	
	public String recibeMensaje() throws IOException 
	{
		return socket.recibe();
	}

	/* Envia un mensaje al servidor
	   - mensaje: Mensaje que se envia al servidor
	 */	
	public void enviaMensaje(String mensaje) 
	{
		socket.envia(mensaje);
	}

	/* Registra un nuevo usuario de chat
	   - login: Login del nuevo usuario
	   - password: Password del nuevo usuario
	   Lanza una LoginInvalidoException si el login esta repetido
	 */	
	public void registraUsuario(String login, String password) throws LoginInvalidoException, IOException 
	{
		// Envia al servidor los datos del registro
		socket.envia(ServidorChat.CMD_REG);
		socket.envia(login);
		socket.envia(password);

		// Recibe la respuesta. Si hay error lanza la excepcion
		String res = socket.recibe();
		if(res.equals(ServidorChat.RES_ERROR)) 
		{
			res = socket.recibe();
			throw new LoginInvalidoException(res);
		}
	}

	/* Valida los datos de un usuario registrado que quiere chatear
	   - login: Login del usuario
	   - password: Password del usuario
	   Lanza una LoginInvalidoException si el login no es correcto
	 */	
	public void loginUsuario(String login, String password) throws LoginInvalidoException, IOException 
	{
		// Envia los datos de validacion
		socket.envia(ServidorChat.CMD_LOGIN);
		socket.envia(login);
		socket.envia(password);

		// Obtiene la respuesta. Si hay error lanza la excepcion
		String res = socket.recibe();
		if(res.equals(ServidorChat.RES_ERROR)) 
		{
			res = socket.recibe();
			throw new LoginInvalidoException(res);
		}
	}

}
