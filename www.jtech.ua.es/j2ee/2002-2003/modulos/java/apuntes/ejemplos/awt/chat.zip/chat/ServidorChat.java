package chat;

import java.io.*;
import java.net.*;
import java.util.Vector;
import usuarios.*;
import es.*;

/**
  * Ejemplo de servidor chat
  */
public class ServidorChat 
{
	/* Comando para validar un usuario registrado */
	public static final String CMD_LOGIN = "LOGIN";

	/* Comando para registrar un nuevo usuario */
	public static final String CMD_REG = "REG";

	/* Respuesta OK */
	public static final String RES_OK = "OK";

	/* Respuesta de ERROR */
	public static final String RES_ERROR = "ERROR";

	/* Fichero para gestion de usuarios */
	public static final String FICHERO_USUARIOS = "datos" + File.separator + "usuarios";

	/* Puerto por el que conectar con el servidor */
	public static final int PUERTO_CHAT = 4444;


	/* Conexiones abiertas de clientes */
	private Vector conexiones;

	/* Sistema para gestion de los datos de los usuarios */
	private AccesoUsuarios usuarios;

	/* Constructor 
	 */
	public ServidorChat() 
	{
		// Inicializa las conexiones y el sistema de gestion de usuarios
		conexiones = new Vector();
		usuarios = new AccesoFicheroUsuarios(FICHERO_USUARIOS);

		// Inicializa el servidor
		try 
		{
			ServerSocket server_socket = new ServerSocket(PUERTO_CHAT);
			Socket sock;
			Thread t;

			while(true) 
			{
				sock = server_socket.accept();

				t = new HiloServidor(sock);
				t.start();
			}

		} catch(IOException e2) {
			System.err.println("Error en la E/S");
			System.exit(1);
		}

	}

	/* Envia un mensaje a todos los clientes conectados
	   - mgs: Mensaje que se difunde
	 */
	public void difunde(String msg) 
	{
		HiloServidor hs = null;

		// Va recorriendo todas las conexiones y enviando el mensaje por cada una
		for(int i=0;i<conexiones.size();i++) 
		{
			hs = (HiloServidor)conexiones.elementAt(i);
			hs.envia(msg);
		}
	}

	/* A�ade un nuevo cliente a la lista de conexiones
	   - hs: Hilo que trata la conexion del cliente
	 */
	public void agregaCliente(HiloServidor hs) 
	{
		conexiones.addElement(hs);
	}

	/* Elimina un cliente de la lista de conexiones
	   - hs: Hilo que trata la conexion del cliente
	 */
	public void eliminaCliente(HiloServidor hs) 
	{
		conexiones.removeElement(hs);
	}

	/* Funcion principal */
	public static void main(String [] args) 
	{
		new ServidorChat();
	}

	/**
	  * Esta clase se emplea para gestionar cada conexion de un cliente
	  * con el servidor
	  */
	class HiloServidor extends Thread 
	{
		/* Conexion */
		ConexionSocket socket;

		/* Nick del cliente */
		String nick;

		/* Constructor
	   	   - sock: Socket con el que conectar
	 	*/		
		public HiloServidor(Socket sock) throws IOException 
		{
			socket = new ConexionSocket(sock);
		}

		/* Funcion principal del hilo */
		public void run() 
		{
			String msg = null;

			// A�ade el usuario al chat

			try 
			{
				nick = registroUsuario();
				if(nick == null) 
					return;
			} catch(Exception e1) {
				return;
			}

			agregaCliente(this);
			System.out.println("Conectado <" + nick + ">");

			// Difunde a todos los usuarios los mensajes que reciba de este

			try 
			{
				while( (msg = socket.recibe()) != null) 
				{
					difunde("<" + nick + "> " + msg);
				}
			} catch(Exception e2) {
			} finally {
				eliminaCliente(this);
				System.out.println("Desconectado <" + nick + ">");
			}
		}

		/* Registra los datos de un usuario
		 */
		private String registroUsuario() throws IOException 
		{
			// Datos que se reciben del cliente
			String login, password, msg;

			while(true)
			{
				msg = socket.recibe();

				if(msg==null)
					return null;

				// Validar los datos de un usuario existente

				if(msg.equals(CMD_LOGIN)) {
					login = socket.recibe();
					password = socket.recibe();
	
					if(usuarios.valida(login,password)) {
						socket.envia(RES_OK);
						return login;
					} else {
						socket.envia(RES_ERROR);
						socket.envia("Login y password no validos");
					}

				// Registrar un nuevo usuario
	
				} else if(msg.equals(CMD_REG)) {
					login = socket.recibe();
					password = socket.recibe();
	
					try {
						usuarios.registra(login,password);
						socket.envia(RES_OK);
					} catch(LoginInvalidoException e) {
						socket.envia(RES_ERROR);
						socket.envia(e.getMessage());
					}
				}
			}
		}

		/* Envia un mensaje al cliente asociado
		   - msg: Mensaje que se envia al cliente
		 */
		public void envia(String msg) 
		{
			socket.envia(msg);
		}
	}
}
