javac EjemploChat.java
javac usuarios/*.java
javac es/*.java
javac chat/*.java