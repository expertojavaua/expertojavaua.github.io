package es;

import java.io.*;
import java.net.*;

/**
  * Esta clase permite establecer una conexion mediante sockets
  */
public class ConexionSocket 
{
	/* Socket para la conexion */
	Socket socket;

	/* Canal de salida (para enviar datos) */
	PrintStream out;

	/* Canal de entrada (para recibir datos) */
	BufferedReader in;

	/* Establece una conexion
	   - host: Direccion del servidor
	   - puerto: Puerto por el que conectar
	 */
	public ConexionSocket(String host, int puerto) throws UnknownHostException, IOException 
	{
		// Conecta
		socket = new Socket(host, puerto);

		// Obtiene los canales de entrada y salida de datos
		in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		out = new PrintStream(socket.getOutputStream());
	}

	/* Establece una conexion
	   - socket: Socket con el que conectar
	 */
	public ConexionSocket(Socket socket) throws IOException 
	{
		this.socket = socket;

		in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		out = new PrintStream(socket.getOutputStream());
	}

	/* Envia datos por el canal de salida
	   - datos: Cadena que se envia por el canal de salida
	 */
	public void envia(String datos)
	{
		out.println(datos);
	}

	/* Recibe una cadena de datos por el canal de entrada
	 */
	public String recibe() throws IOException
	{
		return in.readLine();
	}
}
