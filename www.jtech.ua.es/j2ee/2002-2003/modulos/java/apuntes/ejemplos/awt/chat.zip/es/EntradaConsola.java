package es;

import java.io.*;

/**
  * Esta clase se emplea para leer de la consola los datos que se
  * escriban
  */
public class EntradaConsola 
{
	/* Canal de entrada (consola) */
	BufferedReader in;

	/* Constructor. Inicializa el canal de entrada a la entrada estandar 
	*/
	public EntradaConsola() 
	{
		in = new BufferedReader( new InputStreamReader( System.in ) );
	}

	/* Muestra un mensaje por la salida estandar
	   - message: Mensaje que se muestra
	   Devuelve la respuesta al mensaje (introducida por el usuario)
	 */
	public String promptLine(String message) 
	{
		System.out.print(message);
		return readLine();
	}

	/* Lee una linea de la entrada estandar
	   Devuelve la linea leida
	 */
	public String readLine() 
	{
		try {
			return in.readLine();
		} catch(IOException e) {
			return null;
		}
	}
}