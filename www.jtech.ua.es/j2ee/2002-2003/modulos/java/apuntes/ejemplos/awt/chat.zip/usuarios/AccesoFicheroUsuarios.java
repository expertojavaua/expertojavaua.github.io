package usuarios;

import java.io.*;
import java.util.*;

/**
  * Esta clase implementa la interfaz AccesoUsuarios para gestionar
  * los usuarios del chat mediante ficheros
  */
public class AccesoFicheroUsuarios implements AccesoUsuarios 
{
	/* Caracter para separar los datos de cada usuario */
	private final static char SEPARADOR = ':';

	/* Nombre del fichero donde leer/escribir los datos de los usuarios */
	String filename;

	/* Lista de usuarios leida del fichero */
	Vector listaUsuarios;

	/* Constructor. Lee los usuarios del fichero que se le pasa
	   - filename: Fichero del que leer los usuarios
	 */
	public AccesoFicheroUsuarios(String filename) 
	{
		this.filename = filename;

		listaUsuarios = leeFichero(filename);
	}

	/* Valida que los datos del usuario son correctos
	   - login: login del usuario que quiere entrar
	   - password: password del usuario
	 */
	public boolean valida(String login, String password) 
	{
		Usuario aux = busca(login);

		if(aux != null) 
		{
			if( aux.password.equals(password) ) 
			{
				return true;
			}
		}

		return false;
	}

	/* Registra un nuevo usuario en la base de datos
	   - login: login del usuario
	   - password: password del usuario
	   Lanza una excepcion si el login esta repetido
	 */
	public void registra(String login, String password) throws LoginInvalidoException 
	{
		Usuario aux = busca(login);

		if(aux!=null) 
		{
			throw new LoginInvalidoException("El usuario " + 
						aux.login + " ya esta registrado");
		}
		if(login.trim().equals("")) {
			throw new LoginInvalidoException("El login no puede estar vacio");
		}

		aux = new Usuario(login, password);
		listaUsuarios.addElement(aux);
		escribeFichero(filename, listaUsuarios);
	}

	/* Busca un usuario en la lista de usuarios
	   - login: Login del usuario que se busca
	   Devuelve los datos del usuario, o null si no lo encuentra
	 */	 
	private Usuario busca(String login) 
	{
		Usuario aux = null;

		for(int i=0;i<listaUsuarios.size();i++) 
		{
			aux = (Usuario)listaUsuarios.elementAt(i);

			if( aux.login.equals(login) )
			{
				return aux;
			}
		}

		return null;		
	}

	/* Lee los usuarios del fichero
	   - filename: Fichero del que leer los usuarios
	   Devuelve un vector con los usuarios leidos
	 */	 
	private Vector leeFichero(String filename)
	{
		Vector lista = new Vector();
		String login, password;

		try {
			FileReader in = new FileReader(filename);

			StreamTokenizer st = new StreamTokenizer(in);

			st.wordChars(32,128);
			st.whitespaceChars(SEPARADOR,SEPARADOR);

			while(st.nextToken() != StreamTokenizer.TT_EOF)
			{
				login = st.sval;
				st.nextToken();
				password = st.sval;

				lista.addElement(new Usuario(login, password));
			}

			in.close();

		} catch(FileNotFoundException e1) {
			System.err.println("No se encuentra el fichero " + filename);
		} catch(IOException e2) {
			System.err.println("Error leyendo el fichero " + filename);
		} finally {
			return lista;
		}
	}

	/* Guarda los usuarios en un fichero
	   - filename: Fichero donde guardar los usuarios
	   - lista: Lista de usuarios a guardar
	 */	 
	private void escribeFichero(String filename, Vector lista)
	{
		PrintWriter out = null;
		Usuario aux = null;

		try {
			FileWriter writer = new FileWriter(filename);
			out = new PrintWriter(writer);

			for(int i=0;i<lista.size();i++)
			{
				aux = (Usuario)lista.elementAt(i);

				out.println(aux.login + SEPARADOR + aux.password);
			}

		} catch(IOException e1) {
			System.err.println("Error escribiendo en el fichero " + filename);
		} finally {
			out.close();
		}


	}

	/**
	  * Esta clase mantiene los datos de cada usuario: el login y el password
	  */
	class Usuario 
	{
		/* Login del usuario */
		public String login;
		
		/* Password del usuario */
		public String password;

		/* Crea un usuario
		   - login: Login del nuevo usuario
		   - password: Password del nuevo usuario
		 */
		public Usuario(String login, String password) 
		{
			this.login = login;
			this.password = password;
		}
	}
}