package usuarios;

/**
  * Este interfaz lo implementaran las clases que se utilicen para
  * gestionar el acceso de usuarios. Se tendra una clase para registro
  * mediante fichero, y tambien otra para registro en base de datos
  */
public interface AccesoUsuarios {

	/* Valida que los datos del usuario son correctos
	   - login: login del usuario que quiere entrar
	   - password: password del usuario
	 */
	public boolean valida(String login, String password);

	/* Registra un nuevo usuario en la base de datos
	   - login: login del usuario
	   - password: password del usuario
	   Lanza una excepcion si el login esta repetido
	 */
	public void registra(String login, String password) throws LoginInvalidoException;

}