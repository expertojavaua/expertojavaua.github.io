package usuarios;

/**
  * Esta clase se utiliza para lanzar una excepcion si el login
  * que introduce un usuario no es valido (porque ya exista)
  */
public class LoginInvalidoException extends Exception 
{
	/* Constructor 
	   - msg: Mensaje que se muestra en la excepcion
	 */
	public LoginInvalidoException(String msg) 
	{
		super(msg);
	}

}