/**
  * Ejemplo de clase Java
  */
public class Persona
{
	public String nombre;	
	int edad;

	/**
	  * Constructor
	  */
	public Persona()
	{
		nombre = "Pepe";
		edad = 33;
	}

	/**
	  * Metodo
	  */
	public void nombre()
	{
		System.out.println ("Nombre Persona: " + nombre);
	}

	/**
	  * Metodo
	  */
	public int edad()
	{
		return edad;
	}
	
	/**
	  * Main
	  */
	public static void main (String[] args)
	{
		// Datos de la persona
		Persona p = new Persona();
		p.nombre();
		int e = p.edad();
		System.out.println ("Edad Persona: " + e);
	}	
}
