import animales.*;
import insectos.Mosca;

/**
  * Ejemplo de clase Java
  */
public class Persona
{
	public String nombre;	
	int edad;

	/**
	  * Constructor
	  */
	public Persona()
	{
		nombre = "Pepe";
		edad = 33;
	}

	/**
	  * Metodo
	  */
	public void nombre()
	{
		System.out.println ("Nombre Persona: " + nombre);
	}

	/**
	  * Metodo
	  */
	public int edad()
	{
		return edad;
	}
	
	/**
	  * Main
	  */
	public static void main (String[] args)
	{
		// Datos de la persona
		Persona p = new Persona();
		p.nombre();
		int edad1 = p.edad();
		System.out.println ("Edad Persona: " + edad1);

		// Datos del animal
		Elefante e = new Elefante();
		e.nombre();
		int edad2 = e.edad();
		System.out.println ("Edad Animal: " + edad2);

		// Datos del insecto
		Mosca m = new Mosca();
		m.nombre();
		int edad3 = m.edad();
		System.out.println ("Edad Insecto: " + edad3);

		// Datos de otra persona
		OtraPersona op = new OtraPersona();
		op.nombre();
		int edad4 = op.edad();
		System.out.println ("Edad Otra Persona: " + edad4);
	}	
}
