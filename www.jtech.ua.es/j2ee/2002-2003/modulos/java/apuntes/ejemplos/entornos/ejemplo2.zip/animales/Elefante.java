package animales;

/**
  * Ejemplo de clase Java en un paquete
  */
public class Elefante
{
	String nombre;
	int edad;

	/**
	  * Constructor
	  */
	public Elefante()
	{
		nombre = "Elefante";
		edad = 12;
	}

	/**
	  * Metodo
	  */
	public void nombre()
	{
		System.out.println ("Nombre Animal: " + nombre);
	}

	/**
	  * Metodo
	  */
	public int edad()
	{
		return edad;
	}
}
