package insectos;

/**
  * Ejemplo de clase Java en un paquete
  */
public class Mosca
{
	String nombre;
	int edad;

	/**
	  * Constructor
	  */
	public Mosca()
	{
		nombre = "Mosca";
		edad = 2;
	}

	/**
	  * Metodo
	  */
	public void nombre()
	{
		System.out.println ("Nombre Insecto: " + nombre);
	}

	/**
	  * Metodo
	  */
	public int edad()
	{
		return edad;
	}
}
