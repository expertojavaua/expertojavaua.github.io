
// ------------------------------------------------------------------------------------
// 	Contexto del juego (dispositivos de entrada)
// ------------------------------------------------------------------------------------

public class GameContext {

	public EntradaTeclado et;
	
}