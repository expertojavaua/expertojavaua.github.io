
/**
  * Ejemplo de cliente RMI. Simplemente obtiene un objeto remoto y llama
  * a sus metodos
  */
public class MiClienteRMI 
{
	public static void main(String[] args) 
	{
    	if (System.getSecurityManager() == null) 
       		System.setSecurityManager(new java.rmi.RMISecurityManager());
		try
		{
			MiInterfazRemoto mir = (MiInterfazRemoto)java.rmi.Naming.lookup("//" + args[0] + ":" + args[1] +"/PruebaRMI");
			mir.miMetodo1();
			int i = mir.miMetodo2();
			System.out.println ("Valor de miMetodo2: " + i);
			MiParametro mp = mir.getParametro();
			System.out.println ("MiParametro: " + mp.getS());			
		} catch (Exception e) { System.out.println (e.getMessage()); }
	}
}
