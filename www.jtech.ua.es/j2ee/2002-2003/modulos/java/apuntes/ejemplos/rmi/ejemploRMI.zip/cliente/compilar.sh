export CLASSPATH=./objRemotos.jar:.
javac MiClienteRMI.java
