export CLASSPATH=./objRemotos.jar:.
java -Djava.security.policy=java.policy MiClienteRMI $1 $2
