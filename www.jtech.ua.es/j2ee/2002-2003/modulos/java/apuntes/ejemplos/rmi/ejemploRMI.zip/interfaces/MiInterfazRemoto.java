
/**
  * Interfaz remoto, a implementar por las clases remotas que se 
  * quieran usar
  */
public interface MiInterfazRemoto extends java.rmi.Remote
{
	public void miMetodo1() throws java.rmi.RemoteException;
	public int miMetodo2() throws java.rmi.RemoteException;
	public MiParametro getParametro() throws java.rmi.RemoteException;
}
