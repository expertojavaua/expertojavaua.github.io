
/**
  * Servidor RMI. Implementa la interfaz de la clase remota,
  * definiendo el codigo para sus metodos. En el metodo main() se 
  * registra el objeto para que pueda ser accedido desde los clientes
  */
public class MiClaseRemota	 extends java.rmi.server.UnicastRemoteObject 
                     		 implements MiInterfazRemoto
{
	// Constructor
	
	public MiClaseRemota() throws java.rmi.RemoteException
	{
	}

	// Metodos remotos
	
	public void miMetodo1() throws java.rmi.RemoteException
	{
		System.out.println ("Has llamado al metodo \"miMetodo1()\"");
	}

	public int miMetodo2() throws java.rmi.RemoteException
	{
		return 2;
	}

	public MiParametro getParametro() throws java.rmi.RemoteException
	{
		return new MiParametro();
	}

	// Main

	public static void main(String[] args)
	{
		if (System.getSecurityManager() == null)
			System.setSecurityManager(new java.rmi.RMISecurityManager());
		try
		{
			MiInterfazRemoto mir = new MiClaseRemota();
			java.rmi.Naming.rebind("//" + java.net.InetAddress.getLocalHost().getHostAddress() + ":" + args[0] + "/PruebaRMI", mir);
			System.out.println ("Servidor enlazado");
		} catch (Exception e) { e.printStackTrace(); }
	}
}
