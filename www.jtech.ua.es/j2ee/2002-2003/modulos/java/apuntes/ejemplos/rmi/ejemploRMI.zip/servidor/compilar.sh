export CLASSPATH=./objRemotos.jar:.
javac MiClaseRemota.java
rmic -d . MiClaseRemota