export CLASSPATH=./objRemotos.jar:.
rmiregistry $1 &
java -Djava.security.policy=java.policy MiClaseRemota $1
