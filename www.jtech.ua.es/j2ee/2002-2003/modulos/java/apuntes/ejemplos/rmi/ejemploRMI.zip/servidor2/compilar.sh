export CLASSPATH=./objRemotos.jar:.
javac MiClaseRemota2.java
rmic -d . MiClaseRemota2