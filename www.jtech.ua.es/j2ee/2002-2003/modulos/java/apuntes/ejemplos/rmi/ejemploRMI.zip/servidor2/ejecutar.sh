export CLASSPATH=./objRemotos.jar:.
rmiregistry $1 &
rmid -J-Djava.security.policy=java.policy &
java -Djava.security.policy=java.policy MiClaseRemota2 $1
