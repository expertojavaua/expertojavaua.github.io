
/**
  * Esqueleto para el ejercicio de la ecuacion de segundo grado
  */
public class Ej3
{	  
	/**
	  * Obtiene un array con las dos soluciones a la ecuacion
	  */
	public static double[] solucion (double a, double b, double c)
	{ 
		// ... Colocad aqui vuestro codigo
	} 

	/**
	  * Main
	  */
	public static void main(String[] args) 
	{ 
		double[] sol = solucion(4.0, 1.0, -6.0);
		System.out.println ("X1 = " + sol[0] + ", X2 = " + sol[1]); 
	} 
}
