public class Ej1
{
	public static double logaritmo(double num) 
	{
		return Math.log(num);
	}

	public static void main(String [] args) 
	{
		double num = Double.parseDouble(args[0]);
		System.out.println("Logaritmo = " + logaritmo(num));
	}
}