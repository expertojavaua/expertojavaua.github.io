public class Ej2 {

	// Declarar que el m�todo logaritmo puede lanzar excepciones

	public static double logaritmo(double num)
	{

		if(num <= 0) 
		{
			// Lanzar excepcion con mensaje descriptivo

		}

		return Math.log(num);
	}

	public static void main(String [] args) 
	{

		double num = Double.parseDouble(args[0]);

		System.out.println("Logaritmo = " + logaritmo(num));
	}
}