// Debemos importar algun paquete?

public class Ej3 {

	public Ej3(String login, String password) {

		try {
			registraUsuario(login, password);
		} catch(LoginInvalidoException e) {
			System.err.println(e.getMessage());
		}
	}

	// Hay que a�adir algo a la cabecera de la funci�n?

	private void registraUsuario(String login, String password) 
	{
		if(login.equals("paj")) {

			// Lanzar aqui una excepcion con el mensaje "Login repetido"
		}

		if(password.length() < 6) {

			// Lanzar aqui una excepcion con el mensaje "Password demasiado corto"
		}

	}

	public static void main(String [] args) {
		if(args.length!=2) {
			System.err.println("Uso: java Ej3 login password");
			System.exit(1);
		}

		new Ej3(args[0], args[1]);
	}
}