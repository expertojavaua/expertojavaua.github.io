import java.lang.reflect.*;

public class Ej4 
{
	public static void main(String [] args) 
	{
		if(args.length!=1) 
		{
			System.err.println("Uso: java Ej4 [MiClase1|MiClase2]");
			System.exit(1);
		}

		// Codigo para crear el objeto y llamar al metodo
	}
}