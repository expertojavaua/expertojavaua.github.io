import java.lang.reflect.*;

public class Ej5 
{
	public static void main(String [] args) 
	{
		if(args.length!=1) 
		{
			System.err.println("Uso: java Ej5 [MiClase1b|MiClase2b]");
			System.exit(1);
		}

		// Crear el objeto con el constructor con parametro String
		// y llamar al metodo con parametro String
	}
}