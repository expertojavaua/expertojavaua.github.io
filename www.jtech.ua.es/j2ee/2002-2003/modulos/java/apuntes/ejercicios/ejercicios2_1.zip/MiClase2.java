public class MiClase2
{
	public MiClase2() 
	{
	}

	public void imprime() 
	{
		System.out.println ("Imprimiendo en MiClase2");
	}
}