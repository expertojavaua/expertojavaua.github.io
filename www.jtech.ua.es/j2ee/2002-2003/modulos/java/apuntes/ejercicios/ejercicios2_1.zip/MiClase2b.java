public class MiClase2b
{
	public MiClase2b(String param) 
	{
	}

	public void imprime(String param) 
	{
		System.out.println ("Imprimiendo en MiClase2b con metodo con parametro: " + param);
	}
}