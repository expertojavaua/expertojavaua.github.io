
public class Ej2 
{

	public final static int DELAY = 100;

	public Ej2()
	{
		// Crea los 3 hilos, que realizaran 1000 iteraciones cada 1

		Hilo hiloA = new Hilo(1000);
		Hilo hiloB = new Hilo(1000);
		Hilo hiloC = new Hilo(1000, hiloA);

		// Establece prioridades de los hilos

		hiloA.setPriority(Thread.MAX_PRIORITY);
		hiloB.setPriority(Thread.NORM_PRIORITY);
		hiloC.setPriority(Thread.MIN_PRIORITY);

		// Inicia los hilos

		hiloA.start();
		hiloB.start();
		hiloC.start();

		// Muestra el contados de los 3 hilos cada 100 ms

		do
		{
			System.out.print("A = " + hiloA.count + "\tB = " + hiloB.count + "\tC = " + hiloC.count + "\r");

			try {
				Thread.currentThread().sleep(DELAY);
			} catch(InterruptedException e) { }

		} while(hiloA.isAlive() || hiloB.isAlive() || hiloC.isAlive());

		System.out.print("A = " + hiloA.count + "\tB = " + hiloB.count + "\tC = " + hiloC.count + "\r");
	}


	public static void main(String [] args)
	{
		new Ej2();
	}

	class Hilo extends Thread
	{
		// Iteraciones que realizar� el hilo
		long iter;

		// Contador del hilo
		public long count;

		// Hilo al que debe esperar que finalice antes de comenzar
		Thread t;

		public Hilo(long iter) 
		{
			this.iter = iter;

			t = null;
		}

		public Hilo(long iter, Thread t) 
		{
			this.iter = iter;

			this.t = t;
		}

		public void run()
		{
			if(t!=null) {

				/* Esperar a la finalizaci�n del hilo t */

			}

			for(count=0;count<iter;count++) {

				// Operaci�n costosa

				System.gc();

			}
		}
	}

}