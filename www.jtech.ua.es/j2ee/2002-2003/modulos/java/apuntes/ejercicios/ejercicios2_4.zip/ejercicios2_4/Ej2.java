import java.io.*;
import java.net.*;
import es.*;

public class Ej2 {

	public Ej2(String host, int puerto)
	{
		ConexionSocket sock = null;

		try {
			sock = new ConexionSocket(host, puerto);
		} catch(UnknownHostException e1) {
			System.err.println("Host desconocido");
			System.exit(1);
		} catch(IOException e2) {
			System.err.println("Error al conectar con el socket");
			System.exit(1);
		}

/* Descomentar este bloque para el apartado (b) *

		sock.envia("GET /index.html");

		try {
			String linea;
			while( (linea=sock.recibe()) != null )
			{
				System.out.println(linea);
			}
		} catch(IOException e3) {
			System.err.println("Error al leer del socket");
			System.exit(1);
		}

		System.exit(0);

 * Descomentar este bloque para el apartado (b) */

	}

	public static void main(String [] args)
	{
		if(args.length!=2) {
			System.err.println("Uso: java Ej2 <host> <puerto>");
			System.exit(-1);
		}

		int puerto;

			puerto = Integer.parseInt(args[1]);

		new Ej2(args[0], puerto);
	}
}