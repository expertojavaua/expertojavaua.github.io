package es;

import java.io.*;
import java.net.*;

/**
  * Maneja una conexi�n establecida mediante sockets, permitiendonos leer o escribir
  * lineas en el canal de comunicaci�n.
  */
public class ConexionSocket {

	// Objeto Socket que usamos para comunicarnos
	Socket socket;

	// Flujo de salida
	PrintStream out;

	// Flujo de entrada
	BufferedReader in;

	/**
	  * Construye un objeto conexi�n socket conectandose al host y al puerto indicados.
	  * @param host Host al que conectarse
	  * @param puerto Puerto al que conectarse
	  */
	public ConexionSocket(String host, int puerto) throws UnknownHostException, IOException {

		socket = /* Crear socket para conectar a host y puerto */;

		/* in = Crear BufferedReader de entrada del socket ; */
		/* out = Crear PrintStream de salida al socket; */

	}

	/**
	  * Construye un objeto ConexionSocket a partir de una conexi�n mediante sockets
	  * ya establecida.
	  * @param socket Objeto Socket utilizado para la comunicaci�n
	  */
	public ConexionSocket(Socket socket) throws IOException {

		this.socket = socket;

		/* in = Crear BufferedReader de entrada del socket ; */
		/* out = Crear PrintStream de salida al socket; */

	}

	/** 
	  * Envia una l�nea de texto por el canal de salida del socket.
	  * @param datos Linea de texto a enviar
	  */
	public void envia(String datos)
	{
		out.println(datos);
	}

	/**
	  * Recibe una l�nea de texto del socket
	  * @return Linea de texto recibida
	  */
	public String recibe() throws IOException
	{
		return in.readLine();
	}
}
