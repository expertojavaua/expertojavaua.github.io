import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Ej2 extends JFrame {

	public static final String TEXTO = "Pulsa aqui";

	public Ej2() {

		// Establece las dimensiones de la ventana
		setSize(200,100);

		// Crea el area de dibujo que hemos definido
		AreaDibujo area = new AreaDibujo();
		getContentPane().add(area, BorderLayout.CENTER);

		// Cuando cerremos la ventana saldr� de la aplicaci�n
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	class AreaDibujo extends JPanel implements MouseMotionListener {

		// Indica si el raton est� encima del texto o no
		boolean encima = false;

		// Fuente y m�tricas
		Font f;
		FontMetrics fm;

		// Posicion del texto
		int x, y;

		public AreaDibujo() {
			// Crea la fuente y obtiene sus metricas
			f = new Font("Arial", Font.PLAIN, 20);
			/* Obtener metricas de la fuente */;

			// Registra el componente para que 'escuche' el movimiento del raton
			addMouseMotionListener(this);

			// Establece la posici�n del texto
			x = 10;
			y = 30;
		}

		public void mouseMoved(MouseEvent e) {

			// Comprueba si el raton est� encima del texto 
			if( /* esta el raton encima del texto? */ false )
			{
				encima = true;
				repaint();
			} else {
				encima = false;
				repaint();
			}
		}

		public void mouseDragged(MouseEvent e) { }

		public void paint(Graphics g) {
			// Vacia el �rea de dibujo
			g.clearRect(0, 0, getWidth(), getHeight());

			// Establece el color segun si el raton esta encima del texto o no
			if(encima) {
				g.setColor(Color.blue);
			} else {
				g.setColor(Color.black);
			}

			// Establece la fuente
			g.setFont(f);

			// Dibuja el texto
			g.drawString(TEXTO, x, y);
		}

	}

	public static void main(String [] args) {
		Ej2 ej2 = new Ej2();

		ej2.show();
	}
}