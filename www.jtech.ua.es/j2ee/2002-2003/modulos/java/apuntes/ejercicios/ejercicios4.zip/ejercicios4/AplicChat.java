import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.TextField;
import javax.swing.*;
import java.awt.event.*;
import java.io.IOException;
import java.net.UnknownHostException;
import chat.ClienteChat;
import usuarios.*;

/**
  * Aplicacion para chat
  */
public class AplicChat extends JFrame implements Runnable
{
	/**
	  * Puntero al frame (para el hilo)
	  */
	AplicChat frame = this;

	/**
	  * Direccion IP del servidor
	  */
	TextField txtIP;

	/**
	  * Login del usuario
	  */
	TextField txtLogin;

	/**
	  * Password del usuario
	  */
	TextField txtPassword;

	/**
	  * Texto a enviar al chat
	  */
	TextField txtMensaje;

	/**
	  * Buffer de mensajes del chat
	  */
	JTextArea txtBuffer;
	
	/**
	  * Cliente de chat 
	  */
	ClienteChat chat;

	/**
	  * Hilo para recibir mensajes del servidor 
	  */
	Thread t;
	
	/**
	  * Constructor
	  */
	public AplicChat()
	{
		init();
	}

	/**
	  * Metodo para inicializar los componentes
	  */
	public void init()
	{		
		getContentPane().setLayout(new BorderLayout());
		
		/******** Panel superior para validar el usuario *********/
		
		JPanel panelSup = new JPanel();
		panelSup.setLayout(new GridLayout(3, 3));
		
		// Conexion al servidor
		
		JLabel lblIP = new JLabel ("IP Servidor:");
		txtIP = new TextField();
		panelSup.add(lblIP);
		panelSup.add(txtIP);

		// Boton de conexion con el servidor
	
		JButton btnConectar = new JButton ("Conectar");
		btnConectar.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try {
					chat = new ClienteChat(txtIP.getText());
				} catch(UnknownHostException e1) {
					txtBuffer.append("Host desconocido");
				} catch(IOException e2) {
					txtBuffer.append("Error al conectar con el servidor");
				}
			}
		});
		panelSup.add(btnConectar);

		
		// Login del usuario
		
		JLabel lblLogin = new JLabel("Login:");
		txtLogin = new TextField();
		panelSup.add(lblLogin);
		panelSup.add(txtLogin);

		// Boton de registrar un nuevo usuario
			
		JButton btnRegistrar = new JButton ("Registrar");
		btnRegistrar.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try {
					chat.registraUsuario(txtLogin.getText(), txtPassword.getText());
				} catch(IOException e1) {
					txtBuffer.append("Error al conectar con el servidor");
				} catch(LoginInvalidoException e2) {
					txtBuffer.append(e2.getMessage());
				}
			}
		});
		panelSup.add(btnRegistrar);
					
		// Password del usuario
		
		JLabel lblPassword = new JLabel("Password:");
		txtPassword = new TextField();
		panelSup.add(lblPassword);
		panelSup.add(txtPassword);		

		// Boton de validacion de usuario
			
		JButton btnValidar = new JButton ("Validar");
		btnValidar.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try {
					chat.loginUsuario(txtLogin.getText(), txtPassword.getText());
				} catch(IOException e1) {
					txtBuffer.append("Error al conectar con el servidor");
				} catch(LoginInvalidoException e2) {
					txtBuffer.append(e2.getMessage());
					return;
				}

				t = new Thread(frame);
				t.start();
			}
		});
		panelSup.add(btnValidar);

		getContentPane().add(panelSup, BorderLayout.NORTH);


		/******** Panel central con el buffer del chat *********/

		txtBuffer = new JTextArea("", 10, 450);
		txtBuffer.setEditable(false);
		txtBuffer.setAutoscrolls(true);
		JScrollPane scrllBuffer = new JScrollPane(txtBuffer);
		getContentPane().add(scrllBuffer, BorderLayout.CENTER);
		

		/******** Panel inferior para enviar mensajes al chat *********/
		
		JPanel panelInf = new JPanel();
		panelInf.setLayout(new GridLayout(2, 1));
		
		txtMensaje = new TextField();
		panelInf.add(txtMensaje);
		
		JButton btnEnviar = new JButton("Enviar");
		btnEnviar.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				chat.enviaMensaje(txtMensaje.getText());
			}
		});
		panelInf.add(btnEnviar);
		
		getContentPane().add(panelInf, BorderLayout.SOUTH);		
	}

	/**
	  * Funcion principal del hilo 
	  */
	public void run() 
	{
		// Recibe los mensajes del servidor
		
		String msg = null;

		try {
			while( (msg=chat.recibeMensaje()) != null ) 
			{
				txtBuffer.append(msg + "\n");
			}
		} catch(IOException e1) {
			txtBuffer.append("Desconectado del servidor");
		}
	}
	
	/**
	  * Main
	  */

	public static void main (String[] args)
	{
		AplicChat ac = new AplicChat();

		ac.setSize(400, 300);
		ac.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});

		ac.show();
	}

}