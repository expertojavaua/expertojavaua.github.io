
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.lang.*;
import java.applet.*;
import javax.swing.*;

public class Ej1 extends JApplet {

  // Etiqueta de mensajes
  JLabel lblMensaje;

  // Boton para guardar el texto
  JButton btnGrabar;

  // Area de texto que podr� ser grabado
  JTextArea txtTexto;

  // Fichero donde se guarda
  String fichero = "prueba.txt";

  // -----------------------------------------------------------------------------------
  //  Crea la interfaz gr�fica de la aplicaci�n
  // -----------------------------------------------------------------------------------

  public void init() {

	Container panel = getContentPane();

	panel.setLayout(new BorderLayout());

	lblMensaje = new JLabel("Escriba el texto y pulse GUARDAR para guardarlo en disco");

	txtTexto = new JTextArea();

	btnGrabar = new JButton("GUARDAR");

	btnGrabar.addActionListener(new ActionListener() {	
		public void actionPerformed(ActionEvent e) {
			guardar(fichero);
		}
	});

	panel.add(lblMensaje, BorderLayout.NORTH);
	panel.add(txtTexto, BorderLayout.CENTER);
	panel.add(btnGrabar, BorderLayout.SOUTH);
    
  }

  // -----------------------------------------------------------------------------------
  //  Guarda el texto del area de texto en un fichero en disco
  // -----------------------------------------------------------------------------------

  private void guardar(String fichero) {

	PrintWriter out = null;

	try {
		out = new PrintWriter(new FileWriter(fichero));

		out.print(txtTexto.getText());

		lblMensaje.setText("Guardado correctamente");
	} catch(Exception e) {
		lblMensaje.setText("ERROR: " + e.getMessage());
	} finally {
		out.close();
	}
  } 

  public static void main (String[] args)
  {
	JFrame frame = new JFrame();
	Ej1 ac = new Ej1();
	ac.init();

	frame.setSize(400, 300);
	frame.addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e)
		{
			System.exit(0);
		}
	});

	frame.getContentPane().add(ac);

	frame.show();
  }

}

