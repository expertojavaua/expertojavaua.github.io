import java.awt.Frame;
import java.awt.event.*;
import java.awt.image.renderable.ParameterBlock;
import java.io.IOException;
import javax.media.jai.JAI;
import javax.media.jai.RenderedOp;
import com.sun.media.jai.codec.FileSeekableStream;
import javax.media.jai.widget.ScrollingImagePanel;


/**
  * Ejercicio de JAI para sumar dos imagenes
  */
public class Ej3
{
	public static void main(String[] args)
	{
		// ... Leer las im�genes de los ficheros correspondientes

		// ... Crear operadores que tomen las im�genes de entrada

		// ... Definir los par�metros (las imagenes de entrada)

		// ... Crear el operador de suma de imagenes, pasarle los parametros y obtener el resultado

		// ... Visualizar la imagen resultado
	}
}
