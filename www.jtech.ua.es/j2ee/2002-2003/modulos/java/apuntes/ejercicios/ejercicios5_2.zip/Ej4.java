import java.awt.Frame;
import java.awt.event.*;
import java.awt.image.renderable.ParameterBlock;
import java.io.IOException;
import javax.media.jai.JAI;
import javax.media.jai.RenderedOp;
import com.sun.media.jai.codec.FileSeekableStream;
import javax.media.jai.widget.ScrollingImagePanel;


/**
  * Ejercicio de JAI para aplicar un filtro de mediana
  */
public class Ej4
{
	public static void main(String[] args)
	{
		// ... Leer la imagen del fichero correspondiente

		// ... Crear el operador que tome la imagen de entrada
		
		// ... Definir los par�metros del filtro de mediana (la imagen de entrada)

		// ... Crear el operador de filtro de mediana, pasarle los parametros y obtener el resultado

		// ... Visualizar la imagen resultado
	}
}
