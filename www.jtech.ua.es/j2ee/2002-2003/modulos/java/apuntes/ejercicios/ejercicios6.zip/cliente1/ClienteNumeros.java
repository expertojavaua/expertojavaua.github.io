
/**
  * Cliente RMI que se conecta a un objeto InterfazServidorNumeros
  */
public class ClienteNumeros
{
	public static void main(String[] args) 
	{
		// Instalar un controlador de seguridad
		
		// Obtener un objeto remoto, llamar a su m�todo ultimoNumero() y
		// mostrar por pantalla lo que devuelve
	}
}
