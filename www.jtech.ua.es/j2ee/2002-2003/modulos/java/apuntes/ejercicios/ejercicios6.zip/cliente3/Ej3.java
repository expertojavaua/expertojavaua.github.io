
/**
  * Cliente RMI que se conecta a un servidor desconocido
  */
public class Ej3
{
	public static void main(String[] args) 
	{
		// Insalar un gestor de seguridad
		
		// Obtener un objeto remoto
		
		// Obtener un objeto Datos
		
		// Llamar al metodo cadena() de dicho objeto y ver lo que devuelve
		
	}
}
