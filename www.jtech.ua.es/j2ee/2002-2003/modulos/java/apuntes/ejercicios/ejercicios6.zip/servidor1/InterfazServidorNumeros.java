
/**
  * Interfaz remoto para servir numeros
  */
public interface InterfazServidorNumeros extends java.rmi.Remote
{
	public long ultimoNumero() throws java.rmi.RemoteException;
}
