
/**
  * Servidor RMI. Implementa la interfaz InterfazServidorNumeros para servir numeros primos encontrados
  */
public class ServidorPrimos	 extends java.rmi.server.UnicastRemoteObject 
                     		 implements InterfazServidorNumeros, Runnable
{
	long num = 1;						// Ultimo numero primo encontrado
	Thread t = new Thread(this);		// Hilo para calcular numeros primos
	
	// Constructor
	
	public ServidorPrimos() throws java.rmi.RemoteException
	{
		t.start();
	}

	// Metodo remoto
	
	public long ultimoNumero() throws java.rmi.RemoteException
	{
		return num;
	}

	// Metodo auxiliar para obtener el siguiente numero primo

	public long siguientePrimo(long numero)
	{
		for (long i = numero + 1; i > 0; i++)
			if (esPrimo(i))
				return i;
		return -1;
	}

	// Metodo auxiliar para ver si un numero es primo
	
	public boolean esPrimo(long numero)
	{
		for (long i = 2; i < numero; i++)
		{
			if (numero % 2 == 0)
				return false;
		}
		return true;
	}

	// Main del hilo
	
	public void run()
	{
		while (true)
		{
			try
			{
				t.sleep(1000);
				num = siguientePrimo(num);
			} catch (Exception ex) {}
		}
	}

	// Main

	public static void main(String[] args)
	{
		if (System.getSecurityManager() == null)
			System.setSecurityManager(new java.rmi.RMISecurityManager());
		try
		{
			InterfazServidorNumeros isn = new ServidorPrimos();
			java.rmi.Naming.rebind("//" + java.net.InetAddress.getLocalHost().getHostAddress() + ":" + args[0] + "/ServidorNumeros", isn);
			System.out.println ("Servidor enlazado");
		} catch (Exception e) { e.printStackTrace(); }
	}
}
