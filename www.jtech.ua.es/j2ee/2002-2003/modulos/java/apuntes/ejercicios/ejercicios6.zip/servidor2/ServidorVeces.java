
/**
  * Servidor RMI. Implementa la interfaz InterfazServidorNumeros para decir cuantas veces se le ha solicitado un metodo
  */
public class ServidorVeces	 extends java.rmi.server.UnicastRemoteObject 
                     		 implements InterfazServidorNumeros
{	
	// Constructor
	
	public ServidorVeces() throws java.rmi.RemoteException
	{
	}

	// Metodo remoto
	
	public long ultimoNumero() throws java.rmi.RemoteException
	{
		// Devolver el numero de veces que se ha llamado al metodo
	}

	// Main

	public static void main(String[] args)
	{
		// Instalar un gestor de seguridad
		
		// Crear un objeto remoto y publicarlo con Naming.rebind()
	}
}
