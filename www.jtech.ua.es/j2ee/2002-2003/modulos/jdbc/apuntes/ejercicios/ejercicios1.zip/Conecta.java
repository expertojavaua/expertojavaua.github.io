import java.sql.*;
import java.io.*;

public class Conecta {

	Connection con;

	public Conecta() {
		// Aqu� debe ir la carga del driver y la conexi�n
		
	}
	
	public Statement creaSentencia () {
		// Este m�todo crea y devuelve una sentencia
		
	}
	
	public void close () {
		// M�todo para cerrar la conexi�n
	}
}