import java.sql.*;
import java.io.*;

public class EjJDBC1 {
	
	public EjJDBC1 () {
	}
	
	
	public void listaVuelos () {		
		//Aqu� se listan los vuelos
	}
	
	public void listaUsuarios () {
		// Aqu� los usuarios
	}

	public static void main(String [] args) {

		EjJDBC1 EjJDBC1 = new EjJDBC1();
		EjJDBC1.listaVuelos();
		EjJDBC1.listaUsuarios();
		
	}
}