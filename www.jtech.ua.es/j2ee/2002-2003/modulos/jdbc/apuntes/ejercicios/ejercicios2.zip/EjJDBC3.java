import java.sql.*;
import java.io.*;

public class EjJDBC3 {
	
	Conecta conec;
	
	public EjJDBC3 () {
		conec = new Conecta();
	}
	
	public void close () {
		conec.close();
	}
	
	
	
	public void consultaDisp () throws SQLException {
	}
	
	public void muestraTray () throws SQLException {
	}
	
	public void modificaCliente () throws SQLException {
	}
	
	public void anulaTray () throws SQLException {
	
	}
	
	public void muestraMenu () {
		System.out.print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"+
						"\t1.- Consulta.\n"+
						"\t2.- Muestra trayectos cliente.\n"+
						"\t3.- Modifica datos cliente.\n"+
						"\t4.- Reserva.\n"+
						"\t0.- Salir.\n"+
						"\t\tElija una opcion:");		
	}
	
	public static void main(String [] args) {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int lectura=10;
		Integer auxInt;
		try {
			EjJDBC3 ejJDBC3 = new EjJDBC3();
			while (lectura!=0) {
				ejJDBC3.muestraMenu();
				auxInt = new Integer(br.readLine());
				lectura = auxInt.intValue();
				switch (lectura) {
					case (1): ejJDBC3.consultaDisp();
							  break;
					case (2): ejJDBC3.muestraTray();
							  break;
					case (3): ejJDBC3.modificaCliente();
							  break;
					case (4): ejJDBC3.anulaTray();
							  break;
				}
			}
			ejJDBC3.close();
		}
		catch (SQLException sqle) {
			System.err.println(sqle);
		}
		
		catch (Exception e) {
			System.err.println(e);
		}
	}
}
