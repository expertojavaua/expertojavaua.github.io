package pruebatags;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

import java.util.Calendar;

// Este tag muestra la fecha y hora actuales

public class FechaActual implements Tag
{
	private PageContext contexto;		// Contexto del tag
	private Tag padre; 					// Tag padre del actual
	
	// Metodo llamado cuando se comienza el tag
	public int doStartTag() throws JspException 
	{ 
		return SKIP_BODY; 
	} 
	
	// Metodo llamado cuando se termina el tag
	public int doEndTag() throws JspException 
	{
		try
		{
			// Mostramos la fecha y hora actuales
	        Calendar c=Calendar.getInstance();
			contexto.getOut().write(c.get(Calendar.DAY_OF_MONTH) + "/" + (c.get(Calendar.MONTH)+1) + "/" + c.get(Calendar.YEAR) + " - " + c.get(Calendar.HOUR_OF_DAY) + ":" + c.get(Calendar.MINUTE) + ":" + c.get(Calendar.SECOND)); 
		} catch(java.io.IOException e) {
			throw new JspException("Error: " + e.getMessage()); 
		}
		return EVAL_PAGE;
	} 
	
	// Metodo de limpieza
	public void release() {}
	
	// Metodo para asignar el contexto
	public void setPageContext(final PageContext contexto) 
	{
		this.contexto = contexto; 
	} 
	
	// Metodo para asignar el tag padre
	public void setParent(final Tag padre) 
	{
		this.padre = padre;
	} 
	
	// Metodo para obtener el padre
	public Tag getParent() 
	{
		return padre;
	}
}