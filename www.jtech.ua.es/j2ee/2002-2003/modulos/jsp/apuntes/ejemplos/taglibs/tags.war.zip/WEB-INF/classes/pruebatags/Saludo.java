package pruebatags;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

// Este tag saluda al nombre que se le pasa como parametro

public class Saludo implements Tag
{
	private PageContext contexto;		// Contexto del tag
	private Tag padre; 					// Tag padre del actual
	String nombre = "";					// Nombre al que se va a saludar
	
	// Metodo llamado cuando se comienza el tag
	public int doStartTag() throws JspException 
	{ 
		return SKIP_BODY; 
	} 
	
	// Metodo llamado cuando se termina el tag
	public int doEndTag() throws JspException 
	{
		try
		{
			// Mostramos el saludo
			contexto.getOut().write("�Hola " + nombre + "!"); 
		} catch(java.io.IOException e) {
			throw new JspException("Error: " + e.getMessage()); 
		}
		return EVAL_PAGE;
	} 
	
	// Metodo de limpieza
	public void release() {}
	
	// Metodo para asignar el contexto
	public void setPageContext(final PageContext contexto) 
	{
		this.contexto = contexto; 
	} 
	
	// Metodo para asignar el tag padre
	public void setParent(final Tag padre) 
	{
		this.padre = padre;
	} 
	
	// Metodo para obtener el padre
	public Tag getParent() 
	{
		return padre;
	}

	// Establece el nombre al que saludar
	public void setNombre(String nombre) 
	{
		this.nombre = nombre; 
	} 	
}