CREATE DATABASE faqs;

USE faqs;

CREATE TABLE faqs(
	ID int(3) unsigned NOT NULL auto_increment,
	pregunta text NOT NULL,
	respuesta text NOT NULL,
	fechamodif datetime NOT NULL,
	PRIMARY KEY (ID));
