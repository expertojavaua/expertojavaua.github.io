package faqs.tags;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

// Tag para mostrar formateada la informacion de una FAQ

public class FAQTag implements Tag
{
	private PageContext contexto;		// Contexto del tag
	private Tag padre; 					// Tag padre del actual
	
	// Metodo llamado cuando se comienza el tag
	public int doStartTag() throws JspException 
	{ 
	} 
	
	// Metodo llamado cuando se termina el tag
	public int doEndTag() throws JspException 
	{
	} 
	
	// Metodo de limpieza
	public void release() {}
	
	// Metodo para asignar el contexto
	public void setPageContext(final PageContext contexto) 
	{
		this.contexto = contexto; 
	} 
	
	// Metodo para asignar el tag padre
	public void setParent(final Tag padre) 
	{
		this.padre = padre;
	} 
	
	// Metodo para obtener el padre
	public Tag getParent() 
	{
		return padre;
	}
}