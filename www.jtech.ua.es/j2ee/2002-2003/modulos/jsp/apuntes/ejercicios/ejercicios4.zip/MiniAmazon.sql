# MySQL-Front Dump 2.5
#
# Host: localhost   Database: miniamazon
# --------------------------------------------------------
# Server version 3.23.37

CREATE DATABASE miniamazon;
USE miniamazon;


#
# Table structure for table 'categorias'
#

DROP TABLE IF EXISTS categorias;
CREATE TABLE categorias (
  subcategoria varchar(50) NOT NULL default '',
  categoria varchar(50) default '',
  PRIMARY KEY  (subcategoria)
) TYPE=MyISAM;



#
# Dumping data for table 'categorias'
#

INSERT INTO categorias (subcategoria, categoria) VALUES("libros", NULL);
INSERT INTO categorias (subcategoria, categoria) VALUES("discos", NULL);
INSERT INTO categorias (subcategoria, categoria) VALUES("informatica", "libros");
INSERT INTO categorias (subcategoria, categoria) VALUES("pop", "discos");
INSERT INTO categorias (subcategoria, categoria) VALUES("rock", "discos");
INSERT INTO categorias (subcategoria, categoria) VALUES("electronica", "discos");
INSERT INTO categorias (subcategoria, categoria) VALUES("novela", "libros");
INSERT INTO categorias (subcategoria, categoria) VALUES("ensayo", "libros");
INSERT INTO categorias (subcategoria, categoria) VALUES("web", "informatica");
INSERT INTO categorias (subcategoria, categoria) VALUES("ofimatica", "informatica");
INSERT INTO categorias (subcategoria, categoria) VALUES("programacion", "informatica");
INSERT INTO categorias (subcategoria, categoria) VALUES("superventas", "discos");


#
# Table structure for table 'prodcat'
#

DROP TABLE IF EXISTS prodcat;
CREATE TABLE prodcat (
  codprod int(5) unsigned NOT NULL default '0',
  categoria varchar(50) NOT NULL default '',
  PRIMARY KEY  (codprod,categoria)
) TYPE=MyISAM COMMENT='relacion entre productos y categorias';



#
# Dumping data for table 'prodcat'
#

INSERT INTO prodcat (codprod, categoria) VALUES("1", "discos");
INSERT INTO prodcat (codprod, categoria) VALUES("1", "pop");
INSERT INTO prodcat (codprod, categoria) VALUES("1", "superventas");
INSERT INTO prodcat (codprod, categoria) VALUES("2", "discos");
INSERT INTO prodcat (codprod, categoria) VALUES("2", "pop");
INSERT INTO prodcat (codprod, categoria) VALUES("3", "discos");
INSERT INTO prodcat (codprod, categoria) VALUES("3", "rock");
INSERT INTO prodcat (codprod, categoria) VALUES("4", "informatica");
INSERT INTO prodcat (codprod, categoria) VALUES("4", "libros");
INSERT INTO prodcat (codprod, categoria) VALUES("4", "web");
INSERT INTO prodcat (codprod, categoria) VALUES("5", "discos");
INSERT INTO prodcat (codprod, categoria) VALUES("5", "rock");
INSERT INTO prodcat (codprod, categoria) VALUES("5", "superventas");
INSERT INTO prodcat (codprod, categoria) VALUES("6", "libros");
INSERT INTO prodcat (codprod, categoria) VALUES("6", "novela");
INSERT INTO prodcat (codprod, categoria) VALUES("7", "discos");
INSERT INTO prodcat (codprod, categoria) VALUES("7", "pop");
INSERT INTO prodcat (codprod, categoria) VALUES("8", "discos");
INSERT INTO prodcat (codprod, categoria) VALUES("8", "pop");


#
# Table structure for table 'productos'
#

DROP TABLE IF EXISTS productos;
CREATE TABLE productos (
  cod int(5) unsigned zerofill NOT NULL auto_increment,
  titulo varchar(50) default '',
  autores varchar(100) default NULL,
  precio decimal(12,2) unsigned default '0.00',
  descripcion longtext,
  PRIMARY KEY  (cod)
) TYPE=MyISAM;



#
# Dumping data for table 'productos'
#

INSERT INTO productos (cod, titulo, autores, precio, descripcion) VALUES("00001", "Destrangis", "Estopa", "18.00", " Llegaron de la nada y lo conquistaron todo; con su primer disco ganaron infinidad de premios, vendieron un mill�n de copias y realizaron un centenar de conciertos. Ahora tienen el reto de mantenerse en la cresta de la ola sin perder su esp�ritu \"callejero\".");
INSERT INTO productos (cod, titulo, autores, precio, descripcion) VALUES("00007", "Estopa", "Estopa", "9.00", " Con las ventas de su primer disco, Estopa se han convertido en todo un fen�meno musical e incluso social. Se trata de un disco que no ha salido de las listas de ventas desde su aparici�n en las navidades del 2.000. Todo este fen�meno no se debe a una casualidad y son varios los factores que los han catapultado al �xito: la cuidada producci�n, la resurrecci�n de la rumba popera, la frescura, el estribillo facil�n y el ocupar el puesto que hab�an dejado vacante grupos como Los Chunguitos, Los Chichos, Peret o Las Grecas.");
INSERT INTO productos (cod, titulo, autores, precio, descripcion) VALUES("00003", "Know your enemy", "Manic Street Preachers", "17.40", "Sexto �lbum de su carrera. Esta vez la banda ha grabado su nuevo trabajo entre Espa�a, Gales y Londres. El disco, no exento de sorpresas, contiene adem�s un tema oculto que no aparece en los cr�ditos");
INSERT INTO productos (cod, titulo, autores, precio, descripcion) VALUES("00008", "D�melo en la calle", "Joaqu�n Sabina", "16.95", " El nuevo disco de Sabina se llama \'D�melo en la calle\'. Su primer single, \'69.G\', es un homenaje del artista a la radio de noche. Este nuevo trabajo est� producido por dos fieles colaboradores como son Antonio Garc�a De Diego y Pancho Varona y ha sido grabado en los estudios Sinton�a de Madrid. El disco contiene 13 canciones m�s un bonus track de regalo con el tema que se utiliz� para la banda sonora de la pel�cula \"Torrente 2\" y que Sabina interpreta junto a Santiago Segura");
INSERT INTO productos (cod, titulo, autores, precio, descripcion) VALUES("00004", "HTML y XHTML: la gu�a definitiva", "Chuck Muscianno / Bill Kennedy", "20.00", " Este libro sobre HTML es el m�s exhaustivo de los que puede encontrar hoy en d�a. Cubre los est�ndares, HTML 4.01, XHTML 1.0 y todas las caracter�sticas que admiten los navegadores web m�s utilizados. Le ayudar� a pasar del HTML al lenguaje de marcado de la pr�xima generaci�n web, el XHTML.");
INSERT INTO productos (cod, titulo, autores, precio, descripcion) VALUES("00006", "La carta esf�rica", "Arturo P�rez Reverte", "18.27", "Un marino sin barco, desterrado del mar, conoce a una extra�a mujer que posee, tal vez sin saberlo, respuestas a preguntas que ciertos hombres se hacen desde hace siglos. Cazadores de naufragios en busca del fantasma de un barco perdido en el Mediterr�neo, problemas de latitud y longitud cuyo secreto yace oculto en antiguos derroteros y cartas n�uticas, museos navales, bibliotecas. Nunca el mar y la historia se hab�an combinado de modo tan extraordinario en una novela, como en La carta esf�rica");
