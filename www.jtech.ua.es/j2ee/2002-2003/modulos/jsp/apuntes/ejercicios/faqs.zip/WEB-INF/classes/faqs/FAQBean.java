package faqs;

import java.util.Date;

/**
  * La clase FAQBean permite almacenar la informacion relevante
  * de un FAQ, para intercambiarse entre los distintos modulos
  * del gestor de FAQs
  */
public class FAQBean
{
	/**
	  * Identificador del FAQ (numerico autoincrementable)
	  */
	int id;
	
	/**
	  * Texto de la pregunta
	  */
	String pregunta;

	/**
	  * Texto de la respuesta
	  */
	String respuesta;
	
	/**
	  * Fecha de la �ltima modificacion
	  */
	Date fechaModif;
	
	
	/**
	  * Constructor
	  */
	public FAQBean()
	{
		id = 0;
		pregunta = "";
		respuesta = "";
		fechaModif = new Date();
	}
	
	// ======= METODOS GET Y SET PARA OBTENER CADA CAMPO =======
	
	/**
	  * Obtiene el identificador del FAQ
	  * @return El identificador del FAQ
	  */
	public int getId()
	{
		return id;
	}

	/**
	  * Establece el identificador del FAQ
	  * @param pID Nuevo identificador
	  */
	public void setId(int pID)
	{
		id = pID;
	}

	/**
	  * Obtiene el texto de la pregunta
	  * @return El texto de la pregunta
	  */
	public String getPregunta()
	{
		return pregunta;
	}

	/**
	  * Establece el texto de la pregunta
	  * @param pPregunta Texto de la pregunta
	  */
	public void setPregunta(String pPregunta)
	{
		pregunta = pPregunta;
		fechaModif = new Date();
	}

	/**
	  * Obtiene el texto de la respuesta
	  * @return El texto de la respuesta
	  */
	public String getRespuesta()
	{
		return respuesta;
	}

	/**
	  * Establece el texto de la respuesta
	  * @param pRespuesta Texto de la respuesta
	  */
	public void setRespuesta(String pRespuesta)
	{
		respuesta = pRespuesta;
		fechaModif = new Date();
	}
	
	/**
	  * Obtiene la fecha de ultima modificacion
	  * @return La fecha de ultima modificacion
	  */
	public Date getFechaModif()
	{
		return fechaModif;
	}

	/**
	  * Establece la fecha de ultima modificacion
	  * @param pFecha La fecha de ultima modificacion
	  */
	public void setFechaModif(Date pFecha)
	{
		fechaModif = pFecha;
	}
	
	/**
	  * Devuelve una cadena representativa de la informacion de la FAQ
	  * @return Una cadena con la informacion de la FAQ
	  */
	public String toString()
	{
		return "[" + id + "] " + "Pregunta: " + pregunta + "; Respuesta: " + respuesta + "\n";
	}
}
	  