package faqs.bd;

import java.util.*;
import java.sql.*;
import java.text.*;

import faqs.*;

/**
  * La clase FAQBD controla todo el acceso a la base de datos
  * de FAQs
  */
public class FAQBD
{
	/**
	  * Unica instancia permitida de la clase
	  */
	private static FAQBD instancia = null;
	

	// ================ DATOS DE CONEXION CON LA BD ================
	
	/**
	  * Driver
	  */
	private static final String driver = "org.gjt.mm.mysql.Driver";

	/**
	  * URL de la base de datos
	  */
	private static final String url = "jdbc:mysql://localhost/faqs";


	// ================ SENTENCIAS PREDEFINIDAS ================
	
	/**
	  * Conexion con la base de datos
	  */
	private static Connection con;

	/**
	  * Obtener FAQS de la base de datos
	  */
	private static PreparedStatement selStmt;

	/**
	  * Obtener todas las FAQS de la base de datos
	  */
	private static PreparedStatement selAllStmt;

	/**
	  * Insertar FAQS en la base de datos
	  */
	private static PreparedStatement insStmt;

	/**
	  * Borrar FAQS de la base de datos
	  */
	private static PreparedStatement delStmt;

	/**
	  * Actualizar FAQS en la base de datos
	  */
	private static PreparedStatement updStmt;
	
	
	// ================ METODOS DE INICIALIZACION ================

	/**
	  * Obtiene la unica instancia de la clase
	  * @return La unica instancia de la clase
	  */
	public static FAQBD getInstancia() throws FAQBDException
	{
		if (instancia == null)
			instancia = new FAQBD();
		return instancia;
	}
	
	/**
	  * Constructor
	  */
	private FAQBD() throws FAQBDException
	{
		try
		{
			Class.forName(driver);
			con = DriverManager.getConnection(url, "root", "mysql");		
			selStmt    = con.prepareStatement("SELECT * FROM faqs WHERE ID = ?");
			selAllStmt = con.prepareStatement("SELECT * FROM faqs ORDER BY ID");
			insStmt    = con.prepareStatement("INSERT INTO faqs (pregunta, respuesta, fechamodif) VALUES(?, ?, ?)");
			delStmt    = con.prepareStatement("DELETE FROM faqs WHERE ID = ?");
			updStmt    = con.prepareStatement("UPDATE faqs SET pregunta = ?, respuesta = ?, fechamodif = ? WHERE ID = ?");
		} catch (ClassNotFoundException e1) {
			throw new FAQBDException("No se encontro el driver para la base de datos");
		} catch (SQLException e2) {
			throw new FAQBDException(e2.getMessage());
		}
	}
	
	// ================ METODOS PARA LAS SENTENCIAS PREDEFINIDAS ================

	/**
	  * Obtiene una FAQ con un ID determinado
	  * @param id ID de la FAQ que se busca
	  * @return El FAQBean con los datos de la FAQ buscada
	  */
	public FAQBean getFAQ(int id) throws FAQBDException, FAQDesconocidoException
	{
		try
		{
			ResultSet rs;
			synchronized (selStmt)
			{
				selStmt.clearParameters();
				selStmt.setInt(1, id);
				rs = selStmt.executeQuery();
			}
			
			if (rs.next())
				return crearFAQ(rs);
			throw new FAQDesconocidoException("No se encuentra el FAQ " + id);			
		} catch (SQLException e) {
			throw new FAQBDException (e.getMessage());
		}
	}

	/**
	  * Obtiene todas las FAQs, ordenadas por ID
	  * @return Un array de FAQBeans con las FAQs ordenadas por ID
	  */
	public FAQBean[] getFAQs() throws FAQBDException
	{
		try
		{
			ResultSet rs;
			Collection faqs = new ArrayList();
			synchronized (selAllStmt)
			{
				rs = selAllStmt.executeQuery();
			}
			
			while (rs.next())
				faqs.add(crearFAQ(rs));

			return (FAQBean[])faqs.toArray(new FAQBean[0]);

		} catch (SQLException e) {
			throw new FAQBDException (e.getMessage());
		}
	}

	/**
	  * Inserta una nueva FAQ con los datos proporcionados
	  * @param faq FAQ con los datos que se quieren insertar
	  */
	public void insertFAQ(FAQBean faq) throws FAQBDException
	{
		try
		{
			synchronized (insStmt)
			{
				insStmt.clearParameters();
				insStmt.setString(1, faq.getPregunta());
				insStmt.setString(2, faq.getRespuesta());
				insStmt.setDate(3, new java.sql.Date(faq.getFechaModif().getTime()));
				insStmt.executeUpdate();
			}			
		} catch (SQLException e) {
			throw new FAQBDException (e.getMessage());
		}
	}

	/**
	  * Actualiza los datos de una FAQ con un ID determinado
	  * @param faq FAQ con los datos que se quieren actualizar
	  */
	public void updateFAQ(FAQBean faq) throws FAQBDException, FAQDesconocidoException
	{
		try
		{
			synchronized (updStmt)
			{
				updStmt.clearParameters();
				updStmt.setString(1, faq.getPregunta());
				updStmt.setString(2, faq.getRespuesta());
				updStmt.setDate(3, new java.sql.Date(faq.getFechaModif().getTime()));
				updStmt.setInt(4, faq.getId());
				
				int cambios = updStmt.executeUpdate();
				if (cambios < 1)
					throw new FAQDesconocidoException ("No se encuentra el FAQ " + faq.getId());
			}			
		} catch (SQLException e) {
			throw new FAQBDException (e.getMessage());
		}
	}

	/**
	  * Borra la FAQ de ID proporcionado
	  * @param id ID de la FAQ que se busca
	  */
	public void deleteFAQ(int id) throws FAQBDException, FAQDesconocidoException
	{
		try
		{
			synchronized (delStmt)
			{
				delStmt.clearParameters();
				delStmt.setInt(1, id);

				int cambios = delStmt.executeUpdate();
				if (cambios < 1)
					throw new FAQDesconocidoException ("No se encuentra el FAQ " + id);
			}
		} catch (SQLException e) {
			throw new FAQBDException (e.getMessage());
		}
	}


	// ================ METODOS AUXILIARES ================
	
	/**
	  * Crea un FAQBean con los datos que se le pasan. Utiliza
	  * el elemento actual del ResultSet para crear el FAQBean
	  * @param datos Conjunto de datos con los que crear un FAQBean
	  * @return El FAQBean creado
	  */
	private FAQBean crearFAQ(ResultSet datos) throws FAQBDException
	{
		try
		{
			FAQBean faq = new FAQBean();
			faq.setId(datos.getInt("ID"));
			faq.setPregunta(datos.getString("pregunta"));
			faq.setRespuesta(datos.getString("respuesta"));
			faq.setFechaModif(datos.getDate("fechamodif"));
			
			return faq;
			
		} catch (Exception e) {
			throw new FAQBDException (e.getMessage());
		}
	}

	/**
	  * Cierra la conexion con la base de datos
	  */
	public void cerrar()
	{
		if (con != null)
			try
			{
				con.close();
			} catch (Exception e) {}
	}
}
	  