package faqs.bd;

/**
  * La excepcion FAQBDException se lanza cuando ocurre algun error
  * en el acceso a la base de datos de FAQs
  */
public class FAQBDException extends Exception
{	
	/**
	  * Constructor
	  */
	public FAQBDException()
	{
		super();
	}

	/**
	  * Constructor
	  * @param msg Mensaje de la excepcion
	  */
	public FAQBDException(String msg)
	{
		super(msg);
	}	
}
	  