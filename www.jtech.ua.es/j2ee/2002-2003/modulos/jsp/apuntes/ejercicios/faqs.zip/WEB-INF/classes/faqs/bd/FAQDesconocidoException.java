package faqs.bd;

/**
  * La excepcion FAQDesconocidoException se lanza cuando no se encuentra
  * un FAQ en la base de datos
  */
public class FAQDesconocidoException extends FAQBDException
{	
	/**
	  * Constructor
	  */
	public FAQDesconocidoException()
	{
		super();
	}

	/**
	  * Constructor
	  * @param msg Mensaje de la excepcion
	  */
	public FAQDesconocidoException(String msg)
	{
		super(msg);
	}	
}
	  