package faqs.comandos;

import javax.servlet.*;
import javax.servlet.http.*;

/**
  * La interfaz FAQComando define los metodos que debe implementar
  * todo comando del administrador
  */
public interface FAQComando
{	
	/**
	  * Ejecuta el comando
	  * @param req Datos de la peticion del cliente
	  */
	public String ejecutar(HttpServletRequest req) throws FAQComandoException;
}
	  