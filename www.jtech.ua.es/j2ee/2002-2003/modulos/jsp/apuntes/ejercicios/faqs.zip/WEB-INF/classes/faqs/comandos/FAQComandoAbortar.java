package faqs.comandos;

import javax.servlet.*;
import javax.servlet.http.*;

/**
  * La clase FAQComandoAbortar es un comando que muestra un mensaje
  * de cancelacion y redirige el flujo a la pagina que se indique
  */
public class FAQComandoAbortar implements FAQComando
{	
	/**
	  * Siguiente pagina a mostrar
	  */
	private String siguiente;
	
	/**
	  * Constructor
	  * @param siguiente Siguiente pagina a visitar
	  */
	public FAQComandoAbortar(String siguiente)
	{
		this.siguiente = siguiente;
	}
	
	/**
	  * Ejecuta el comando
	  * @param req Datos de la peticion del cliente
	  */
	public String ejecutar(HttpServletRequest req) throws FAQComandoException
	{
		req.setAttribute("faqs.mensaje", "Operacion Abortada");
		return siguiente;
	}
}
	  