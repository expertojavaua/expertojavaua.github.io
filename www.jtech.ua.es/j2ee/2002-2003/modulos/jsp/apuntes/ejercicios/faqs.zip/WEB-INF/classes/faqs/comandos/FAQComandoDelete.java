package faqs.comandos;

import javax.servlet.*;
import javax.servlet.http.*;

import faqs.bd.*;

/**
  * La clase FAQComandoDelete es un comando que elimina una FAQ
  * de la base de datos
  */
public class FAQComandoDelete implements FAQComando
{	
	/**
	  * Siguiente pagina a mostrar
	  */
	private String siguiente;
	
	/**
	  * Constructor
	  * @param siguiente Siguiente pagina a visitar
	  */
	public FAQComandoDelete(String siguiente)
	{
		this.siguiente = siguiente;
	}
	
	/**
	  * Ejecuta el comando
	  * @param req Datos de la peticion del cliente
	  */
	public String ejecutar(HttpServletRequest req) throws FAQComandoException
	{
		try
		{
			// Es un comando critico que no debe repetirse accidentalmente
			
			if (FAQComandoToken.isValida(req))
			{
				FAQBD faqs = FAQBD.getInstancia();
				int id = Integer.parseInt(req.getParameter("id"));
				faqs.deleteFAQ(id);
				req.setAttribute("faqs.mensaje", "FAQ eliminada correctamente");
			} else {
				req.setAttribute("faqs.mensaje", "Error al eliminar FAQ");
			}

			return siguiente;

		} catch (NumberFormatException e1) {
			throw new FAQComandoException("FAQComandoDelete: " + e1.getMessage());
		} catch (FAQDesconocidoException e2) {
			throw new FAQComandoException("FAQComandoDelete: " + e2.getMessage());
		} catch (FAQBDException e3) {
			throw new FAQComandoException("FAQComandoDelete: " + e3.getMessage());
		}
	}
}
	  