package faqs.comandos;

/**
  * La excepcion FAQComandoException se lanza cuando ocurre algun error
  * al ejecutar un comando (clase que implemente la interfaz FAQComando)
  */
public class FAQComandoException extends Exception
{	
	/**
	  * Constructor
	  */
	public FAQComandoException()
	{
		super();
	}

	/**
	  * Constructor
	  * @param msg Mensaje de la excepcion
	  */
	public FAQComandoException(String msg)
	{
		super(msg);
	}	
}
	  