package faqs.comandos;

import javax.servlet.*;
import javax.servlet.http.*;

import faqs.bd.*;
import faqs.*;

/**
  * La clase FAQComandoGet es un comando que obtiene una FAQ con
  * un ID determinado
  */
public class FAQComandoGet implements FAQComando
{	
	/**
	  * Siguiente pagina a mostrar
	  */
	private String siguiente;
	
	/**
	  * Constructor
	  * @param siguiente Siguiente pagina a visitar
	  */
	public FAQComandoGet(String siguiente)
	{
		this.siguiente = siguiente;
	}
	
	/**
	  * Ejecuta el comando
	  * @param req Datos de la peticion del cliente
	  */
	public String ejecutar(HttpServletRequest req) throws FAQComandoException
	{
		try
		{
			FAQBD faqs = FAQBD.getInstancia();
			int id = Integer.parseInt(req.getParameter("id"));
			FAQBean faq = faqs.getFAQ(id);
			req.setAttribute("faq", faq);
			return siguiente;
		} catch (NumberFormatException e1) {
			throw new FAQComandoException("FAQComandoGet: " + e1.getMessage());
		} catch (FAQDesconocidoException e2) {
			throw new FAQComandoException("FAQComandoGet: " + e2.getMessage());
		} catch (FAQBDException e3) {
			throw new FAQComandoException("FAQComandoGet: " + e3.getMessage());
		}
	}
}
	  