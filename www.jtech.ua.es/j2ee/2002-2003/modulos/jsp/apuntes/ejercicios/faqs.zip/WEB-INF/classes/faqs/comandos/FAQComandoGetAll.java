package faqs.comandos;

import javax.servlet.*;
import javax.servlet.http.*;

import faqs.bd.*;
import faqs.*;

/**
  * La clase FAQComandoGetAll es un comando que obtiene todas las
  * FAQs de la base de datos
  */
public class FAQComandoGetAll implements FAQComando
{	
	/**
	  * Siguiente pagina a mostrar
	  */
	private String siguiente;
	
	/**
	  * Constructor
	  * @param siguiente Siguiente pagina a visitar
	  */
	public FAQComandoGetAll(String siguiente)
	{
		this.siguiente = siguiente;
	}
	
	/**
	  * Ejecuta el comando
	  * @param req Datos de la peticion del cliente
	  */
	public String ejecutar(HttpServletRequest req) throws FAQComandoException
	{
		try
		{
			FAQBD faqs = FAQBD.getInstancia();
			FAQBean[] lista = faqs.getFAQs();
			req.setAttribute("faqs", lista);
			return siguiente;
		} catch (FAQBDException e) {
			throw new FAQComandoException("FAQComandoGetAll: " + e.getMessage());
		}
	}
}
	  