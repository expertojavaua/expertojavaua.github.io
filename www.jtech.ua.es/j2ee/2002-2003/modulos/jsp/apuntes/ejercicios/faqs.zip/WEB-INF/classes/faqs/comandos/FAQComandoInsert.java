package faqs.comandos;

import javax.servlet.*;
import javax.servlet.http.*;

import faqs.bd.*;
import faqs.*;

/**
  * La clase FAQComandoInsert es un comando que a�ade una FAQ
  * a la base de datos
  */
public class FAQComandoInsert implements FAQComando
{	
	/**
	  * Siguiente pagina a mostrar
	  */
	private String siguiente;
	
	/**
	  * Constructor
	  * @param siguiente Siguiente pagina a visitar
	  */
	public FAQComandoInsert(String siguiente)
	{
		this.siguiente = siguiente;
	}
	
	/**
	  * Ejecuta el comando
	  * @param req Datos de la peticion del cliente
	  */
	public String ejecutar(HttpServletRequest req) throws FAQComandoException
	{
		try
		{
			// Es un comando critico que no debe repetirse accidentalmente
			
			if (FAQComandoToken.isValida(req))
			{
				FAQBD faqs = FAQBD.getInstancia();
				FAQBean faq = new FAQBean();
				faq.setPregunta(req.getParameter("pregunta"));
				faq.setRespuesta(req.getParameter("respuesta"));
				faqs.insertFAQ(faq);
				req.setAttribute("faqs.mensaje", "FAQ a�adida correctamente");
			} else {
				req.setAttribute("faqs.mensaje", "Error al a�adir FAQ");
			}

			return siguiente;

		} catch (FAQBDException e) {
			throw new FAQComandoException("FAQComandoInsert: " + e.getMessage());
		}
	}
}
	  