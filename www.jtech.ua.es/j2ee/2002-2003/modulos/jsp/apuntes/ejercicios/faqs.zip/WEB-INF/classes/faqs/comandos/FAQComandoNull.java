package faqs.comandos;

import javax.servlet.*;
import javax.servlet.http.*;

/**
  * La clase FAQComandoNull es un comando vac�o, que simplemente
  * devuelve la siguiente pagina a la que debe ir el flujo del 
  * programa
  */
public class FAQComandoNull implements FAQComando
{	
	/**
	  * Siguiente pagina a mostrar
	  */
	private String siguiente;
	
	/**
	  * Constructor
	  * @param siguiente Siguiente pagina a visitar
	  */
	public FAQComandoNull(String siguiente)
	{
		this.siguiente = siguiente;
	}
	
	/**
	  * Ejecuta el comando
	  * @param req Datos de la peticion del cliente
	  */
	public String ejecutar(HttpServletRequest req) throws FAQComandoException
	{
		return siguiente;
	}
}
	  