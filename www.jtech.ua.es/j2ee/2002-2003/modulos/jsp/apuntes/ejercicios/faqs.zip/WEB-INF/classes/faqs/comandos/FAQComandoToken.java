package faqs.comandos;

import javax.servlet.http.*;
import java.security.*;

/**
  * La clase FAQComandoToken asegura que no se va a realizar una
  * misma accion repetidamente de forma accidental
  */
public class FAQComandoToken
{	
	/**
	  * Establece un token asociado para una petici�n determinada
	  * @param req Datos de la peticion
	  */
	public static void set(HttpServletRequest req)
	{
		HttpSession sesion = req.getSession(true);
		
		long tiempoms = System.currentTimeMillis();
		byte[] tiempo = new Long(tiempoms).toString().getBytes();
		byte[] id = sesion.getId().getBytes();
		
		try
		{
			MessageDigest md5 = MessageDigest.getInstance("MD5");
			md5.update(id);
			md5.update(tiempo);
			String token = toHex(md5.digest());
			req.setAttribute("token", token);
			sesion.setAttribute("token", token);
		} catch (Exception e) {
			System.err.println ("Error al calcular codificacion MD5");
		}
	}

	/**
	  * Comprueba si una peticion es valida
	  * @param req Datos de la peticion
	  */
	public static boolean isValida(HttpServletRequest req)
	{
		HttpSession sesion = req.getSession(true);
		String tokenReq = req.getParameter("token");
		String tokenSes = (String)sesion.getAttribute("token");
		
		if (tokenReq == null || tokenSes == null)
			return false;
		return (tokenReq.equals(tokenSes));
	}
	
	/**
	  * Convierte un array de bytes a una cadena de hexadecimales
	  * @param datos Datos a convertir
	  * @return Una cadena con los bytes convertidos a hexadecimal
	  */
	private static String toHex(byte[] datos)
	{
		StringBuffer buf = new StringBuffer();
		for (int i = 0; i < datos.length; i++)
			buf.append(Integer.toHexString((int)datos[i] & 0x00ff));
		return buf.toString();
	}
	
}
	  