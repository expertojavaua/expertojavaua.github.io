package faqs.comandos;

import javax.servlet.*;
import javax.servlet.http.*;

import faqs.bd.*;
import faqs.*;

/**
  * La clase FAQComandoUpdate es un comando que actualiza una FAQ
  * en la base de datos
  */
public class FAQComandoUpdate implements FAQComando
{	
	/**
	  * Siguiente pagina a mostrar
	  */
	private String siguiente;
	
	/**
	  * Constructor
	  * @param siguiente Siguiente pagina a visitar
	  */
	public FAQComandoUpdate(String siguiente)
	{
		this.siguiente = siguiente;
	}
	
	/**
	  * Ejecuta el comando
	  * @param req Datos de la peticion del cliente
	  */
	public String ejecutar(HttpServletRequest req) throws FAQComandoException
	{
		try
		{
			// Es un comando critico que no debe repetirse accidentalmente
			
			if (FAQComandoToken.isValida(req))
			{
				FAQBD faqs = FAQBD.getInstancia();
				FAQBean faq = new FAQBean();
				faq.setId(Integer.parseInt(req.getParameter("id")));
				faq.setPregunta(req.getParameter("pregunta"));
				faq.setRespuesta(req.getParameter("respuesta"));
				faqs.updateFAQ(faq);
				req.setAttribute("faqs.mensaje", "FAQ actualizada correctamente");
			} else {
				req.setAttribute("faqs.mensaje", "Error al actualizar FAQ");
			}

			return siguiente;

		} catch (NumberFormatException e1) {
			throw new FAQComandoException("FAQComandoUpdate: " + e1.getMessage());
		} catch (FAQDesconocidoException e2) {
			throw new FAQComandoException("FAQComandoUpdate: " + e2.getMessage());
		} catch (FAQBDException e3) {
			throw new FAQComandoException("FAQComandoUpdate: " + e3.getMessage());
		}
	}
}
	  