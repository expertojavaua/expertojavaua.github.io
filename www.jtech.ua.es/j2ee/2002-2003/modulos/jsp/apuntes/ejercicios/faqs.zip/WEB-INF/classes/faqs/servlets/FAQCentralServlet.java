package faqs.servlets;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

import faqs.comandos.*;

/**
  * La clase FAQCentralServlet centraliza todo el acceso a las p�ginas
  * de la administracion de FAQs, indicando qu� p�gina cargar y
  * qu� acci�n realizar
  */
public class FAQCentralServlet extends HttpServlet
{
	/**
	  * Comandos que se pueden solicitar
	  */
	private HashMap comandos;
	
	/**
	  * Pagina de error
	  */
	private String error = "error.jsp";

	/**
	  * Directorio de las paginas JSP
	  */
	private String dirJSP = "/jsp/";

	// ============== METODOS PRINCIPALES DEL SERVLET ==============
		
	/**
	  * Metodo de inicializacion
	  * @param config Configuracion del servlet
	  */
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		
		comandos = new HashMap();
		comandos.put("menu", new FAQComandoNull("menu.jsp"));
		comandos.put("abortar", new FAQComandoAbortar("menu.jsp"));
		comandos.put("insert", new FAQComandoNull("insert.jsp"));
		comandos.put("exe-insert", new FAQComandoInsert("menu.jsp"));
		comandos.put("menu-update", new FAQComandoGetAll("update_menu.jsp"));
		comandos.put("update", new FAQComandoGet("update.jsp"));
		comandos.put("exe-update", new FAQComandoUpdate("menu.jsp"));
		comandos.put("menu-delete", new FAQComandoGetAll("delete_menu.jsp"));
		comandos.put("delete", new FAQComandoGet("delete.jsp"));
		comandos.put("exe-delete", new FAQComandoDelete("menu.jsp"));		
	}

	/**
	  * Metodo de procesamiento de peticion
	  * @param req Datos de la peticion
	  * @param res Datos de la respuesta
	  */
	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		String siguiente;
		
		try
		{
			FAQComando cmd = getComando(req.getParameter("cmd"));
			siguiente = cmd.ejecutar(req);
			FAQComandoToken.set(req);
		} catch (FAQComandoException e) {
			req.setAttribute("javax.servlet.jsp.jspException", e);
			siguiente = error;
		}
		
		RequestDispatcher rd = getServletContext().getRequestDispatcher(dirJSP + siguiente);
		rd.forward(req, res);
	}
	

	// ============== METODOS AUXILIARES ==============
	
	/**
	  * Obtiene un comando indicado por un nombre
	  * @param cmd Nombre del comando que se busca
	  * @return Un objeto FAQComando con el comando solicitado
	  */
	private FAQComando getComando(String cmd) throws FAQComandoException
	{
		if (cmd == null)
			cmd = "menu";
		if (comandos.containsKey(cmd.toLowerCase()))
			return (FAQComando)comandos.get(cmd.toLowerCase());
		else
			throw new FAQComandoException("Comando invalido");
	}
}
	  