package faqs.servlets;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

import faqs.comandos.*;

/**
  * La clase FAQServlet obtiene las FAQs de la base de datos
  * atendiendo a unos par�metros que se le indican
  */
public class FAQServlet extends HttpServlet
{
	/**
	  * Pagina de error
	  */
	private String error = "jsp/error.jsp";

	/**
	  * Directorio de las paginas JSP
	  */
	private String dirJSP = "/";

	/**
	  * Metodo de procesamiento de peticion
	  * @param req Datos de la peticion
	  * @param res Datos de la respuesta
	  */
	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		String siguiente;
		FAQComando cmd;
		
		try
		{
			siguiente = req.getParameter("pagina");
			if (siguiente == null)
				throw new FAQComandoException("Pagina no especificada");

			if (req.getParameter("id") != null)
				cmd = new FAQComandoGet(siguiente);
			else
				cmd = new FAQComandoGetAll(siguiente);
			cmd.ejecutar(req);
			
		} catch (FAQComandoException e) {
			req.setAttribute("javax.servlet.jsp.jspException", e);
			siguiente = error;
		}
		
		RequestDispatcher rd = getServletContext().getRequestDispatcher(dirJSP + siguiente);
		rd.forward(req, res);
	}
}
	  