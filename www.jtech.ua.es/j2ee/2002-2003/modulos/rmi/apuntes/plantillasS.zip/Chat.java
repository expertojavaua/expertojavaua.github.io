
import java.rmi.*;

public interface Chat extends Remote {

    public void chatNotify(Message m) throws RemoteException;
    public String getName() throws RemoteException;

}
