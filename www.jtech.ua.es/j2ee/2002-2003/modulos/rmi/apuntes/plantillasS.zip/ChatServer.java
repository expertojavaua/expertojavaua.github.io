
import java.rmi.*;

public interface ChatServer extends Remote {

   //register a chatter with the server. Pass a reference to the 
   //Chat client, and a name that it will be used to identify the user
   public void register(Chat c,String name) throws RemoteException;

   //This is used to post broadcast messages to the server
   public void postMessage(Message m) throws RemoteException;

   //This will return a list of all of the chatters that 
   //are currently logged onto this server
   public String[] listChatters() throws RemoteException;

}
