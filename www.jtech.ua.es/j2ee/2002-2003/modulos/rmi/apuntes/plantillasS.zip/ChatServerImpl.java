

import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
import java.util.*;

public 	class ChatServerImpl 
extends UnicastRemoteObject 
implements ChatServer {

	//The chatters Vector maintains a list of
	//all registered Chat clients
	private Vector chatters = new Vector();

	public ChatServerImpl() throws RemoteException {
	   super();
	   System.out.println("Initializing Server...");
	}

	public static void main(String args[]){

	   Registry reg;
	   //A security manager must be set to allow stub
  	   //loading over the network
          if (System.getSecurityManager() == null)
	   System.setSecurityManager(new RMISecurityManager());
	   try {
	      //create an instance of the ChatServerImpl object to
	      //export
	      ChatServer cs = new ChatServerImpl();

	      //create a new registry running on port 5060
	      //reg = LocateRegistry.createRegistry(5060);

	      //bind our cs object to this registry
	      //reg.bind("//192.168.12.16/:5060"+"/ChatServerImpl", cs);
	      System.out.println("acceso a Naming");
          Naming.rebind("//" + java.net.InetAddress.getLocalHost().getHostAddress()+":" + "1200" +"/ChatServerImpl",cs);
	      
	      System.out.println("Server Ready");
	   } 
//	   catch (AlreadyBoundException e) {
//	      System.out.println("This name is already bound: " + e);
//	      System.exit(0);
//	   } 
	   catch (RemoteException e) {
	      System.out.println("General ChatServer Error: " + e);
	      //System.exit(0);
	   } 
	     catch (Exception e) {
	      //System.out.println("Mal formed URL exception: " + e);
              e.printStackTrace();
	      //System.exit(0);
	   } 
	}

	synchronized public void register(Chat c, String name) {
	   System.out.println("voy a proceder al registro");
	   chatters.addElement(new Talker(c,name)); 
	   System.out.println("registrado  "+name);
	}

	public String[] listChatters() {
	      String list[] = new String[chatters.size()];
	      Talker c;

	      for(int i=0; i< list.length; i++){
		   c=(Talker)chatters.elementAt(i);
		   list[i] = c.getChatterName();
	      }
	      return list;
	}

	synchronized public void postMessage(Message m){
	   Talker t;
	   for(int i=0; i < chatters.size() ; i++){
	      t = (Talker)chatters.elementAt(i);
	      System.out.println("mensaje: "+m.getMessage()+ " de usuario "+ i);
	      if(!t.addMessage(m))
	        chatters.removeElementAt(i);
	   }
		
	}
}
