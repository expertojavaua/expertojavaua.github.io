

import java.util.*;
import java.rmi.*;

class ServerTalker extends Thread {

	private Vector messages = new Vector();	
	private ChatServer cs;
	private boolean isSuspended = false;
	//private boolean volatile isSuspended = false;

	public ServerTalker(ChatServer cs, String name) {
		this.cs = cs;
		//Send a welcome message
		messages.addElement(new 
		   Message("***", name + " acaba de conectar***"));
		this.start();
	}

	public boolean addMessage(Message e){

	}

	public void run() {

	    }

	}
}

