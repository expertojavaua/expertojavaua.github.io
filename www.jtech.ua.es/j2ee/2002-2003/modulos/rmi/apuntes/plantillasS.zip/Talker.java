

import java.util.*;
import java.rmi.*;

public class Talker extends Thread {

	private Vector messages = new Vector();	
	private Chat c;
	boolean isActive = true;
	private boolean isSuspended = false;
	private String name;

	public Talker(Chat c,String name) {
	   this.c = c;
	   this.name=name;
	   this.start();
	}


	public boolean addMessage(Message e){
	  boolean result;
	   if(!isActive)
	     return false;
	   // synchronized (this) {
	   //   isSuspended=false;
           //notify();
           //}  	
	     //resume();
	     messages.addElement(e);
	     System.out.println("mensaje anyadido en Talker: "+e.getMessage());
	    synchronized (this) {
	      isSuspended=false;
              notify();
            }  	
	     return true;
	}

	public void run() {

//	    while(true){
	    while(isActive){	    	
	        try {
	   	
		 if(messages.isEmpty()) {
		 	System.out.println("No hay mensajes");
            synchronized(this) {
              isSuspended = true;
              while (isSuspended)
                wait();
           }
		 }; //if
			//suspend();
			   System.out.println("Talker despertado");
	           c.chatNotify((Message)messages.elementAt(0));
	           System.out.println("mensaje notificado en Talker");
	           messages.removeElementAt(0);
	           System.out.println("mensaje eliminado en Talker");
	        } catch (ArrayIndexOutOfBoundsException e) {
		  System.out.println("postMessage: " + e);
	        } catch (RemoteException e) {
		  System.out.println("Removing "+ name);
		  isActive=false;
		  //this.stop();
	        } catch (InterruptedException e) {
		  System.out.println("postMessage: " + e);
	        }
		yield();
	    }

	}
	
   public String getChatterName() {
      return name;
   }
}
