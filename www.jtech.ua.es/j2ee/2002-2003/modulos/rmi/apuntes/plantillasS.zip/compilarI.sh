export CLASSPATH=./objRemotos.jar:.
javac Message.java
javac Chat.java
javac ChatServer.java
jar -cvf objRemotos.jar Chat.class ChatServer.class Message.class
