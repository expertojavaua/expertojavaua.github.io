export CLASSPATH=./objRemotos.jar:.
cp ../interfaces/objRemotos.jar .
javac Talker.java
javac ChatServerImpl.java
javac ServerTalker.java
rmic -d . ChatServerImpl 
jar -uvf objRemotos.jar ServerTalker.class
