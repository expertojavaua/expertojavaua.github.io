import java.security.*;
import javax.crypto.*;

// Ejercicio 1: Probar el algoritmo TripleDES

public class Ejercicio1 
{
  public static void main (String[] args)
  throws Exception
  {
    if (args.length != 1) {
      System.err.println("Uso: java Ejercicio1 texto_a_encriptar");
      System.exit(1);
    }
    String text = args[0];

    System.out.println("Generando clave TripleDES...");

    // Crear una clave TripleDES

    System.out.println("Clave generada.");

    // Mostrar la clave

    // Crear e incializar cifrador

    byte[] plaintext = text.getBytes("UTF8");

    // Imprimir los bytes del texto de entrada
    System.out.println("\nTexto de entrada: ");
    for (int i=0;i<plaintext.length;i++) {
		System.out.print(plaintext[i]+" ");
	}

    // Encriptar 

    // Imprimir el texto cifrado 
    System.out.println("\n\nTexto cifrado: ");
    for (int i=0;i<ciphertext.length;i++) {
		System.out.print(ciphertext[i]+" ");
	}

    // Reinicializar cifrador para desencriptar

    // Desencriptar

    String output = new String(decryptedText,"UTF8");

    System.out.println("\n\nTexto desencriptado: "+output);


  }
}
