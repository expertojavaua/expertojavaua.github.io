import java.io.*;
import java.net.*;
import java.math.*;
import java.security.*;
import java.security.spec.*;
import javax.crypto.*;
import javax.crypto.spec.*;

public class Cliente {

  public static void main (String[] args) throws Exception {

    if (args.length != 2) {
      System.err.println("Uso: java Cliente host puerto");
      System.exit(1);
    }

    String host = args[0];
    int puerto = Integer.parseInt(args[1]);

    // 1. Crear una clave sim�trica para Blowfish
    System.out.println("Generando clave Sim�trica Blowfish...");
    KeyGenerator generador = KeyGenerator.getInstance("Blowfish");
    generador.init(128);
    Key claveBlowfish = generador.generateKey();

    // 2. Establecer conexi�n con el servidor y recibir clave p�blica
    // a. Establecer conexion
    System.out.println("Intentando conexi�n a "+host+", puerto "+puerto+".");
    Socket s = new Socket (host,puerto);
    DataOutputStream out = new DataOutputStream(s.getOutputStream());
    DataInputStream in = new DataInputStream(s.getInputStream());

    // b. Recibir la clave p�blica del servidor
    System.out.println("Recibiendo clave p�blica del servidor.");
    byte[] bytesClave = new byte[in.readInt()];
    in.readFully(bytesClave);
    KeyFactory kf = KeyFactory.getInstance("RSA");
    X509EncodedKeySpec x509Spec = new X509EncodedKeySpec(bytesClave);
    PublicKey clavePublica = kf.generatePublic(x509Spec);

    // 3. Encriptar la clave privada con la clave p�blica recibida y enviarla
    // a. Crear e inicializar un cifrador adecuado (ECB)
    Cipher cifradorRSA = Cipher.getInstance("RSA/ECB/PKCS1Padding");
    cifradorRSA.init(Cipher.ENCRYPT_MODE, clavePublica);

    // b.Obtener bytes de la clave sim�trica y encriptarlos con RSA
    byte[] bytesClaveBlowfish = claveBlowfish.getEncoded();
    byte[] claveBlowfishCifrada = cifradorRSA.doFinal(bytesClaveBlowfish);
    System.out.println("Encriptada la clave sim�trica");
    
    // c. Enviar la clave sim�trica
    System.out.println("Enviando mi clave sim�trica encriptada.");
    out.writeInt(claveBlowfishCifrada.length);
    out.write(claveBlowfishCifrada);

    // 4. Preparar el cifrado de stream y realizar comunicaci�n

    // a. Recibir el IV
    byte[] iv = new byte[8];
    in.readFully(iv);

    // b. Crear el cifrador de stream
    System.out.println("Creando el cifrador de stream...");
    Cipher encriptador = Cipher.getInstance("Blowfish/CFB8/NoPadding");
    IvParameterSpec spec = new IvParameterSpec(iv);
    encriptador.init(Cipher.ENCRYPT_MODE, claveBlowfish, spec);


    CipherOutputStream cifradorOut = new CipherOutputStream(s.getOutputStream(), encriptador);

    // c. Enviar la primera cadena
    String cadenaTest = "Conexi�n establecida.\n\n";
    byte[] bytesTest = cadenaTest.getBytes();
    cifradorOut.write(bytesTest);

    System.out.println("Conexi�n establecida.\n");

    // d. Enviar cualquier cosa que escriba el cliente
    int car=0;
    car = System.in.read();
    while (car != '~') // Escape para salir
    {
      cifradorOut.write(car);
      car = System.in.read();
    }

    // Clean up
    cifradorOut.close();
    in.close();
    out.close();
    s.close();
  }
}
