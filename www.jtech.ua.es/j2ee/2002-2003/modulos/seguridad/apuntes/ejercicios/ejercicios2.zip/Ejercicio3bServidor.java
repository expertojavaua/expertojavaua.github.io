import java.io.*;
import java.net.*;
import java.math.*;
import java.security.*;
import java.security.spec.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import javax.crypto.interfaces.*;

// Ejercicio3b: Modificar para utilizar ElGamal

public class Ejercicio3bServidor {

  public static void main (String[] args) throws Exception {

    if (args.length != 1) {
      System.err.println("Uso: java Ejemplo3bServidor puerto");
      System.exit(1);
    }

    int puerto = Integer.parseInt(args[0]);

    // 1. Generar un par El Gamal y enviar la clave p�blica 
    // a. Generar el par El Gamal 
    System.out.println("Generada la clave asim�trica.");

    // b. Abrir el puerto y un stream de salida
    ServerSocket ss = new ServerSocket (puerto);
    System.out.println("Escuchando en el puerto "+puerto+"...");
    Socket socket = ss.accept();
    DataOutputStream out = new DataOutputStream(socket.getOutputStream());

    // c. Enviar la clave p�blica
    System.out.println("Enviando mi clave p�blica.");
    byte[] bytesClave = claves.getPublic().getEncoded();
    out.writeInt(bytesClave.length);
    out.write(bytesClave);


    // 2. Recibir y Desencriptar la clave secreta del cliente (Blowfish) que
    // est� encriptada con la clave p�blica del servidor


    // a. Recibir los bytes de la clave secreta del cliente
    System.out.println("Recibiendo clave secreta del cliente...");
    DataInputStream in = new DataInputStream(socket.getInputStream());
    bytesClave = new byte[in.readInt()];
    in.readFully(bytesClave);

    // b. Inicializar cifrador ElGamal para desencriptar con la clave privada

    // c. Desencriptar la clave
    byte[] bytesClaveBlowfish= cifradorElGamal.doFinal(bytesClave);
    System.out.println("Ya la hemos desencriptado");


    // 3. Inicializar el Cifrador de Stream con la clave privada

    // a. Crear y enviar el IV
    byte[] iv = new byte[8];
    SecureRandom sr = new SecureRandom();
    sr.nextBytes(iv);
    out.write(iv);

    // b. Recrear la clave Blowfish a partir de los bytes
    SecretKey claveBlowfish = new SecretKeySpec(bytesClaveBlowfish, "Blowfish");

    // c. Crear el cifrador de Stream
    System.out.println("Creando el cifrador de stream...");
    Cipher desencriptador = Cipher.getInstance("Blowfish/CFB8/NoPadding");
    IvParameterSpec spec = new IvParameterSpec(iv);
    desencriptador.init(Cipher.DECRYPT_MODE, claveBlowfish, spec);
    CipherInputStream cifradorIn = new CipherInputStream(socket.getInputStream(), desencriptador);

    // d. Imprimir todo lo recibido por el cifrador
    int car=0;
    car = cifradorIn.read();
    while (car != -1) {
      System.out.print((char)car);
      car = cifradorIn.read();
    }

    // e. Cerrar
    cifradorIn.close();
    in.close();
    out.close();
    socket.close();

  }
}
