package arranque.objetos;

public class Jefe implements java.io.Serializable
{
	String name;

	public Jefe() {
		name = "Miguel Cazorla";
	}

	public String getName() {
		return name;
	}

}