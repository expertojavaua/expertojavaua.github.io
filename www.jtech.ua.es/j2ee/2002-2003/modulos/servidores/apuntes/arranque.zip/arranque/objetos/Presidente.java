package arranque.objetos;

public class Presidente implements java.io.Serializable
{
	String name;

	public Presidente() {
		name = "Domingo Gallardo";
	}

}