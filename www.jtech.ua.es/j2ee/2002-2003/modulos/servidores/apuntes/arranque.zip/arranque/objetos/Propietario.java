package arranque.objetos;

public class Propietario implements java.io.Serializable
{
	String name;

	public Propietario() {
		name = "Otto Colomina";
	}

}