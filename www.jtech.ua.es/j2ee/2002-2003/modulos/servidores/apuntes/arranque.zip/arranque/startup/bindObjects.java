package arranque.startup;

import weblogic.common.T3StartupDef;
import weblogic.common.T3ServicesDef;
import java.util.Hashtable;
import arranque.objetos.*;
import javax.naming.InitialContext;
import javax.naming.Context;


public class bindObjects implements T3StartupDef
{
	public bindObjects() {}

	public String startup(String name, Hashtable ht)
	{
		System.out.println("");
		System.out.println("");
		System.out.println("Nombre de la clase de arranque: " + name);
		System.out.println("");
		System.out.println("");

		Jefe jefe = new Jefe();
		Propietario propietario = new Propietario();
		Presidente presidente = new Presidente();

		try
		{
			InitialContext ic = new InitialContext();
			ic.createSubcontext("com");

			Context context = (Context) ic.lookup("com");
			context.createSubcontext("bea");

			context = (Context) ic.lookup("com.bea");
			context.createSubcontext("ejecutivos");

			context = (Context) ic.lookup("com.bea.ejecutivos");

			context.bind("Ejecutivo en jefe", jefe);
			context.bind("Propietario", propietario);
			context.bind("Presidente", presidente);

		} catch (Exception e) {
			System.out.println("Ocurrio el error: " + e);
		}

		return name;

	}

	public void setServices(T3ServicesDef serv) {}

}