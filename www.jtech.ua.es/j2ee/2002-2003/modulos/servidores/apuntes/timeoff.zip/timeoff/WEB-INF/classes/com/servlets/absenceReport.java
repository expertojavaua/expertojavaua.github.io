package com.servlets;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.Enumeration;

public class absenceReport extends HttpServlet
{
	public void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		response.setContentType("text/html");
		ServletOutputStream out = response.getOutputStream();

		out.print("<HTML><HEAD><TITLE>Absence Report Filed</TITLE></HEAD>");
		out.print("<BODY>");

		out.print("<CENTER>");
		String empname = request.getParameter("empname");
		String month = request.getParameter("month");
		String year = request.getParameter("year");
		String hours = request.getParameter("hours");
		String name = request.getParameter("managersname");
		String email = request.getParameter("managersemail");


		if ((hours.equals("")) || (name.equals("")) || (email.equals("")) || (empname.equals("")))
			out.print("<BR>You need to fill out the form in its entirety<BR>");

		else {
			out.print("<FONT SIZE='4' COLOR='navy'>");
			out.print("Report for: " + empname + "<BR>");
			out.print("Time Off In Hours: " + hours + " in " + month + ", " + year + "<BR>");
			out.print("This report has been submitted to " + name + " at " + email);
			out.print("</FONT><BR>");

		}

		out.print("<BR><A HREF='./welcome.html'>Back To Home Page</A><BR>");
		out.print("</CENTER>");
		out.print("<BR><BR><BR><HR>Copyright Staplerz 2001</HR>");
		out.print("</BODY></HTML>");

	}
}