package com.servlets;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.Enumeration;

public class officeClosing extends HttpServlet
{
	public void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		response.setContentType("text/html");
		ServletOutputStream out = response.getOutputStream();

		out.print("<HTML><HEAD><TITLE>Office Closing Announcement</TITLE></HEAD>");
		out.print("<BODY>");

		out.print("<CENTER>");
		String reason = request.getParameter("reason");
		String date = request.getParameter("date");


		if ((reason.equals("")) || (date.equals("")))
			out.print("<BR>You need to fill out the form in its entirety<BR>");

		else {
			out.print("<FONT SIZE='4' COLOR='navy'>");
			out.print("A message has been sent to all employees that the office<BR>");
			out.print("is closing on " + date + " for the following reason<BR>");
			out.print(reason);
			out.print("</FONT><BR>");

		}

		out.print("<BR><A HREF='./welcome.html'>Back To Home Page</A><BR>");
		out.print("</CENTER>");
		out.print("<BR><BR><BR><HR>Copyright Staplerz 2001</HR>");
		out.print("</BODY></HTML>");

	}
}