import java.net.*;
import java.io.*;

class ServHTTP {
	
   public static final int DEFAULT_PORT = 80;	
   private Socket conexion;
   private InputStream peticion;
   private OutputStream respuesta;
  
   
   public ServHTTP() throws IOException {
      this(DEFAULT_PORT);      
   }
   
   public ServHTTP(int puerto) throws UnknownHostException, IOException {
      ServerSocket serv;
      
      serv = new ServerSocket(puerto);      
   	  conexion = serv.accept();
   	  peticion = conexion.getInputStream();
   	  respuesta = conexion.getOutputStream();
   }
   
      
   public void enviarRespuesta(String res) throws IOException {
      PrintWriter salida = new PrintWriter(respuesta);
      salida.println(res);
      salida.flush();
      salida.close();
   }
   
   public String recibirPeticion() throws IOException {
   	  StringBuffer buf;
      BufferedReader entrada;
      String linLeida;
   	  
   	  entrada = new BufferedReader(new InputStreamReader(peticion));   	  
   	  buf=new StringBuffer();
   	  linLeida = entrada.readLine();
   	  while (!linLeida.equals("")) { 
   	  	 buf.append(linLeida + "\n");
   	     linLeida = entrada.readLine();
   	  }
   	  return buf.toString();	 	   	  	   	  
   }		
}	