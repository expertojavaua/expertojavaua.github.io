import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.io.*;
import java.net.*;

class ServidorHTTP extends JFrame implements ActionListener {
   
   private final static String DEFAULT_PORT="80";
   private JTextArea textoPeticion, textoRespuesta;
   private JTextField textoPuerto;
   private JButton botonEnviar, botonConectar;
   private JLabel etiqCon;
   ServHTTP conexion;
      	   
   public ServidorHTTP() {
      super("Simulador de servidor HTTP");      
      crearGUI();
      setVisible(true);      	
   }
   
   
   private void crearGUI() {
      Dimension tamPantalla;
      JPanel panelGlobal;
      Container panelCon, boxPuerto, boxCon;
            
      //hacer que la ventana ocupe la mitad del ancho y alto de la pantalla
      tamPantalla = Toolkit.getDefaultToolkit().getScreenSize();
      setSize(tamPantalla.width/2, tamPantalla.height/2);
      
      //hacer que se salga de la aplicaci�n cuando se cierre la ventana
      addWindowListener(new WindowAdapter() {
      	                      public void windowClosing(WindowEvent e) {
      	                      	 System.exit(0);
      	                      }
      	                    });	
      	                    
      //panel para datos de la conexion
      panelCon = Box.createVerticalBox();
      boxPuerto = Box.createHorizontalBox();
      boxPuerto.add(new JLabel("Puerto:"));
      textoPuerto = new JTextField(DEFAULT_PORT);
      boxPuerto.add(textoPuerto);
      boxCon = Box.createHorizontalBox();
      botonConectar = new JButton("Esperar peticion");
      boxCon.add(botonConectar);
      panelCon.add(boxPuerto);
      panelCon.add(boxCon);
      
      //panel donde aparecen la petici�n y la respuesta  
      Border borde = BorderFactory.createEtchedBorder();
      JPanel panelES = new JPanel();
      panelES.setLayout(new BoxLayout(panelES, BoxLayout.Y_AXIS));
      
      textoPeticion = new JTextArea();
      textoPeticion.setRows(6);
      textoPeticion.setEditable(false);
      JScrollPane sc = new JScrollPane(textoPeticion);
      sc.setBorder(BorderFactory.createTitledBorder(borde, "Petici�n del cliente"));
      panelES.add(sc);
      
      textoRespuesta = new JTextArea();
      textoRespuesta.setRows(6);
      sc = new JScrollPane(textoRespuesta);
      sc.setBorder(BorderFactory.createTitledBorder(borde, "Respuesta del servidor"));
      panelES.add(sc);
      botonEnviar = new JButton("Enviar");
      botonEnviar.setEnabled(false);
      Container boxEnviar = Box.createHorizontalBox();
      boxEnviar.add(botonEnviar);
	  panelES.add(boxEnviar);      
           
      //crear contenedor global
      panelGlobal = new JPanel();
      panelGlobal.setLayout(new BorderLayout());
      panelGlobal.add(panelCon, BorderLayout.NORTH);
      panelGlobal.add(panelES, BorderLayout.CENTER);
	  setContentPane(panelGlobal);
	  
      //manejo de eventos
      botonConectar.addActionListener(this);
      botonEnviar.addActionListener(this);
   }
   
   
   public void actionPerformed(ActionEvent e) {
   	 int puerto;
   	 
   	 if (e.getActionCommand().equals("Esperar peticion")) 
   	    conectar();
   	 else if (e.getActionCommand().equals("Enviar"))
   	    comunicar();
       	    
   }
   

   private void conectar() {
   	    int puerto;   	    
   	    
   	    //quedarse a la espera de la petici�n del cliente
   		System.out.println("Esperando petici�n del cliente");

   	 	try {
   	 	   puerto = Integer.parseInt(textoPuerto.getText());
   	       conexion = new ServHTTP(puerto);
   		}
   		catch(NumberFormatException exc) {
   		   JOptionPane.showMessageDialog(null, "Error en el n�mero de puerto");	
   		}
   		catch (IOException exc2) {
   		   JOptionPane.showMessageDialog(null, "error al hacer la conexion");	   			
   		}

   		System.out.println("Petici�n recibida");
	    try {
	       textoPeticion.setText(conexion.recibirPeticion());
	    }
   		catch (IOException exc3) {
   		   JOptionPane.showMessageDialog(null, "error de comunicaci�n");	   			
   		}
   		
	    //habilitar controles GUI para poder enviar respuesta
   		textoRespuesta.setEnabled(true);
   		botonEnviar.setEnabled(true); 
   		//deshabilitar el boton para crear socket, ya est� creado
   		botonConectar.setEnabled(false);
   }
   	
   private void comunicar() {   	
   	  //deshabilitar el env�o de respuesta, ya que el socket se cierra
   	  botonEnviar.setEnabled(false);
   	  //habilitar bot�n para crear nuevo socket
   	  botonConectar.setEnabled(true);
   	  
   	  
      try {
      	 conexion.enviarRespuesta(textoRespuesta.getText());
      }
      catch (IOException e) {
      	 JOptionPane.showMessageDialog(null, "error de entrada/salida");
      }	
   	
   }
   
   
   public static void main(String args[]) {
   	  new ServidorHTTP();
   	     	
   }
   
}	