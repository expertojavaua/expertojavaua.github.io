import java.io.*;
import java.awt.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.sun.jimi.core.*;

// Servlet que genera imagenes compatible con Java 1.1 (genera un circulo azul)

public class ServletImagenes11 extends HttpServlet
{
	// Metodo para GET
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.setContentType("image/png");
		
		// Crear el frame
		
		Frame f = new Frame();
		f.setVisible(true);
		Image img = f.createImage(150, 150);
		Graphics g = img.getGraphics();
		f.setVisible(false);

		// Dibujar la imagen

		g.setColor(Color.blue);
		g.fillOval(0, 0, 100, 100);
		
		// Crear el JimiWriter para volcar la imagen al OutputStream que se pida
		
		try
		{
			OutputStream salida = response.getOutputStream();
			JimiWriter writer = Jimi.createJimiWriter("image/png", salida);
			writer.setSource(img);
			writer.putImage(salida);
		} catch (JimiException e) {}
	}	
}