import java.io.*;
import java.awt.*;
import java.awt.image.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.sun.image.codec.jpeg.*;

// Servlet que genera imagenes compatible con Java 1.2 (genera un circulo azul)

public class ServletImagenes12 extends HttpServlet
{
	// Metodo para GET
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.setContentType("image/jpeg");
				
		// Crear la imagen
		
		BufferedImage img = new BufferedImage(150, 150, BufferedImage.TYPE_BYTE_INDEXED);
		Graphics2D g = img.createGraphics();

		// Dibujar

		g.setColor(Color.blue);
		g.fillOval(0, 0, 100, 100);
		
		// Crear el Codificador para volcar la imagen al OutputStream que se pida
		
		try
		{
			OutputStream salida = response.getOutputStream();
			JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(salida);
			encoder.encode(img);
		} catch (Exception e) {}
	}
}