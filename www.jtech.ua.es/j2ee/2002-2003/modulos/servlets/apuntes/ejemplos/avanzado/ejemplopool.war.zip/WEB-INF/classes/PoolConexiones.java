import java.sql.*;
import java.util.*;

// Clase que gestiona un pool de conexiones a una base de datos

public class PoolConexiones
{
	int maxConexiones;						// Maximo numero de conexiones permitidas
	String nombreBD;						// Nombre de la base de datos a la que se conecta
	Connection[] conexiones;				// Conjunto de conexiones
	boolean[] disponibles;					// Conexiones disponibles a true, y ocupadas a false
	
	// Constructor
	
	public PoolConexiones(int maxConexiones, String nombreBD) throws SQLException
	{
		this.maxConexiones = maxConexiones;
		this.nombreBD = nombreBD;
		conexiones = new Connection[maxConexiones];
		disponibles = new boolean[maxConexiones];

		for (int i = 0; i < maxConexiones; i++)
		{
			conexiones[i] = nuevaConexion();
			disponibles[i] = true;
		}				
	}
	
	// Crea una nueva conexion
	
	private Connection nuevaConexion() throws SQLException
	{
		try
		{
			Class.forName("org.gjt.mm.mysql.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/" + nombreBD, "root", "mysql");
			return con;
		} catch (Exception e) {
			throw new SQLException ("No se pudo encontrar el driver de conexion a la base de datos");
		}
	} 
	
	// Obtiene una conexion libre, o devuelve null si no hay ninguna
	
	public synchronized Connection conexionLibre()
	{
		for (int i = 0; i < maxConexiones; i++)
			if (disponibles[i])
			{
				disponibles[i] = false;
				return conexiones[i];
			}
		return null;
	}
	
	// Libera una conexion
	
	public synchronized void liberaConexion(Connection conexion)
	{
		for (int i = 0; i < maxConexiones; i++)
			if (conexiones[i].equals(conexion))
			{
				try
				{
					if (conexiones[i].isClosed())					
						conexiones[i] = nuevaConexion();						
					disponibles[i] = true;
				} catch (Exception ex) {}
				return;
			}
	}
	
	// Cierra una conexion
	
	public void cierraConexion(int indice)
	{
		Connection con = conexiones[indice];
		try
		{
			if (!con.isClosed())
				con.close();
		} catch (Exception ex) {}
	}	
	
	// Obtiene el maximo numero de conexiones
	
	public int getMaxConexiones()
	{
		return maxConexiones;
	}
}