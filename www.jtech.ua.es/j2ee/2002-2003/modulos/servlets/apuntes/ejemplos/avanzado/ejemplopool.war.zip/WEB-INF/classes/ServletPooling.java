import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

// Servlet que maneja un pooling de conexiones a una base de datos mediante JDBC

public class ServletPooling extends HttpServlet
{
	PoolConexiones pc;
	
	// Metodo de inicializacion
	
	public void init()
	{
		try
		{
			pc = new PoolConexiones (30, "prueba");
		} catch (Exception ex) {
			pc = null;
		}
	}
	
	// Metodo para GET
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.setContentType("text/html");
		response.setHeader("Pragma", "no-cache");
//		response.setHeader("Cache-Control", "no-cache");
		
		PrintWriter out = response.getWriter();
		
		if (pc == null)
		{
			out.println ("Error al establecer el pooling");
			return;
		}

		try
		{	
			Connection con = null;
				
			do
			{
				con = pc.conexionLibre();
			} while (con == null);

			Statement stmt = con.createStatement();

			ResultSet rs = stmt.executeQuery("SELECT * FROM datos");

			out.println ("<HTML>");
			out.println ("<BODY>");
			out.println ("Listado de nombres:");
			out.println ("<BR><BR>");
			
			while (rs.next())
			{
				out.println (rs.getString("nombre"));
				out.println ("<BR>");
			}

			out.println ("</BODY>");
			out.println ("</HTML>");

			pc.liberaConexion(con);		
			
		} catch (Exception ex) {
			out.println ("ERROR: " + ex.getMessage());
		}		
	}
	
	// Metodo de finalizacion
	
	public void destroy()
	{
		for (int i = 0; i < pc.getMaxConexiones(); i++)
		{
			pc.cierraConexion(i);
		}
	}
}