import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

// Servlet que maneja un pooling de conexiones a una base de datos mediante JDBC

public class ServletPooling2 extends ServletPooling
{
	// Metodo de inicializacion
	
	public void init()
	{
		try
		{
			pc = new PoolConexiones (1, "prueba");
		} catch (Exception ex) {
			pc = null;
		}
	}	
}