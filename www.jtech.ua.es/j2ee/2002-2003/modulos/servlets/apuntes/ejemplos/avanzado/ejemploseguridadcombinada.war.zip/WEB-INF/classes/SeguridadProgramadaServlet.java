import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

// Ejemplo de servlet que utiliza seguridad programada

public class SeguridadProgramadaServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println ("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">");
		out.println ("<HTML><BODY>");
		out.println ("<h2>El usuario es 'admin':" + (request.isUserInRole("admin")?"SI":"NO") + "</h2>");
		out.println ("<h2>El usuario es 'supervisor':" + (request.isUserInRole("supervisor")?"SI":"NO") + "</h2>");
		out.println ("<h2>El usuario es 'usuario':" + (request.isUserInRole("usuario")?"SI":"NO") + "</h2>");
		out.println ("</BODY></HTML>");
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);
	}
}