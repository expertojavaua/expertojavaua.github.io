import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

// Servlet que muestra una pagina de error

public class ErrorServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println ("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">");
		out.println ("<HTML><BODY>");
		out.println ("<h1>Error al acceder al recurso</h1>");
		out.println ("</BODY></HTML>");
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);
	}
}