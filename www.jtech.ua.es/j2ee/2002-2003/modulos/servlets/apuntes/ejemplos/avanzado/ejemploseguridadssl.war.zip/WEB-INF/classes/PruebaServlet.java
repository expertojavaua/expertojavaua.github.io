import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

// Servlet al que no deberia poderse acceder

public class PruebaServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println ("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">");
		out.println ("<HTML><BODY>");
		out.println ("<h1>No deberias poder ver esto</h1>");
		out.println ("</BODY></HTML>");
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);
	}
}