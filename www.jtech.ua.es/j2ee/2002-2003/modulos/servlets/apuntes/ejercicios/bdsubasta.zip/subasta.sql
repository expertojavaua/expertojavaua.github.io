CREATE DATABASE subasta;

USE subasta;

CREATE TABLE usuarios(
	login varchar(50) NOT NULL,
	password varchar(50) NOT NULL,
	email varchar(100) NOT NULL,
	PRIMARY KEY (login));
