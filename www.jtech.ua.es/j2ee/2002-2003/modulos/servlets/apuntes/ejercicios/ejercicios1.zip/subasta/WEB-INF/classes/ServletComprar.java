import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

// Servlet para comprar (pujar por) productos de otros usuarios

public class ServletComprar extends HttpServlet
{
}