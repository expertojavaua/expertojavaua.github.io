import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

// Servlet para entrar en el servidor de subastas

public class ServletLogin extends HttpServlet
{
}