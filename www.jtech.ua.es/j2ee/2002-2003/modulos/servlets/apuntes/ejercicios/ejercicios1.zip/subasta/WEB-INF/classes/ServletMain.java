import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

// Servlet principal del motor de subastas

public class ServletMain extends HttpServlet
{
	Vector usuarios = new Vector();			// Usuarios registrados
		
	// Metodo para GET
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{	
		// Parametros de entrada
		


		// ================ NO HAY ACCION O USUARIO ==============

		if (accion == null || login == null || password == null) {




		
		// ================= REGISTRAR UN USUARIO ================

		} else if (accion.equalsIgnoreCase("registrar")) {
			




		// ================== VALIDAR UN USUARIO =================
		
		} else if (accion.equalsIgnoreCase("validar")) {



					
		// ============ COMPRAR (PUJAR POR) UN ARTICULO ==========
						
		} else if (accion.equalsIgnoreCase("comprar")) {
			



		// =============== PONER EN VENTA UN ARTICULO ============
								
		} else if (accion.equalsIgnoreCase("vender")) {
			



		// ========== ADJUDICAR UN ARTICULO A UN USUARIO =========
			
		} else if (accion.equalsIgnoreCase("adjudicar")) {
			




		// ============ QUITAR UN ARTICULO DE LA PUJA ============

		} else if (accion.equalsIgnoreCase("cancelar")) {
			


		}
				
		// Mostrar una pagina con el estado actual de la subasta
			

		
		
		// Enlaces para vender un producto y salir al login
		


		// Lista de objetos propios, con el estado actual de la puja:
		


		// Lista de objetos ajenos, para pujar por ellos

	}
	

	// Metodo para POST
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);
	}	

	//==========================================================
	//					METODOS PARA GESTION DE USUARIOS
	//==========================================================	
	
	// Valida que los datos del usuario son correctos
	// - login: login del usuario que quiere entrar
	// - password: password del usuario
	// Devuelve true si se ha podido validar bien, false si no
	
	public boolean validaUsuario(String login, String password) 
	{
		Usuario aux = buscaUsuario(login);

		if(aux != null) 
		{
			if( aux.password.equals(password) ) 
			{
				return true;
			}
		}

		return false;
	}

	// Registra un nuevo usuario en la base de datos
	// - login: login del usuario
	// - password: password del usuario
	// Devuelve true si se ha podido registrar bien, false si no

	public boolean registraUsuario(String login, String password, String email)
	{
		Usuario aux = buscaUsuario(login);

		if(aux!=null || login.trim().equals(""))
			return false;

		aux = new Usuario(login, password, email);
		usuarios.addElement(aux);
		return true;
	}
	
	// Busca un usuario en la lista de usuarios
	// - login: Login del usuario que se busca
	// Devuelve los datos del usuario, o null si no lo encuentra

	private Usuario buscaUsuario(String login) 
	{
		Usuario aux = null;

		for(int i=0; i<usuarios.size(); i++) 
		{
			aux = (Usuario)usuarios.elementAt(i);

			if( aux.login.equals(login) )
			{
				return aux;
			}
		}

		return null;		
	}

	//==========================================================
	//		   CLASE PARA GESTION DE OBJETOS DE LA SUBASTA
	//==========================================================	
		
	class ObjetoSubasta
	{
		String producto = "";			// Nombre del producto
		double valor = 0.0;				// Valor actual (en euros)
		String usuario = null;			// Usuario que ofrece el valor actual
		String propietario = null;		// Propietario del producto
		
		// Constructor
		
		public ObjetoSubasta(String propietario, String producto, double valor)
		{
			this.usuario = propietario;
			this.propietario = propietario;
			this.producto = producto;
			this.valor = valor;
		}
		
		// Obtiene el nombre del producto
		
		public String getProducto()
		{
			return producto;
		}

		// Obtiene el valor del producto
		
		public double getValor()
		{
			return valor;
		}

		// Obtiene el usuario que hizo la mayor puja
		
		public String getUsuario()
		{
			return usuario;
		}

		// Obtiene el propietario del producto
		
		public String getPropietario()
		{
			return propietario;
		}

		// Establece el valor del producto y el usuario que paga dicho valor
		
		public void setPuja(String usuario, double valor)
		{
			this.usuario = usuario;
			this.valor = valor;
		}
	}

	//==========================================================
	//					CLASE PARA GESTION DE USUARIOS
	//==========================================================	

	class Usuario 
	{
		// Login del usuario
		public String login;
		
		// Password del usuario
		public String password;
		
		// E-mail del usuario
		public String email;

		// Crea un usuario
		// - login: Login del nuevo usuario
		// - password: Password del nuevo usuario
		// - email: E-mail del nuevo usuario

		public Usuario(String login, String password, String email) 
		{
			this.login = login;
			this.password = password;
			this.email = email;
		}
	}
}