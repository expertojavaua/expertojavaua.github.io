import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

// Servlet para dar de alta un usuario en el servidor de subastas

public class ServletRegistro extends HttpServlet
{
	// Metodo para GET
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// Cabecera
	
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println ("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">");

		out.println ("<html>");
		out.println ("<body>");
		
		// Mostramos el formulario de registro
			
		out.println ("<h1>Introduzca los datos de registro (todos los campos son obligatorios)</h1>");
		out.println ("<form action=\"/subasta/main\">");
		out.println ("<input type=\"hidden\" name=\"accion\" value=\"registrar\">");
		out.println ("Login:");
		out.println ("<input name=\"login\" value=\"\">");
		out.println ("<br>");
		out.println ("Password:");
		out.println ("<input name=\"password\" value=\"\">");
		out.println ("<br>");
		out.println ("E-mail:");
		out.println ("<input name=\"email\" value=\"\">");
		out.println ("<br>");
		out.println ("<input type=\"submit\" value=\"Enviar\">");
		out.println ("</form>");

		// Enlace para pagina de login
		
		out.println ("Ir a pagina de <a href=\"/subasta/login\">validacion</a>");
		
		// Fin
		
		out.println ("</body>");
		out.println ("</html>");
	}
	

	// Metodo para POST
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);
	}	
}