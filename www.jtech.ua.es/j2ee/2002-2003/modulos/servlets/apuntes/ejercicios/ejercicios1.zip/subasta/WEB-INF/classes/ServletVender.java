import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

// Servlet para vender un articulo propio

public class ServletVender extends HttpServlet
{
}