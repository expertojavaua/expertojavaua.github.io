package chat;

import java.util.*;
import java.io.Serializable;

public class ColaMensajes extends LinkedList implements Serializable {

	public final static int DEFAULT_SIZE = 20;

	int max_size;

	public ColaMensajes() {
		max_size = DEFAULT_SIZE;
	}

	public synchronized void addMessage(Mensaje msg) {
		addLast(msg);
		if(size() > max_size) {
			removeFirst();
		}
	}
}
