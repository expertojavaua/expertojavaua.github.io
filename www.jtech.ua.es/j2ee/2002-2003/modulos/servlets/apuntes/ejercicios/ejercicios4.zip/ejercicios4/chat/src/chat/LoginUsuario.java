package chat;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class LoginUsuario extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		HttpSession session = req.getSession();
		ServletContext sc = getServletContext();

		String nick = req.getParameter("nick");
		
		if(nick!=null) {
			session.setAttribute("nick", nick);

			try {
				RequestDispatcher rd = getServletConfig().getServletContext().getRequestDispatcher("/chat/frames.html");
				rd.forward(req, res);
			} catch(Exception e) {
				e.printStackTrace();
			}
		} else {
			RequestDispatcher rd = sc.getRequestDispatcher("/index.html");
			rd.forward(req, res);
		}

	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doGet(req,res);
	}
}
