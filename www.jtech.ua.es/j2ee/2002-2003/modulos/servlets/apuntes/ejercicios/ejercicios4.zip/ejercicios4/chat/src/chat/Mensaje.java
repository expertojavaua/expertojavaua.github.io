package chat;

import java.io.Serializable;

public class Mensaje implements Serializable {

	public String emisor;
	public String texto;

	public Mensaje(String emisor, String texto) {
		this.emisor = emisor;
		this.texto = texto;
	}
}
