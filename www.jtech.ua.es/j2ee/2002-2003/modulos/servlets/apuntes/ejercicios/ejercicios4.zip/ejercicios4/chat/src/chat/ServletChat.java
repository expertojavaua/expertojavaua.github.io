package chat;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class ServletChat extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		// A�adir cabecera para actualizar cada 5 segundos

		// Incluir /chat/cabecera.html

		// Mostrar mensajes del chat

		// Incluir /chat/pie.html
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doGet(req,res);
	}
}
