package context;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class ListaAtributos extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		ServletContext sc = getServletContext();

		Enumeration enum = sc.getAttributeNames();

		PrintWriter out = res.getWriter();

		String atr_name;

		out.println("<HTML><HEAD>");
		out.println("</HEAD><BODY>");

		while(enum.hasMoreElements()) {
			atr_name = (String)enum.nextElement();
			out.println("<b>" + atr_name + "</b>: " + sc.getAttribute(atr_name) + "<br>");
		}

		RequestDispatcher rd = sc.getRequestDispatcher("/enlaces.html");
		rd.include(req, res);

		out.println("</BODY></HTML>");

		out.close();
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doGet(req,res);
	}
}
