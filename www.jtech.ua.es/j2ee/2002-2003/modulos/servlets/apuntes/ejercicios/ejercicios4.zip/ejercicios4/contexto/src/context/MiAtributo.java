package context;

public class MiAtributo {

	public String texto;
	public String sesion;
	
	public MiAtributo(String texto, String sesion) {
		this.texto = texto;
		this.sesion = sesion;
	}

	public String toString() {
		return "{ sesion: " + sesion + "; texto: " + texto + " }";
	}
}