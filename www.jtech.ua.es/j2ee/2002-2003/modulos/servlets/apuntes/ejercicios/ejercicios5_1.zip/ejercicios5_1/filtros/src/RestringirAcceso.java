package filtro;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class RestringirAcceso implements Filter {

    FilterConfig filterConfig = null;

    public void doFilter(ServletRequest request,
                        ServletResponse response, FilterChain chain) 
				throws IOException, ServletException
    {
        // Se intenta acceder a la zona restringida

        // Solo podemos comprobar la sesión en el caso de tener una petición HTTP
        if(request instanceof HttpServletRequest &&
            response instanceof HttpServletResponse)
        {

            HttpServletRequest http_request = (HttpServletRequest)request;
            HttpServletResponse http_response = (HttpServletResponse)response;

            // *********** Comprobamos si el usuario se ha registrado ***********
            // En nuestra aplicación si el usuario se ha registrado habremos establecido
            // el atributo usuario de la sesion al nombre del usuario, si no será null.

            if(http_request.getSession().getAttribute("usuario") != null)
            {
                // Continuamos de forma normal con la petición
		chain.doFilter(request, response);
            }
            else
            {
                // Redireccionamos a la página de login
               	http_response.sendRedirect("/filtros/login.html");
            }

        } else {
            // Si no es una petición HTTP simplemente procesamos la petición
    	    chain.doFilter(request, response);
        }
    }

    public void init(FilterConfig config) {
    	filterConfig = config;
    }

    public void destroy() {
    	filterConfig = null;
    }
}

