CREATE DATABASE ranking;

USE ranking;

CREATE TABLE paginas(
	ruta varchar(255) NOT NULL,
	titulo varchar(100),
	accesos integer,
	PRIMARY KEY (ruta));
