import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;
import bd.*;

public class RankingPaginas extends HttpServlet {

    private PaginasBD conn = null;



    public void doGet(HttpServletRequest request, HttpServletResponse response)
					throws IOException, ServletException {

	ArrayList lista = conn.listaPaginas();
	ListIterator iter = lista.listIterator();
	Pagina pagina;

	PrintWriter out = response.getWriter();

	out.println("<html><head><title>Ranking de paginas</title></head>");
	out.println("<body>");

	out.println("<table>");
	out.println("<tr>");
	out.println("<td><b>Ruta</b></td>");
	out.println("<td><b>Titulo</b></td>");
	out.println("<td><b>Accesos</b></td>");
	out.println("</tr>");

	while(iter.hasNext()) {
		pagina = (Pagina)iter.next();

		out.println("<tr>");
		out.println("<td>" + pagina.ruta + "</td>");
		out.println("<td>" + pagina.titulo + "</td>");
		out.println("<td>" + pagina.accesos + "</td>");
		out.println("</tr>");
	}

	out.println("</table>");
    	out.println("</body>");
	out.println("</html>");

	out.close();
    }

    public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
    {
	doGet(req,res);
    }

    /**
      * Destruye el servlet. Cierra conexin a base de datos
      */

    public void destroy() {
	try {
		this.conn.close();
	} catch(SQLException e) { }
    }

    /**
      * Inicializa el servlet. Abre conexin a BD y lee par�etros.
      * @param servletConfig Configuracin del servlet y de la aplicacin.
      */

    public void init(ServletConfig servletConfig) throws ServletException {
	try {
		this.conn = new PaginasBD(
			servletConfig.getServletContext().getInitParameter("driverbd"),
			servletConfig.getServletContext().getInitParameter("urlbd"),
			"root", "mysql");
	} catch(SQLException e1) {
		throw new ServletException("Error el conectar a la BD: " + e1.getMessage());
	} catch(ClassNotFoundException e2) {
		throw new ServletException("No se encuentra el driver de la BD: " + e2.getMessage());
	}
    }

}
