package bd;

public class Pagina {

	public String ruta;
	public String titulo;
	public int accesos;

	public Pagina(String url, String titulo, int accesos) {
		this.ruta = url;
		this.titulo = titulo;
		this.accesos = accesos;
	}
}
