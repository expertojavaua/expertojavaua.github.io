package filtro;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;
import parse.*;
import wrapper.*;
import bd.*;

public final class RegistrarAccesos implements Filter {

    private FilterConfig filterConfig = null;

    /**
      *	Efectua el filtrado de una peticin.
      * @param request Peticin realizada al servidor
      * @param response Respuesta para enviar al cliente
      * @param chain Cadena de filtros para procesar la peticin
      */

    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain)
	throws IOException, ServletException {

	// Si la pagina solicitada esta registrada, incrementa el numero de accesos

	// Si no, registra la pagina (ruta, titulo) en la base de datos
    }

    /**
      * Destruye el filtro. Cierra conexin a base de datos
      */

    public void destroy() {
        this.filterConfig = null;

    	// Cerrar conexion con base de datos
    }

    /**
      * Inicializa el filtro. Abre conexin a BD y lee par�etros.
      * @param filterConfig Configuracin del filtro y de la aplicacin.
      */

    public void init(FilterConfig filterConfig) throws ServletException {
	this.filterConfig = filterConfig;

	// Abrir conexion con base de datos
    }

}
