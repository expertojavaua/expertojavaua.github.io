
package cliente;

import utils.*;
import java.util.*;
import javax.xml.rpc.handler.*;
import javax.xml.rpc.Stub;
import javax.xml.namespace.QName;
import com.amazon.soap.*;

public class ClienteDebug {
    public static void main(String[] args) {
        if(args.length < 1) {
		System.out.println("Uso: ant run -Ddirector=nombre_director");
		System.exit(0);
	}

	System.out.println("Buscando peliculas de [" + args[0] + "]");

	try {
            AmazonSearchPort serv = creaProxy();

	    DirectorRequest dsr = new DirectorRequest(args[0], "1", "dvd", "D3JV7SSUMSD7I5", "lite", "D3JV7SSUMSD7I5", null, null);

	    ProductInfo pi = serv.directorSearchRequest(dsr);
	    Details [] d = pi.getDetails();

	    for(int i=0;i<d.length;i++) {
	    	System.out.println(d[i].getProductName());
	    }

	} catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static AmazonSearchPort creaProxy() {
	AmazonSearchService_Impl serv = null;

	try {
		serv = new AmazonSearchService_Impl();
		HandlerRegistry hr = serv.getHandlerRegistry();
		List chain = hr.getHandlerChain(new QName("http://soap.amazon.com", "AmazonSearchPort"));
		HandlerInfo hi = new HandlerInfo(cliente.HandlerEspia.class,null,null);
		chain.add(hi);

	} catch(Exception e) {}

        return serv.getAmazonSearchPort();
    }
}
