
package cliente;

import utils.*;
import java.util.*;
import javax.xml.rpc.handler.*;
import javax.xml.rpc.Stub;
import javax.xml.namespace.QName;

public class ClienteDebug {
    public static void main(String[] args) {
        if(args.length < 2) {
		System.out.println("Uso: ant run -Dpais1=pais_origen -Dpais2=pais_destino");
		System.exit(0);
	}

	try {
            CurrencyExchangePortType serv = creaProxy();
	    float divisa = serv.getRate(args[0], args[1]);
	    System.out.println("Divisa de " + args[0] + " a " + args[1] + " = " + divisa);

	} catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static CurrencyExchangePortType creaProxy() {
	CurrencyExchangeService_Impl serv = null;

	try {
		serv = new CurrencyExchangeService_Impl();
		HandlerRegistry hr = serv.getHandlerRegistry();
		List chain = hr.getHandlerChain(new QName("http://www.xmethods.net/sd/CurrencyExchangeService.wsdl", "CurrencyExchangePort"));
		HandlerInfo hi = new HandlerInfo(cliente.HandlerEspia.class,null,null);
		chain.add(hi);
	} catch(Exception e) {}

        return serv.getCurrencyExchangePortType();
    }
}
