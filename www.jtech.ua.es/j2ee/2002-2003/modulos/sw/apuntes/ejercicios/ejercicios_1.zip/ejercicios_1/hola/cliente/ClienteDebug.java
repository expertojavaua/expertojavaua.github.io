
package cliente;

import utils.*;
import java.util.*;
import javax.xml.rpc.handler.*;
import javax.xml.rpc.Stub;
import javax.xml.namespace.QName;

public class ClienteDebug {
    public static void main(String[] args) {
        if(args.length < 2) {
		System.out.println("Uso: ant run -Dnombre=nombre");
		System.exit(0);
	}

	try {
            HolaPort serv = creaProxy(args[0]);
	    System.out.println("Devuelve: " + serv.saluda(args[1]));

	} catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static HolaPort creaProxy(String wsdl) {
	Hola_Impl serv = null;

	try {
		serv = new Hola_Impl(wsdl);
		HandlerRegistry hr = serv.getHandlerRegistry();
		List chain = hr.getHandlerChain(new QName("http://www.rvg.ua.es/ws", "HolaPort"));
		HandlerInfo hi = new HandlerInfo(cliente.HandlerEspia.class,null,null);
		chain.add(hi);
	} catch(Exception e) {}

        return serv.getHolaPort();
    }
}
