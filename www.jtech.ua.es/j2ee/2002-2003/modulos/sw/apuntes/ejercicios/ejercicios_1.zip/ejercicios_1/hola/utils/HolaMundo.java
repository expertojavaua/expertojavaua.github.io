package utils;

public class HolaMundo {

	public String saluda(String nombre) {
		return "Hola " + nombre;
	}
}
