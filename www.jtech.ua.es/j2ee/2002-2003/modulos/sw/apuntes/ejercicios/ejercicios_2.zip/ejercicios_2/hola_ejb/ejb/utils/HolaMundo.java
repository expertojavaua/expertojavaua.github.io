package utils;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;

public interface HolaMundo extends EJBObject {

	String saluda(String nombre) throws RemoteException;
}
