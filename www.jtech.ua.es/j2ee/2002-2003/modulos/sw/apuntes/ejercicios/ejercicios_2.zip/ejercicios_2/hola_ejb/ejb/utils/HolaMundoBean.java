package utils;

import javax.ejb.CreateException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class HolaMundoBean implements SessionBean {

  private SessionContext ctx;

  public void ejbActivate() { }

  public void ejbRemove() { }

  public void ejbPassivate() { }

  public void setSessionContext(SessionContext ctx) {
    this.ctx = ctx;
  }

  public void ejbCreate () throws CreateException { }

  public String saluda(String nombre) {
    return "Hola " + nombre;
  }
}
