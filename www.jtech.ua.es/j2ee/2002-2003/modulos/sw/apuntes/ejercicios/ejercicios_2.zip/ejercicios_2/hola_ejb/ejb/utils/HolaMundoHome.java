package utils;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;

public interface HolaMundoHome extends EJBHome {

	HolaMundo create() throws CreateException, RemoteException;
}
