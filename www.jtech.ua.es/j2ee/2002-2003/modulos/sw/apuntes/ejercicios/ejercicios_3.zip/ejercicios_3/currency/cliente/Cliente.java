
package cliente;

import utils.*;

public class Cliente {
    public static void main(String[] args) {
        if(args.length < 2) {
		System.out.println("Uso: java cliente.Cliente pais_origen pais_destino");
		System.exit(0);
	}

	try {
            CurrencyExchangePortType serv = creaProxy();
	    float divisa = serv.getRate(args[0], args[1]);
	    System.out.println("Cambio de " + args[0] + " a " + args[1] + " = " + divisa);

	} catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static CurrencyExchangePortType creaProxy() {
	CurrencyExchangeService_Impl serv = null;

	try {
		serv = new CurrencyExchangeService_Impl();
	} catch(Exception e) {}

        return serv.getCurrencyExchangePortType();
    }
}
