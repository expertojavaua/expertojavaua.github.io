
package cliente;

import utils.*;

public class Cliente {
    public static void main(String[] args) {
        if(args.length < 2) {
		System.out.println("Uso: java cliente.Cliente <wsdl> <nombre>");
		System.exit(0);
	}

	try {
            HolaPort serv = creaProxy(args[0]);
	    System.out.println("Devuelve: " + serv.saluda(args[1]));

	} catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static HolaPort creaProxy(String wsdl) {
	Hola_Impl serv = null;

	try {
		serv = new Hola_Impl(wsdl);
	} catch(Exception e) {}

        return serv.getHolaPort();
    }
}
