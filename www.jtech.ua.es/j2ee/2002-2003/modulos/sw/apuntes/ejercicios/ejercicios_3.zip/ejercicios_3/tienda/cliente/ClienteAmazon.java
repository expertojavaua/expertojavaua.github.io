
package cliente;

import java.util.*;
import javax.xml.rpc.handler.*;
import javax.xml.rpc.Stub;
import javax.xml.namespace.QName;
import com.amazon.soap.*;
import utils.*;
import tienda.*;

public class ClienteAmazon {
    public static DatosPelicula [] busca(String director) {

    	ArrayList lista = new ArrayList();

	try {
            AmazonSearchPort serv = creaProxy();

	    DirectorRequest dsr = new DirectorRequest(director, "1", "dvd", "D3JV7SSUMSD7I5", "lite", "D3JV7SSUMSD7I5", null, null);

	    ProductInfo pi = serv.directorSearchRequest(dsr);
	    Details [] d = pi.getDetails();

	    for(int i=0;i<d.length;i++) {
	    	float precio = 0.0f;

		String sprecio = d[i].getOurPrice();
		if(sprecio!=null) {
			sprecio = sprecio.substring(1,sprecio.length());

			try {
				precio = Float.parseFloat(sprecio);
			} catch(Exception e) {}
		}

		lista.add(new DatosPelicula(d[i].getProductName(), director, precio));
	    }

	} catch (Exception e) { }

    	DatosPelicula [] result = new DatosPelicula[lista.size()];
	lista.toArray(result);

	return result;
    }

    private static AmazonSearchPort creaProxy() {
	AmazonSearchService_Impl serv = null;

	try {
		serv = new AmazonSearchService_Impl();
	} catch(Exception e) {}

        return serv.getAmazonSearchPort();
    }
}
