package tienda;

import java.util.*;
import cliente.*;

public class BuscaDVD {

	public DatosPelicula [] buscaPorDirector(String director) {
		DatosPelicula [] result = ClienteAmazon.busca(director);
		
		// Actualizar precios

		return result;
	}
}
