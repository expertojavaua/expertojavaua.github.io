package tienda;

public class DatosPelicula {
    public String titulo;
    public String director;
    public float precio;

    public DatosPelicula() {}

    public DatosPelicula(String titulo, String director, float precio) {
        this.titulo = titulo;
        this.director = director;
        this.precio = precio;
    }

    public String toString() {
    	return titulo + ", " + director + ", " + precio + " euros.";
    }
}
