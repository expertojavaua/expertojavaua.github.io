import java.util.*;
import javax.wsdl.*;
import javax.wsdl.xml.*;
import javax.wsdl.factory.*;

public class AnalizaWSDL {

	public static void main(String [] args)
	{
	    	try {
			WSDLReader wsdlReader = WSDLFactory.newInstance().newWSDLReader();

			Definition wsdlDefinition = wsdlReader.readWSDL(args[0]);

			// Analizar WSDL

	    	} catch(Exception e) { e.printStackTrace(); }
	}
}
