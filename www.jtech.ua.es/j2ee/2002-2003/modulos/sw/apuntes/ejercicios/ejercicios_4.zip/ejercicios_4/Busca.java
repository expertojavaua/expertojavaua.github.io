import javax.xml.registry.*;
import javax.xml.registry.infomodel.*;
import java.net.*;
import java.util.*;

public class Busca {

    public static void main(String[] args) {

	String inquiry = "http://uddi.ibm.com/ubr/inquiryapi";
        String publish = "https://uddi.ibm.com/ubr/publishapi";
//	String inquiry = "http://localhost:7001/uddi/uddilistener";
//      String publish = "http://localhost:7001/uddi/uddilistener";

        if (args.length < 1) {
            System.out.println("Uso: ant run -Dorg=nombre_organizacion");
            System.exit(1);
        }

	String nombre = args[0];
        System.out.println("Buscando organizacion: " + nombre);

        // Conecta al registro

	Properties props = new Properties();
        props.setProperty("javax.xml.registry.queryManagerURL", inquiry);

	Connection con = null;
        RegistryService rs = null;
        BusinessQueryManager bqm = null;

	try {

		/***************************************/
		/* Obtener BusinessQueryManager en bqm */
		/*                                     */
		/***************************************/

        } catch (Exception e) {
            e.printStackTrace();
	    System.exit(1);
        }

	// Busca organizaciones


        try {

	    // Criterios de busqueda

            Collection nombres = new ArrayList();
            nombres.add("%" + nombre + "%");

            BulkResponse resp = bqm.findOrganizations(null, nombres, null, null, null, null);
            Collection orgs = resp.getCollection();

	    // Enumera organizaciones

            Iterator orgIter = orgs.iterator();
            while (orgIter.hasNext()) {
                Organization org = (Organization) orgIter.next();

                System.out.println("Nombre: " + org.getName().getValue(Locale.ENGLISH));
                System.out.println("Descripcion: " + org.getDescription().getValue(Locale.ENGLISH));
                System.out.println("Clave: " + org.getKey().getId());

 		// Enumera servicios

                Collection servicios = org.getServices();
                Iterator servIter = servicios.iterator();
                while (servIter.hasNext()) {
                    Service serv = (Service) servIter.next();

                    System.out.println(" Nombre servicio: " + serv.getName().getValue(Locale.ENGLISH));
                    System.out.println(" Descripcion servicio: " + serv.getDescription().getValue(Locale.ENGLISH));

		    // Enumera enlaces

                    Collection bindings = serv.getServiceBindings();
                    Iterator sbIter = bindings.iterator();
                    while (sbIter.hasNext()) {
                        ServiceBinding sb = (ServiceBinding) sbIter.next();

                        System.out.println("  Descripcion enlace: " + sb.getDescription().getValue(Locale.ENGLISH));
                        System.out.println("  URL enlace: " + sb.getAccessURI());
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally  {

	    // Cierra la conexion

            if (con != null) {
                try {
                    con.close();
                } catch (JAXRException je) {}
            }
        }
    }

}
