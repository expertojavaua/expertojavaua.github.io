import javax.xml.registry.*;
import javax.xml.registry.infomodel.*;
import java.net.*;
import java.util.*;

public class BuscaWSDL {

    public static void main(String[] args) {

	String inquiry = "http://uddi.ibm.com/ubr/inquiryapi";
        String publish = "https://uddi.ibm.com/ubr/publishapi";
//	String inquiry = "http://localhost:7001/uddi/uddilistener";
//      String publish = "http://localhost:7001/uddi/uddilistener";

        Properties props = new Properties();
        props.setProperty("javax.xml.registry.queryManagerURL", inquiry);
        props.setProperty("javax.xml.registry.lifeCycleManagerURL", publish);

	Connection con = null;

        try {

	    // Conecta al registro

            ConnectionFactory cf = ConnectionFactory.newInstance();
            cf.setProperties(props);
            con = cf.createConnection();

            RegistryService rs = con.getRegistryService();
            BusinessQueryManager bqm = rs.getBusinessQueryManager();
            BusinessLifeCycleManager blcm = rs.getBusinessLifeCycleManager();

	    // Crea esquema de clasificacion

            String taxonomia = "uddi-org:types";
            ClassificationScheme tiposUDDI = bqm.findClassificationSchemeByName(null, taxonomia);

            Classification claseWSDL = blcm.createClassification(tiposUDDI, "wsdlSpec", "wsdlSpec");

	    // Busca conceptos segun la clasificacion

            Collection clases = new ArrayList();
            clases.add(claseWSDL);

            BulkResponse resp = bqm.findConcepts(null, null, clases, null, null);

	    // Enumera conceptos

   	    /**************************************************/
	    /* Mostrar links externos (WSDL) de cada concepto */
	    /*                                                */
	    /**************************************************/

        } catch (Exception e) {
            e.printStackTrace();
        } finally  {

	    // Cerrar conexion

            if (con != null) {
                try {
                    con.close();
                } catch (JAXRException je) {}
            }
        }

    }

}
