/*
 * Operation Panel.java, Panel for operation parameters input
 * Copyright (C) 2003 DCCIA
 *
 * This file is part of Web Services Explorer.
 *
 * Web Services Explorer is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Web Services Explorer is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with Web Services Explorer; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package wse.tools;

import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import javax.xml.namespace.QName;
import wse.tools.wsdl.*;
import wse.calls.*;

public class OperationPanel extends JPanel
{
	public final static String MSG_BTN_INVOKE = "Invoke";
	public final static int TXT_LENGTH = 20;

	WSDLOperation wsdl_op;
	WSDLParameter [] wsdl_params;
	JTextField [] values;

	QName serviceName;
	QName portName;
	QName opName;
	URL wsdl;
	Object [] params;

	JTextArea result;
	JTextArea request;
	JTextArea response;

	public OperationPanel(WSDLOperation wsdl_op, String wsdl) {
		this.wsdl_op = wsdl_op;
		try {
			this.wsdl = new URL(wsdl);
		} catch(MalformedURLException e) {
			System.err.println(e.getMessage());
		}

		init();
	}

	public void parse() {
		// Datos del servicio

		String endpoint;
		String target;
		String namespace;

		WSDLPortType wsdl_type = wsdl_op.getPortType();
		WSDLPort wsdl_port = wsdl_type.getPort();
		WSDLService wsdl_srv = wsdl_port.getService();

		target = wsdl_srv.getTargetNamespace();
		namespace = wsdl_op.getNamespace();
		endpoint = wsdl_port.getEndpoint();
		
		serviceName = wsdl_srv.getService().getQName();
		portName = new QName(target, wsdl_port.getPort().getName());
		opName = new QName(namespace, wsdl_op.getOperation().getName());

		// Parametros

		int n_params = wsdl_params.length;
		params = new Object[n_params];
		for(int i=0;i<n_params;i++) {
			params[i] = wsdl_params[i].parse(values[i].getText());
		}
	}

	public void init() {
		wsdl_params = WSDLTree.expandOperation(wsdl_op);

		int n_params = wsdl_params.length;

		setLayout(new BorderLayout());

		JPanel [] panels = new JPanel[n_params];
		JLabel [] labels = new JLabel[n_params];
		values = new JTextField[n_params];

		JPanel params_panel = new JPanel();
		params_panel.setLayout(new BoxLayout(params_panel, BoxLayout.Y_AXIS));

		for(int i=0;i<n_params;i++) {
			panels[i] = new JPanel();
			labels[i] = new JLabel(wsdl_params[i].toString());
			values[i] = new JTextField(TXT_LENGTH);

			panels[i].setLayout(new FlowLayout());
			panels[i].add(labels[i]);
			panels[i].add(values[i]);

			params_panel.add(panels[i]);
		}

		JPanel panel_btn = new JPanel();
		panel_btn.setLayout(new FlowLayout());

		JButton invoke = new JButton(MSG_BTN_INVOKE);
		panel_btn.add(invoke);

		params_panel.add(panel_btn);

		// Text areas

		JPanel results_panel = new JPanel();
		results_panel.setLayout(new BoxLayout(results_panel, BoxLayout.Y_AXIS));

		result = new JTextArea();
		request = new JTextArea();
		response = new JTextArea();

		JLabel lbl_result = new JLabel("Results");
		JLabel lbl_request = new JLabel("SOAP Request");
		JLabel lbl_response = new JLabel("SOAP Response");

		results_panel.add(lbl_result);
		results_panel.add(new JScrollPane(result));
		results_panel.add(lbl_request);
		results_panel.add(new JScrollPane(request));
		results_panel.add(lbl_response);
		results_panel.add(new JScrollPane(response));

		add(params_panel, BorderLayout.NORTH);
		add(results_panel, BorderLayout.CENTER);

		invoke.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				invoke();
			}
		});
	}

	public void invoke() {
		try {
			parse();
			Object result = DIICall.call(wsdl, serviceName, portName, opName, params);
	
			this.result.setText(result.toString());
		} catch(Exception e) {
			this.result.setText("Error invoking service: " + e.getMessage());
		} finally {
			this.request.setText(wse.calls.SpyHandler.getRequest());
			this.response.append(wse.calls.SpyHandler.getResponse());
		}

	}
}
