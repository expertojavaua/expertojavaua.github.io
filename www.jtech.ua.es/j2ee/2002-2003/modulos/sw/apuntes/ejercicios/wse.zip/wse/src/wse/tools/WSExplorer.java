/*
 * WSExplorer.java, Main application to explore Web Services
 * Copyright (C) 2003 DCCIA
 *
 * This file is part of Web Services Explorer.
 *
 * Web Services Explorer is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Web Services Explorer is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with Web Services Explorer; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package wse.tools;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import wse.tools.wsdl.*;

public class WSExplorer extends JFrame 
{

	public final static int WIDTH = 640;
	public final static int HEIGHT = 480;

	public final static int TREE_MIN_WIDTH = 200;
	public final static int TREE_MIN_HEIGHT = 400;

	public final static String MSG_BTN_DIR = "Go";
	public final static String MSG_LABEL_DIR = "WSDL URL: ";
	public final static String MSG_MENU_FILE = "File";
	public final static String MSG_MENU_EXIT = "Exit";
	public final static String MSG_MENU_ABOUT = "About";
	public final static String MSG_MENU_HELP = "Help";
	public final static String MSG_TREE_ROOT = "WSDL Document";
	public final static String MSG_TITLE = "Web Services Explorer";
	public final static String MSG_ABOUT_TITLE = "About Web Services Explorer";
	public final static String MSG_ABOUT = "Web Services Explorer\nMiguel Angel Lozano Ortega\nDCCIA (c) 2003";

	JTextField txt_dir;

	JTree tree;
	DefaultMutableTreeNode root;

	JSplitPane jsp;

	JPanel viewer;
	String wsdl;

	public WSExplorer() {
		init();
	}

	private void init() {
		setTitle(MSG_TITLE);

		Container base = getContentPane();

		base.setLayout(new BorderLayout());

		// ------------------------------------------------------------------------
		// Panel de barra de direcci�n
		// ------------------------------------------------------------------------

		JRootPane p_dir = new JRootPane();
		p_dir.setLayout(new BorderLayout());

		txt_dir = new JTextField();
		JButton btn_dir = new JButton(MSG_BTN_DIR);

		JLabel label_dir = new JLabel(MSG_LABEL_DIR);
		
		p_dir.setDefaultButton(btn_dir);
		p_dir.add(label_dir, BorderLayout.WEST);
		p_dir.add(txt_dir, BorderLayout.CENTER);
		p_dir.add(btn_dir, BorderLayout.EAST);

		// ------------------------------------------------------------------------
		// Menu
		// ------------------------------------------------------------------------

		JMenuBar menu = new JMenuBar();
		JMenu menu_file = new JMenu(MSG_MENU_FILE);
		JMenu menu_help = new JMenu(MSG_MENU_HELP);
		JMenuItem menu_exit = new JMenuItem(MSG_MENU_EXIT);
		JMenuItem menu_about = new JMenuItem(MSG_MENU_ABOUT);

		menu_file.add(menu_exit);
		menu_help.add(menu_about);
		menu.add(menu_file);
		menu.add(menu_help);

		setJMenuBar(menu);

		// ------------------------------------------------------------------------
		// Visor
		// ------------------------------------------------------------------------

		viewer = new JPanel();
		viewer.setLayout(new CardLayout());

		// ------------------------------------------------------------------------
		// Arbol
		// ------------------------------------------------------------------------
	
		root = new DefaultMutableTreeNode(MSG_TREE_ROOT);
		tree = new JTree(root);
		JScrollPane scroll_tree = new JScrollPane(tree);
		scroll_tree.setMinimumSize(new Dimension(TREE_MIN_WIDTH, TREE_MIN_HEIGHT));

		// ------------------------------------------------------------------------
		// Panel dividido
		// ------------------------------------------------------------------------

		jsp = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
		jsp.add(scroll_tree, JSplitPane.LEFT);
		jsp.add(viewer, JSplitPane.RIGHT);

		// ------------------------------------------------------------------------
		// Disposicion de los elementos
		// ------------------------------------------------------------------------

		base.add(p_dir, BorderLayout.NORTH);
		base.add(jsp, BorderLayout.CENTER);

		// ------------------------------------------------------------------------
		// Eventos
		// ------------------------------------------------------------------------

		setDefaultCloseOperation(EXIT_ON_CLOSE);

		btn_dir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				go(txt_dir.getText());
			}
		});

		tree.addTreeSelectionListener(new TreeSelectionListener() {
			public void valueChanged(TreeSelectionEvent e) {
				TreePath tp = e.getNewLeadSelectionPath();
				if(tp != null) {
					select(tp.getLastPathComponent());
				}
			}
		});

		menu_exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
	
		menu_about.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, MSG_ABOUT, MSG_ABOUT_TITLE, JOptionPane.PLAIN_MESSAGE);
			}
		});

	}

	public void go(String wsdl) {
		if(wsdl != null) {
			root = new DefaultMutableTreeNode(MSG_TREE_ROOT);
			tree = new JTree(root);
			JScrollPane scroll_tree = new JScrollPane(tree);
			scroll_tree.setMinimumSize(new Dimension(TREE_MIN_WIDTH, TREE_MIN_HEIGHT));
			jsp.add(scroll_tree, JSplitPane.LEFT);
		
			tree.addTreeSelectionListener(new TreeSelectionListener() {
				public void valueChanged(TreeSelectionEvent e) {
					TreePath tp = e.getNewLeadSelectionPath();
					if(tp != null) {
						select(tp.getLastPathComponent());
					}
				}
			});

			WSDLTree.creaNodos(wsdl, root);
			this.wsdl = wsdl;
		}
		tree.expandRow(0);
	}

	public void select(Object o) {
		viewer.removeAll();

		if(o instanceof DefaultMutableTreeNode) {
			DefaultMutableTreeNode node = (DefaultMutableTreeNode) o;
			if(node.getUserObject()!=null && 
			   node.getUserObject() instanceof WSDLOperation) 
			{
				WSDLOperation op = (WSDLOperation) node.getUserObject();

				OperationPanel op_panel = new OperationPanel(op, wsdl);
				JScrollPane scroll = new JScrollPane(op_panel);
				viewer.add(scroll, "");

			}
		}
		
		jsp.setDividerLocation(jsp.getDividerLocation());
	}

	public static void main(String [] args) {
		WSExplorer wse = new WSExplorer();
		wse.setSize(WIDTH, HEIGHT);
		wse.show();
	}
}
