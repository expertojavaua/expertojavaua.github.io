/*
 * WSDLParameter.java, Parameters in the WSDL file
 * Copyright (C) 2003 DCCIA
 *
 * This file is part of Web Services Explorer.
 *
 * Web Services Explorer is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Web Services Explorer is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with Web Services Explorer; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


package wse.tools.wsdl;

import javax.xml.namespace.*;
import javax.wsdl.*;
import javax.wsdl.xml.*;
import javax.wsdl.factory.*;

public class WSDLParameter {

	WSDLOperation op;
	Part part;

	public WSDLParameter(WSDLOperation op, Part part) {
		this.op = op;
		this.part = part;
	}

	public WSDLOperation getOperation() {
		return op;
	}

	public Part getPart() {
		return part;
	}

	public String toString() {
		return part.getTypeName().getLocalPart();
	}

	public Object parse(String value) {
		if(part.getTypeName().getLocalPart().toLowerCase().equals("string")) {
			return new String(value);
		} else if(part.getTypeName().getLocalPart().toLowerCase().equals("int")) {
			return new Integer(value);
		} else if(part.getTypeName().getLocalPart().toLowerCase().equals("float")) {
			return new Float(value);
		} else if(part.getTypeName().getLocalPart().toLowerCase().equals("double")) {
			return new Double(value);
		} else if(part.getTypeName().getLocalPart().toLowerCase().equals("boolean")) {
			return new Boolean(value);
		} else {
			return null;
		}
	}
}