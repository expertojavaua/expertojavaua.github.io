/*
 * WSDLService.java, Services in the WSDL file
 * Copyright (C) 2003 DCCIA
 *
 * This file is part of Web Services Explorer.
 *
 * Web Services Explorer is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Web Services Explorer is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with Web Services Explorer; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


package wse.tools.wsdl;

import javax.xml.namespace.*;
import javax.wsdl.*;
import javax.wsdl.xml.*;
import javax.wsdl.factory.*;

public class WSDLService {

	Definition def;
	Service serv;

	public WSDLService(Definition def, Service serv) {
		this.def = def;
		this.serv = serv;
	}

	public Service getService() {
		return serv;
	}

	public Definition getDefinition() {
		return def;
	}

	public String getTargetNamespace() {
		return def.getTargetNamespace();
	}

	public String toString() {
		return serv.getQName().getLocalPart();
	}
}