//Ejemplo 4. B�squeda de un nodo

/*
Encuentra el subnodo en una lista. Ignora comentarios e
instrucciones de procesamiento. Ignora nodos TEXT, CDADA y
EntityRef. Examina los elementos node para encontrar uno
con el nombre especificado */

//name= etiqueta del elemento a buscar
//node= nodo a partir del cual se inicia la b�squeda
//devuelve el nodo encontrado

public Node findSubNode(String name, Node node) 
{
  if (node.getNodeType() != Node.ELEMENT_NODE) {
    System.err.println("Error: El nodo buscado no es de ese tipo");
    System.exit(22);
  }

  if (! node.hasChildNodes()) return null;

  NodeList list = node.getChildNodes();
  for (int i=0; i < list.getLength(); i++) {
    Node subnode = list.item(i);
    if (subnode.getNodeType() == Node.ELEMENT_NODE) {
      if (subnode.getNodeName() == name) return subnode;
    }
  }
  return null;
}