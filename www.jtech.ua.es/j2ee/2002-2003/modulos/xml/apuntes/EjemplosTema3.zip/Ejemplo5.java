//Ejemplo 5. Obtenci�n del contenido de un nodo

/* Devuelve el texto que contiene el nodo.
Ignora comentarios e instrucciones de procesamiento.
Concatena nodos TEXT, CDATA, y los resultados del
procesamiento recursivo de nodos EntityRef.
Ignora los elementos de las sublistas */

//node = nodo DOM
//devuelve un String representando su contenido

public String getText(Node node) 
{
  StringBuffer result = new StringBuffer();
  if (! node.hasChildNodes()) return "";

  NodeList list = node.getChildNodes();
  for (int i=0; i < list.getLength(); i++) {
    Node subnode = list.item(i);
    if (subnode.getNodeType() == Node.TEXT_NODE) {
      result.append(subnode.getNodeValue());
    }
    else if (subnode.getNodeType() ==
        Node.CDATA_SECTION_NODE) 
    {
      result.append(subnode.getNodeValue());
    }
    else if (subnode.getNodeType() ==
        Node.ENTITY_REFERENCE_NODE) 
    {
      result.append(getText(subnode));
    }
  }
  return result.toString();
}