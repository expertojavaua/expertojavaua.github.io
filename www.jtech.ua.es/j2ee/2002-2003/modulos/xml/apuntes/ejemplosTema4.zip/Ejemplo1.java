import oracle.jdbc.driver.*;
import oracle.xml.sql.query.OracleXMLQuery;
import java.lang.*;
import java.sql.*;
import oracle.xdb.XMLType;

//Ejemplo1. Generaci�n de un String a partir de una tabla. 

class Ejemplo1 {

   public static void main(String[] argv) {
      try {
         Connection conn = getConnection("catalog", "catalog");
         OracleXMLQuery qry = new OracleXMLQuery(conn, "select * from categories");
         String str = qry.getXMLString();

         System.out.println("Salida XML: \n" + str);
         qry.close();
      }
      catch(SQLException e) {
         System.out.println(e.toString());
      }

   }

   private static Connection getConnection(String userName, String password) throws SQLException {
      DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
      Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@www.rvg.ua.es:1521:j2eebd", userName, password);
       
      return conn;
   }



}
