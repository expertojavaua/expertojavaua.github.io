import org.w3c.dom.*;
import oracle.xml.parser.v2.*;
import java.sql.*;
import oracle.xml.sql.query.OracleXMLQuery;
import java.io.*;

//Ejemplo 2. Generaci�n de un XML a partir de ResultSets 

 class Ejemplo2{

   public static void main(String[] argv)
   {
      try{
       Connection conn  = getConnection("scott","tiger");
       OracleXMLQuery qry = new OracleXMLQuery(conn, "select * from emp");

       // Obtenci�n del documento DOM
       XMLDocument domDoc = (XMLDocument)qry.getXMLDOM();

       // Escritura directamente a partir de DOM
       domDoc.print(System.out);

       // Si se prefiere escribir en un string buffer hacer lo siguiente:
       StringWriter s = new StringWriter(10000);
       domDoc.print(new PrintWriter(s));
       System.out.println(" The string version ---> "+s.toString());

       qry.close(); // Siempre se debe cerrar el query!!
      }catch(Exception e){
        System.out.println(e.toString());
      }
    }
    //getConnection
    private static Connection getConnection(String userName, String password) throws SQLException {
      DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
      Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@www.rvg.ua.es:1521:j2eebd", userName, password);
       
      return conn;
   }

}
