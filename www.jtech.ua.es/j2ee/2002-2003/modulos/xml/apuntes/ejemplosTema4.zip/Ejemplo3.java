import java.sql.*;
import oracle.xml.sql.dml.OracleXMLSave;

//Ejemplo 3. Inserci�n de valores en Columnas mediante OracleXMLSave  

public class Ejemplo3
{
   public static void main(String argv[])
     throws SQLException
   {
      Connection conn = getConnection("scott","tiger");
      OracleXMLSave sav = new OracleXMLSave(conn, "scott.emp");

      String [] colNames = new String[5];
      colNames[0] = "EMPNO";
      colNames[1] = "ENAME";
      colNames[2] = "JOB";

      sav.setUpdateColumnList(colNames); // set the columns to update..!

      // Assume that the user passes in this document as the first argument!
      sav.insertXML(argv[0]);
      sav.close();
   }
   //getConnection
   private static Connection getConnection(String userName, String password) throws SQLException {
      DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
      Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@www.rvg.ua.es:1521:j2eebd", userName, password);
       
      return conn;
   }

}

