import java.sql.*;
import oracle.xml.sql.dml.OracleXMLSave;

//Ejemplo 4. Actualizaci�n de una tabla usando las claves mediante OracleXMLSave 

public class Ejemplo4
{
   public static void main(String argv[])
     throws SQLException
   {
      Connection conn = getConnection("scott","tiger");
      OracleXMLSave sav = new OracleXMLSave(conn, "scott.emp");

      String [] keyColNames = new String[1];
      keyColNames[0] = "EMPNO";
      sav.setKeyColumnList(keyColNames);

      // Assume that the user passes in this document as the first argument!
      sav.updateXML(argv[0]);
      sav.close();
   }
   //getConnection
   private static Connection getConnection(String userName, String password) throws SQLException {
      DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
      Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@www.rvg.ua.es:1521:j2eebd", userName, password);
       
      return conn;
   }
}


