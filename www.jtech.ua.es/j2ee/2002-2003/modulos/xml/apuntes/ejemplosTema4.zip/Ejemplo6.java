//Ejemplo 6. Actualizaci�n del elemento discount dentro de la orden de compra, almacenada en una columna XMLType. 

//CLASSPATH debe contener classes12.zip, xmlparserv2.jar, y oraxdb.jar

import java.sql.*;
import java.io.*;
import oracle.xml.parser.v2.*;
import org.xml.sax.*;
import org.w3c.dom.*;
import oracle.jdbc.driver.*;
import oracle.sql.*;
import oracle.xdb.XMLType;

public class Ejemplo6
{
  static String conStr = "jdbc:oracle:oci8:@";
  static String user = "scott";
  static String pass = "tiger";
  static String qryStr =
    "SELECT x.poDoc from po_xml_tab x "+
    "WHERE x.poDoc.extract('/PO/PONO/text()').getNumberVal()=200";

  static String updateXML(String xmlTypeStr)
  {
    System.out.println("\n===============================");
    System.out.println("xmlType.getStringVal():");
    System.out.println(xmlTypeStr);
    System.out.println("===============================");
    String outXML = null;
    try{
    DOMParser parser = new DOMParser();
    parser.setValidationMode(false);
    parser.setPreserveWhitespace (true);
    parser.parse(new StringReader(xmlTypeStr));
    System.out.println("xmlType.getStringVal(): xml String is well-formed");
    XMLDocument doc = parser.getDocument();
    NodeList nl = doc.getElementsByTagName("DISCOUNT");
    for(int i=0;i<nl.getLength();i++){
      XMLElement discount = (XMLElement)nl.item(i);
      XMLNode textNode = (XMLNode)discount.getFirstChild();
      textNode.setNodeValue("10");
    } //end for
    StringWriter sw = new StringWriter();
    doc.print(new PrintWriter(sw));
    outXML = sw.toString();
    //print modified xml
    System.out.println("\n===============================");
    System.out.println("Updated PurchaseOrder:");
    System.out.println(outXML);
    System.out.println("===============================");
    }
    catch ( Exception e )
    {
      e.printStackTrace(System.out);
    }
    return outXML;
  }

  public static void main(String args[]) throws Exception
  {
    try{
     System.out.println("qryStr="+ qryStr);
     DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
     Connection conn =
     DriverManager.getConnection
         ("jdbc:oracle:thin:@www.rvg.ua.es:1521:j2eebd", user, pass);
     Statement s = conn.createStatement();
     OraclePreparedStatement stmt;
     ResultSet rset = s.executeQuery(qryStr);
     OracleResultSet orset = (OracleResultSet) rset;
     while(orset.next()){
      //retrieve PurchaseOrder xml document from database
      XMLType xt = XMLType.createXML(orset.getOPAQUE(1));
      //store this PurchaseOrder in po_xml_hist table
      stmt = (OraclePreparedStatement)conn.prepareStatement(
        "insert into po_xml_hist values(?)");
      stmt.setObject(1,xt); // bind the XMLType instance
      stmt.execute();
      //update "DISCOUNT" element
      String newXML = updateXML(xt.getStringVal());
      // create a new instance of an XMLtype from the updated value
      xt = XMLType.createXML(conn,newXML);
      // update PurchaseOrder xml document in database
      stmt = (OraclePreparedStatement)conn.prepareStatement(
           "update po_xml_tab x set x.poDoc =? where "+
           "x.poDoc.extract('/PO/PONO/text()').getNumberVal()=200");
      stmt.setObject(1,xt); // bind the XMLType instance
      stmt.execute();
      conn.commit();
      System.out.println("PurchaseOrder 200 Updated!");
     } //end while
    //delete PurchaseOrder 1001
    s.execute("delete from po_xml x"+
      "where x.xpo.extract"+
      "('/PurchaseOrder/PONO/text()').getNumberVal()=1001");
    System.out.println("PurchaseOrder 1001 deleted!");
    }
    catch( Exception e )
    {
      e.printStackTrace(System.out);
    }
  }
}