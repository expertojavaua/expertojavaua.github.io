import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.InputSource;
import org.apache.xpath.*;
import java.io.*;
import javax.xml.transform.*;
import javax.xml.transform.stream.*;
import javax.xml.transform.dom.*;


public class AplicaXPath {

	
   public static void main(String args[]) {
      Document doc;
	  Element raiz;
	  DocumentBuilderFactory dbf;
	  DocumentBuilder db;
	  String nombreXML, exprXPath;
	  InputSource fichXML;
	  NodeList listaNodos;
	  int i;


      if (args.length!=2) {
      	System.out.println("Uso: AplicaXPath ficheroXML expresionXPath");      	
      	return;
      }
      else {
      	nombreXML = args[0];
      	exprXPath = args[1];
      } 
      
      //abrir el fichero XML
      try
      {
        fichXML = new InputSource(new FileInputStream(nombreXML));
      }
      catch (FileNotFoundException fnf)
      {
        System.err.println(fnf);
        return;
      }        
      
      //analizar el documento XML
      try
      {
  	    dbf = DocumentBuilderFactory.newInstance();
	    db = dbf.newDocumentBuilder();
        doc = db.parse(fichXML);
		raiz = doc.getDocumentElement();
      }
	    catch (ParserConfigurationException pce)
      {
	      System.err.println(pce);
	      return;
      }
      catch(Exception e)
      {
        System.err.println(e);
        return;
      }
      
      //Aplicar la expresi�n XPath
      try
      {
        listaNodos = XPathAPI.selectNodeList(raiz, exprXPath);
	  }
      catch (Exception e2)
      {
        System.err.println(e2);
        return;
      }
      
      //Sacar resultados
      /*
      org.apache.xpath.objects.XNodeSet xNode;
      
  	  for(i=0;i<listaNodos.getLength();i++) {
  	  	xNode = new org.apache.xpath.objects.XNodeSet(listaNodos.item(i));
  	    System.out.println("Nodo: " + i);
        //System.out.println("Nombre: " + listaNodos.item(i).getNodeName());
        //System.out.println("Valor: " + listaNodos.item(i).getNodeValue());
        System.out.println(xNode.str());
      } 
      */
      try {
         Transformer serializer = TransformerFactory.newInstance().newTransformer();
         serializer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
         for (i=0;i<listaNodos.getLength();i++) {
         	System.out.println("\nNodo " + i);
 	        serializer.transform(new DOMSource(listaNodos.item(i)),
 	                             new StreamResult(System.out));
 	        System.out.println("\n----------------");  
 	     }     		
      }
      catch(Exception e) {
         System.out.println(e);	
      }
   	
   }
}