
//importar clases del API TraX 
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerConfigurationException;
//importar clases generales de Java
import java.io.FileNotFoundException;
import java.io.IOException;

/*
* El programa espera como primer argumento un nombre de fichero XML a transformar
* y como segundo el nombre del fichero que contiene el XSLT a aplicar. El resultado
* se env�a por defecto a la salida est�ndar.
*/

public class AplicaXSLT  {
   public static void main(String args[]) throws TransformerException,
                        TransformerConfigurationException,
                        FileNotFoundException, IOException {
      if (args.length!=2)
         System.out.println("uso: java AplicaXSLT fichero.xml fichero.xsl");
      else {
      	//instanciar un TransformerFactory
      	TransformerFactory tf = TransformerFactory.newInstance();
      	//El TransformerFactory sirve para crear un objeto Transformer
      	//que aplicar� el XSLT especificado.
      	Transformer t = tf.newTransformer(new StreamSource(args[1]));
      	//Emplear el Transformer para transformar una entrada (StreamSource)
      	//y enviarla a una salida (StreamResult)
      	t.transform(new StreamSource(args[0]), new StreamResult(System.out));;
      }   	
   	
   }
   	
}