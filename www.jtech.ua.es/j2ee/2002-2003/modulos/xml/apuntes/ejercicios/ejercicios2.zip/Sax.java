import java.io.FileReader;
import javax.xml.parsers.SAXParser; 
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.DefaultHandler;

public class Sax {
	
	public static void main(String[] args) throws Exception {
		SAXParserFactory factory = SAXParserFactory.newInstance(); 
		factory.setValidating(true); 
		SAXParser parser = factory.newSAXParser();
		parser.parse(args[0], new SAXHandler()); 
	}
}
	
	