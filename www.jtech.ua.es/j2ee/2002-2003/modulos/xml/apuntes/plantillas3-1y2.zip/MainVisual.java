import javax.swing.JFrame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Dimension;
import java.awt.Toolkit;

import org.w3c.dom.*;
import javax.xml.parsers.*;

public class MainVisual  
{
    public static void main(String argv[])
    {
        JFrame frame = new JFrame("VISUAL DOM");
        frame.addWindowListener(
          new WindowAdapter() {
            public void windowClosing(WindowEvent e) {System.exit(0);}
          }  
        );
        
        try {
        //aqu� ten�is que poner las sentencias para
        //crear un modelo DOM a partir de un documento xml existente
        //que se pasa como par�metro
        	
        
        //El modelo DOM del documento ten�is que asignarlo al
        //atributo document de la clase Visual
            
        } catch (ParserConfigurationException pce) {
            // Parser with specified options can't be built
            pce.printStackTrace();

        } 

        // Actualiza el �rbol, las vistas, y visualiza todo
        final Visual echoPanel = 
           new Visual();
        frame.getContentPane().add("Center", echoPanel );
        frame.pack();
        Dimension screenSize = 
           Toolkit.getDefaultToolkit().getScreenSize();
        int w = Visual.windowWidth + 10;
        int h = Visual.windowHeight + 10;
        frame.setLocation(screenSize.width/3 - w/2, 
                          screenSize.height/2 - h/2);
        frame.setSize(w, h);
        frame.setVisible(true);
    } // main
    
}    