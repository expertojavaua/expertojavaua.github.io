package es.ua.jtech.proyint.cache;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.opensymphony.oscache.general.GeneralCacheAdministrator;

public class CacheManager {

    private static CacheManager me = new CacheManager();

    private Log logger = LogFactory.getLog(CacheManager.class.getName());

    private GeneralCacheAdministrator cache = null;

    private CacheManager() {
        try {
             cache = new GeneralCacheAdministrator();
        } catch (Exception e) {
            logger.error("Error al inicializar la cache", e);
            e.printStackTrace();
        }

        logger.info("Cache Creada");
    }

    public static CacheManager getInstance() {
        return me;
    }

    public GeneralCacheAdministrator getCache() {
        return cache;
    }
}