package es.ua.jtech.proyint.dao;

import com.opensymphony.oscache.general.GeneralCacheAdministrator;

import es.ua.jtech.proyint.cache.CacheManager;
import es.ua.jtech.proyint.dao.libro.ILibroDAO;
import es.ua.jtech.proyint.dao.libro.LibroJDBCDAO;
import es.ua.jtech.proyint.dao.operacion.IOperacionDAO;
import es.ua.jtech.proyint.dao.operacion.OperacionJDBCDAO;
import es.ua.jtech.proyint.dao.usuario.IUsuarioDAO;
import es.ua.jtech.proyint.dao.usuario.UsuarioCacheDAO;

public class FactoriaDAOs {

	private static FactoriaDAOs me = new FactoriaDAOs();

	private GeneralCacheAdministrator cache = null;

	private FactoriaDAOs() {
		// Obtenemos la cache
		this.cache = CacheManager.getInstance().getCache();
	}

	public static FactoriaDAOs getInstance() {
		return me;
	}

	public IUsuarioDAO getUsuarioDAO() {
		// En este DAO cacheamos
		return new UsuarioCacheDAO(this.cache);
	}

	public ILibroDAO getLibroDAO() {
		return new LibroJDBCDAO();
	}

	public IOperacionDAO getOperacionDAO() {
		return new OperacionJDBCDAO();
	}
}
