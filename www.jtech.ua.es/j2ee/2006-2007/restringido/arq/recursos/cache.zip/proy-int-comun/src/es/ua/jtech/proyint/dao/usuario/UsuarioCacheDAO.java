package es.ua.jtech.proyint.dao.usuario;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.opensymphony.oscache.base.NeedsRefreshException;
import com.opensymphony.oscache.general.GeneralCacheAdministrator;

import es.ua.jtech.proyint.dao.DAOException;
import es.ua.jtech.proyint.to.UsuarioTO;

public class UsuarioCacheDAO implements IUsuarioDAO {

	private static Log logger = LogFactory.getLog(UsuarioCacheDAO.class
			.getName());

	private GeneralCacheAdministrator cache;

	private final static String GRUPO_USUARIO = "GrupoUsuario";

	private IUsuarioDAO dao;

	public UsuarioCacheDAO(GeneralCacheAdministrator laCache) {
		this.cache = laCache;
		this.dao = new UsuarioJDBCDAO();
	}

	public void addUsuario(UsuarioTO usuario) throws DAOException {
		dao.addUsuario(usuario);

		// Limpiamos la cache
		cache.flushGroup(UsuarioCacheDAO.GRUPO_USUARIO);

		return;
	}

	public int delUsuario(String login) throws DAOException {
		int result = dao.delUsuario(login);

		// Limpiamos la cache
		cache.flushGroup(UsuarioCacheDAO.GRUPO_USUARIO);

		return result;
	}

	@SuppressWarnings("unchecked")
	public List<UsuarioTO> getAllUsuarios() throws DAOException {
		List<UsuarioTO> result = null;

		// Creamos la clave teniendo en cuenta los parametros
		// TODO Crear una clase de Constantes de Cache (similar a Tokens)
		String key = "UsuarioSelectAll";

		// Primero, buscamos el usuario en la cache (max 600 seg)
		try {
			result = (List<UsuarioTO>) cache.getFromCache(key, 600);
			logger.debug("Listado de usuarios de la cache :)");
		} catch (NeedsRefreshException nre) {
			// si no los encuentra
			try {
				result = dao.getAllUsuarios();

				// los almacenamos en la cache dentro de un grupo
				cache.putInCache(key, result,
						new String[] { UsuarioCacheDAO.GRUPO_USUARIO });
			} catch (Exception ex) {
				logger.warn("Recuperando usuarios de la cache", ex);
				// Tenemos el contenido por si queremos tolerancia a fallos.
				result = (List<UsuarioTO>) nre.getCacheContent();
				// Evitamos el refresco de la cache
				cache.cancelUpdate(key);
			}
		}

		return result;
	}

	public List<UsuarioTO> getPosiblesPrestatarios() throws DAOException {
		return dao.getPosiblesPrestatarios();
	}

	public UsuarioTO selectUsuario(String login, String password)
			throws DAOException {
		return dao.selectUsuario(login, password);
	}

	public UsuarioTO selectUsuario(String login) throws DAOException {
		UsuarioTO result = null;

		// Creamos la clave teniendo en cuenta los parametros
		// TODO Crear una clase de Constantes de Cache (similar a Tokens)
		String key = "Usuario(" + login + ")";

		// Primero, buscamos el usuario en la cache
		try {
			result = (UsuarioTO) cache.getFromCache(key, 600);
		} catch (NeedsRefreshException nre) {
			// si no los encuentra
			try {
				result = dao.selectUsuario(login);

				// los almacenamos en la cache dentro de un grupo
				cache.putInCache(key, result,
						new String[] { UsuarioCacheDAO.GRUPO_USUARIO });
			} catch (Exception ex) {
				logger.warn("Recuperando usuario de la cache", ex);
				// Tenemos el contenido por si queremos tolerancia a fallos.
				result = (UsuarioTO) nre.getCacheContent();
				// Evitamos el refresco de la cache
				cache.cancelUpdate(key);
			}
		}

		return result;
	}

	public int updateUsuario(UsuarioTO usuario) throws DAOException {
		int result = dao.updateUsuario(usuario);

		// Limpiamos la cache
		cache.flushGroup(UsuarioCacheDAO.GRUPO_USUARIO);

		return result;
	}

}
