package es.ua.jtech.jdbc.sesion1;
/**
 * Implementaci�n del patr�n singleton
 * @author miguel
 */
import java.sql.*;

public class FuenteDatos {	
	private static FuenteDatos f;

	private FuenteDatos() throws SQLException{
	}
	
	public static FuenteDatos getInstance () throws SQLException {
	}
	
	public Connection getConnection () throws SQLException {
	}
}
