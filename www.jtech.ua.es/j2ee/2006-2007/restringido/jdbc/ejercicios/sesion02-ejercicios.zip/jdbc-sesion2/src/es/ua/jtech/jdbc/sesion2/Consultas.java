/**
 * Clase principal para la primera sesi�n de JDBC
 */
package es.ua.jtech.jdbc.sesion2;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

import es.ua.jtech.jdbc.sesion2.dao.HotelDAO;
import es.ua.jtech.jdbc.sesion2.dao.UsuarioDAO;
import es.ua.jtech.jdbc.sesion2.dao.VueloDAO;
import es.ua.jtech.jdbc.sesion2.valueobj.Hotel;
import es.ua.jtech.jdbc.sesion2.valueobj.Usuario;
import es.ua.jtech.jdbc.sesion2.valueobj.Vuelo;

/**
 * @author Miguel
 *
 */
public class Consultas {
	UsuarioDAO usuDAO;
	VueloDAO vueDAO;
	HotelDAO hotDAO;
	
	public Consultas () {
		usuDAO = new UsuarioDAO();
		vueDAO = new VueloDAO();
		hotDAO = new HotelDAO();
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Consultas consu = new Consultas();
		consu.muestraUsuarios();
		consu.muestraVuelos();
		consu.muestraHoteles();
		consu.muestraVuelosNombre();
		consu.muestraHotelesNombre();
		consu.consultaUsuarios();
	}
	
	private void muestraVuelosNombre() {
		try {
			System.out.print("Introduzca el nombre del aeropuerto de salida:");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String nomAeroInic = br.readLine();
			
		}
		catch (Exception e) {System.out.println(e);}
	}
	
	private void muestraHotelesNombre() {
		try {
			System.out.print("Introduzca el nombre del hotel:");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String nomHotel = br.readLine();
			
		}
		catch (Exception e) {System.out.println(e);}
	}
	
	public void consultaUsuarios () {
		Integer auxInt;
		int opc=10;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		
		try {
			while (opc!=0) {
				System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"+
						"DNI\tNombre\tApellido1\tApellido2\tDireccion\tNacionalidad");
				System.out.print(
							"\t1.- Registro siguiente.\n"+
							"\t2.- Registro anterior.\n"+
							"\t3.- Ultimo registro.\n"+
							"\t4.- Primer registro.\n"+
							"\t0.- Salir.\n"+
							"\t\tElija una opcion:");
				auxInt = new Integer(br.readLine());
				opc = auxInt.intValue();
				switch (opc) {
					case (1): 
				  			  break;
					case (2): 
							  break;
					case (3): 
							  break;
					case (4): 
							  break;
				}
			}
		}
		catch (Exception e) {System.out.println(e);}
	}
}
