-- ----------------------------------------------------------------------
-- MySQL GRT Application
-- SQL Script
-- ----------------------------------------------------------------------

SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS `viajes`
  CHARACTER SET latin1;
-- -------------------------------------

USE `viajes`;

-- Tables

-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `viajes`.`usuario`;
CREATE TABLE `viajes`.`usuario` (
  DNI int(11) NOT NULL default '0',
  Nombre varchar(50) default NULL,
  Apellido1 varchar(50) default NULL,
  Apellido2 varchar(50) default NULL,
  Direccion varchar(50) default NULL,
  Nacionalidad varchar(50) default NULL,
  PRIMARY KEY  (DNI)
)
ENGINE = InnoDB
ROW_FORMAT = Compact
CHARACTER SET latin1 COLLATE latin1_spanish_ci;

-- Data for usuario
INSERT INTO usuario VALUES (2121212,'Miguel','Cazorlas','Quevedor','Avda Mi casa','Espa�a');
INSERT INTO usuario VALUES (2222222,'Otto','Colomina','Parduzco','C/ Su casa','Espa�a');
INSERT INTO usuario VALUES (3333333,'Domingo','Gallardo','Loperado','C/ Otra casa','Espa�a');
INSERT INTO usuario VALUES (4444444,'Dinio','Gonz�lez','Penalcul','Paseo Habana','Cuba');


-- Table structure for table `vuelo`
--

DROP TABLE IF EXISTS `viajes`.`vuelo`;
CREATE TABLE `viajes`.`vuelo` (
  Numero smallint(6) NOT NULL default '0',
  AeroInic varchar(50) default NULL,
  AeroFin varchar(50) default NULL,
  DiaSal date default NULL,
  DiaLleg date default NULL,
  HoraSal time default NULL,
  HoraLleg time default NULL,
  Avion varchar(50) default NULL,
  PlazasDisp int(10) UNSIGNED default NULL,
  PRIMARY KEY  (Numero)
)
ENGINE = InnoDB
ROW_FORMAT = Compact
CHARACTER SET latin1 COLLATE latin1_spanish_ci;

-- Data for `vuelo`
INSERT INTO vuelo VALUES (2,'ALC','BCN','2003-01-01','2003-01-01','07:30:00','08:10:00','IBE 2',100);
INSERT INTO vuelo VALUES (1,'ALC','MAD','2003-01-01','2003-01-01','07:00:00','07:50:00','IBE 1',10);
INSERT INTO vuelo VALUES (3,'MAD','JFK','2003-01-01','2003-01-01','10:00:00','13:00:00','IBE 3',0);
INSERT INTO vuelo VALUES (4,'MAD','AMS','2003-01-01','2003-01-01','11:00:00','15:00:00','IBE 4',1);
INSERT INTO vuelo VALUES (5,'JFK','SFA','2003-01-01','2003-01-01','15:00:00','18:00:00','AA 1',30);
INSERT INTO vuelo VALUES (6,'JFK','SFA','2003-01-02','2003-01-02','15:00:00','18:00:00','AA 2',40);
INSERT INTO vuelo VALUES (7,'AMS','LHR','2003-01-01','2003-01-01','15:00:00','16:00:00','KLM 1',50);
INSERT INTO vuelo VALUES (8,'MAD','LHR','2003-01-01','2003-01-01','11:00:00','14:00:00','BAI 1',10);
INSERT INTO vuelo VALUES (9,'AMS','SFA','2003-01-01','2003-01-01','10:00:00','13:00:00','KLM 2',12);
INSERT INTO vuelo VALUES (10,'ALC','AMS','2003-01-01','2003-01-01','07:00:00','09:00:00','KLM 3',18);
INSERT INTO vuelo VALUES (11,'AMS','SFA','2003-01-02','2003-01-02','10:00:00','13:00:00','KLM 2',23);
INSERT INTO vuelo VALUES (12,'ALC','MAD','2003-01-02','2003-01-02','07:00:00','07:50:00','IBE 1',76);
INSERT INTO vuelo VALUES (13,'ALC','BCN','2003-01-02','2003-01-02','07:30:00','08:10:00','IBE 2',150);
INSERT INTO vuelo VALUES (14,'MAD','JFK','2003-01-02','2003-01-02','10:00:00','13:00:00','IBE 3',0);
INSERT INTO vuelo VALUES (15,'MAD','AMS','2003-01-02','2003-01-02','11:00:00','15:00:00','IBE 4',1);
INSERT INTO vuelo VALUES (16,'JFK','SFA','2003-01-02','2003-01-02','15:00:00','18:00:00','AA 1',3);
INSERT INTO vuelo VALUES (17,'AMS','LHR','2003-01-02','2003-01-02','15:00:00','16:00:00','KLM 1',5);
INSERT INTO vuelo VALUES (18,'MAD','LHR','2003-01-02','2003-01-02','11:00:00','14:00:00','BAI 1',6);
INSERT INTO vuelo VALUES (19,'ALC','AMS','2003-01-02','2003-01-02','07:00:00','09:00:00','KLM 3',8);


-- Table structure for table `hotel`
--

DROP TABLE IF EXISTS `viajes`.`hotel`;
CREATE TABLE `viajes`.`hotel` (
  Iden smallint(6) NOT NULL default '0',
  Nombre varchar(50) default NULL,
  Direccion varchar(50) default NULL,
  AnyoCrea int(4) default NULL,
  PlazasDisp int(11) UNSIGNED default NULL,
  Precio int(11) default NULL,
  PRIMARY KEY  (Iden)
)
ENGINE = InnoDB
ROW_FORMAT = Compact
CHARACTER SET latin1 COLLATE latin1_spanish_ci;

-- Data for hotel
INSERT INTO hotel VALUES (1,'Hotelito','Avda. Nacional, 14', 1970, 100, 50);
INSERT INTO hotel VALUES (2,'Gran Hotel','C/ Escudero, S/N', 1990, 1, 100);
INSERT INTO hotel VALUES (3,'Hostalito','C/ Paradita, 1', 2001, 23, 30);
INSERT INTO hotel VALUES (4,'Pension','C/ Tenencio, 100',1930,0, 20);


-- Table structure for table `resHotel`
--
DROP TABLE IF EXISTS `viajes`.`resHotel`;
CREATE TABLE `viajes`.`resHotel` (
  `idreserva` INT(11) NOT NULL AUTO_INCREMENT,
  Numhotel smallint(6) NOT NULL,
  DniUsuario int(11) NOT NULL,
  FechaReserva date default NULL,
  Numdias INT(11) default NULL,
  PRIMARY KEY  (idreserva),
  INDEX `Numhotel` (`Numhotel`),
  CONSTRAINT `fk_operacion_Numhotel` FOREIGN KEY `fk_operacion_Numhotel` (`Numhotel`)
    REFERENCES `viajes`.`hotel` (`Iden`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  INDEX `DniUsuario` (`DniUsuario`),
  CONSTRAINT `fk_operacion_DniUsuHotel` FOREIGN KEY `fk_operacion_DniUsuHotel` (`DniUsuario`)
    REFERENCES `viajes`.`usuario` (`DNI`)
    ON DELETE CASCADE
    ON UPDATE CASCADE
)
ENGINE = InnoDB
ROW_FORMAT = Compact
CHARACTER SET latin1 COLLATE latin1_spanish_ci;


-- Data for `resHotel`
INSERT INTO resHotel VALUES (1,1,2121212,'2006-11-02',2);
INSERT INTO resHotel VALUES (2,1,2222222,'2006-11-01',3);
INSERT INTO resHotel VALUES (3,3,2121212,'2006-10-10',1);


-- Table structure for table `resVuelo`
--
DROP TABLE IF EXISTS `viajes`.`resVuelo`;
CREATE TABLE `viajes`.`resVuelo` (
  `idreserva` INT(11) NOT NULL AUTO_INCREMENT,
  Numvuelo smallint(6) NOT NULL,
  DniUsuario int(11) NOT NULL,
  FechaReserva date default null,
  Precio INT(11) default NULL,
  PRIMARY KEY  (idreserva),
  INDEX `Numvuelo` (`Numvuelo`),
  CONSTRAINT `fk_operacion_Numvuelo` FOREIGN KEY `fk_operacion_Numvuelo` (`Numvuelo`)
    REFERENCES `viajes`.`vuelo` (`numero`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  INDEX `DniUsuario` (`DniUsuario`),
  CONSTRAINT `fk_operacion_DniUsuario` FOREIGN KEY `fk_operacion_DniUsuario` (`DniUsuario`)
    REFERENCES `viajes`.`usuario` (`DNI`)
    ON DELETE CASCADE
    ON UPDATE CASCADE
)
ENGINE = InnoDB
ROW_FORMAT = Compact
CHARACTER SET latin1 COLLATE latin1_spanish_ci;


-- Data for `resVuelo`
INSERT INTO resVuelo VALUES (1,1,2121212,'2006-11-02',150);
INSERT INTO resVuelo VALUES (2,1,2222222,'2006-11-01',200);
INSERT INTO resVuelo VALUES (3,3,2121212,'2006-10-10',1500);


SET FOREIGN_KEY_CHECKS = 1;

-- ----------------------------------------------------------------------
-- EOF
