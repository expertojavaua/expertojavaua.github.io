/**
 * Clase principal para la tercera sesi�n de JDBC
 */
package es.ua.jtech.jdbc.sesion3;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import es.ua.jtech.jdbc.sesion3.valueobj.Usuario;
import es.ua.jtech.jdbc.sesion3.dao.HotelDAO;
import es.ua.jtech.jdbc.sesion3.dao.UsuarioDAO;
import es.ua.jtech.jdbc.sesion3.dao.VueloDAO;

/**
 * @author Miguel
 *
 */
public class Consultas {
	UsuarioDAO usuDAO;
	VueloDAO vueDAO;
	HotelDAO hotDAO;
	
	public Consultas () {
		usuDAO = new UsuarioDAO();
		vueDAO = new VueloDAO();
		hotDAO = new HotelDAO();
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Consultas consu = new Consultas();
		consu.actualizaHotelEuros();
		consu.consultaUsuario();
		consu.llamaFuncion();
	}
	
	public void llamaFuncion() {
	}
	
	public void actualizaHotelEuros () {
	}

	private void consultaUsuario() {
	}
}
