/**
 * Clase principal para la cuarta sesi�n de JDBC
 */
package es.ua.jtech.jdbc.sesion4;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * @author Miguel
 *
 */
public class Consultas {
	
	public Consultas () {
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Consultas consu = new Consultas();
		consu.reservaViaje();
	}

	private void reservaViaje() {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.print("Introduzca el numero del hotel:");
			int numHotel = Integer.parseInt(br.readLine());
			System.out.print("Introduzca el DNI del usuario: ");
			int dni=Integer.parseInt(br.readLine());
			System.out.print("Introduzca el numero del vuelo:");
			int numVuelo = Integer.parseInt(br.readLine());
			if (usuDAO.reserva(dni, numHotel, numVuelo)) 
				System.out.println("Reserva efectuada");
			else 
				System.out.println("Alg�n problema en la reserva");
		}
		catch (Exception e) {System.out.println(e);}
		}
}
