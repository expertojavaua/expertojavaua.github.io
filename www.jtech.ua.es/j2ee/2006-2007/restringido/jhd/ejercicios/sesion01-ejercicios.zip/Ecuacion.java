package es.ua.jtech.jhd.sesion1.ejerc3;

/**
  * Esqueleto para el ejercicio de la ecuacion de segundo grado
  */
public class Ecuacion
{
	/**
	  * Constructor
	  */
	public Ecuacion()
	{
	}
	
	/**
	  * Obtiene un array con las dos soluciones a la ecuacion
	  */
	public double[] solucion (double a, double b, double c)
	{ 
		// ... Colocad aqui vuestro codigo
		return new double[]{0.0, 0.0};
	} 

	/**
	  * Main
	  */
	public static void main(String[] args) 
	{ 
		Ecuacion ec = new Ecuacion();
		double[] sol = ec.solucion(4.0, 1.0, -6.0);
		System.out.println ("X1 = " + sol[0] + ", X2 = " + sol[1]); 
	} 
}
