package es.ua.jtech.jhd.sesion1.ejerc1;

import es.ua.jtech.jhd.sesion1.ejerc1.animales.*;
import es.ua.jtech.jhd.sesion1.ejerc1.insectos.Mosca;
import es.ua.jtech.jhd.sesion1.ejerc1.plantas.*;

public class Prueba 
{
	public static void main(String[] args) 
	{

		// Datos del insecto
		Mosca m = new Mosca();
		m.nombre();
		int edad3 = m.edad() + 2;
		System.out.println ("Edad Insecto: " + edad3);

		// Datos del animal
		Elefante e = new Elefante();
		e.nombre();
		int edad2 = e.edad() + 5;
		System.out.println ("Edad Animal: " + edad2);

		// Datos de la planta
		Geranio g = new Geranio();
		g.nombre();
		int edad5 = g.edad();
		System.out.println ("Edad Planta: " + edad5);
	}
}