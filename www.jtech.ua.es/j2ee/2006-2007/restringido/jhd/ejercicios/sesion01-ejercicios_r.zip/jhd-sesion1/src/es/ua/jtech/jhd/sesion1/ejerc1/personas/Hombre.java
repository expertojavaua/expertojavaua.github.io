package es.ua.jtech.jhd.sesion1.ejerc1.personas;

/**
  * Ejemplo de herencias y clases abstractas
  */
public class Hombre implements Persona
{	 
	/* 
	   No hace falta definir el metodo clase(), porque ya esta
	   definido en la clase padre. Lo tendr�amos que definir si
	   queremos devolver algo distinto a lo que devuelve all�
	*/
	
	/**
	  * Devuelve la clase a la que pertenecen los hombres
	  */
	public String clase() 
	{ 
		return "mamiferos"; 
	} 

	/**
	  * Devuelve el genero de la persona (este metodo si hay que
	  * definirlo porque es abstracto en la clase padre)
	  */
	public String genero()
	{
		return "masculino";
	}

	/**
	  * Devuelve la edad de la persona (este metodo si hay que definirlo
	  * porque es abstracto en la clase padre)
	  */
	public String edad()
	{
		return "40";
	}
}
