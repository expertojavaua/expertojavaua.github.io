package es.ua.jtech.jhd.sesion1.ejerc1.personas;

/**
  * Ejemplo de herencias y clases abstractas
  */
public interface Persona
{	  
	/**
	  * Devuelve la clase a la que pertenecen las personas
	  */
	public String clase();

	/**
	  * Devuelve el genero de la persona
	  */
	public abstract String genero();

	/**
	  * Devuelve la edad de la persona
	  */
	public abstract String edad();
}
