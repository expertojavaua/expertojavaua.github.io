package es.ua.jtech.jhd.sesion1.ejerc2;

/**
 * Esqueleto para el ejercicio del factorial
 */
public class Factorial {
	/**
	 * Obtiene el factorial recursivo del numero que se le pasa
	 */
	public static int factorialRec(int num) {
		// ... Colocad aqui vuestro codigo
		if (num == 1)
			return 1;
		return num * factorialRec(num - 1);

	}

	/**
	 * Obtiene el factorial iterativo del numero que se le pasa
	 */
	public static int factorialIter(int num) {
		// ... Colocad aqui vuestro codigo
		int result = 1;

		for (int i = num; i > 0; i--)
			result = result * i;

		return result;

	}

	/**
	 * Main
	 */
	public static void main(String[] args) {
		System.out.println("Factorial de 2 = " + factorialRec(2) + ", "
				+ factorialIter(2));
		System.out.println("Factorial de 1 = " + factorialRec(1) + ", "
				+ factorialIter(1));
		System.out.println("Factorial de 5 = " + factorialRec(5) + ", "
				+ factorialIter(5));

	}
}
