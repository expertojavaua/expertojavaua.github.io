/*
 * Created on 17-sep-2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package es.ua.jtech.jhd.sesion1.ejerc5.arbol;

import java.util.Collection;
/**
 * @author administrador
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class Arbol {


	protected Collection nodo;

	public boolean addNodo(Nodo n) {
		return false;
	}

}
