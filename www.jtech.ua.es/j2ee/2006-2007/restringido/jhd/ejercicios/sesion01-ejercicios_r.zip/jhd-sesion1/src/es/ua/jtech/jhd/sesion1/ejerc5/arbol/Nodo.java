/*
 * Created on 17-sep-2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package es.ua.jtech.jhd.sesion1.ejerc5.arbol;

/**
 * @author administrador
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class Nodo {

	public Clave clave;

	public Valor valor;

	public Clave getClave() {
		return clave;
	}

	public void setClave(Clave clave) {
		this.clave = clave;
	}

	public Valor getValor() {
		return valor;
	}

	public void setValor(Valor valor) {
		this.valor = valor;
	}

	public Nodo(Clave c, Valor v) {
	}

}
