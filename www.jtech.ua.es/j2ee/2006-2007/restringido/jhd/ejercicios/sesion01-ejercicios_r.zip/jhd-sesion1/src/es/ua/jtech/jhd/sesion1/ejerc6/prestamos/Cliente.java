/*
 * Created on 12-oct-2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.jtech.jhd.sesion1.ejerc6.prestamos;

import java.util.ArrayList;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Cliente {

	public final static int MAX_PRESTAMOS = 5;
	
	private String dni;
	private String nombre;
	
	private ArrayList<Prestamo> prestamos = new ArrayList<Prestamo>();
	
	/**
	 * @return Returns the dni.
	 */
	public String getDni() {
		return dni;
	}
	/**
	 * @param dni The dni to set.
	 */
	public void setDni(String dni) {
		this.dni = dni;
	}
	/**
	 * @return Returns the nombre.
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * @param nombre The nombre to set.
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void addPrestamo(Prestamo prestamo) {
		prestamos.add(prestamo);
	}
	
	public void removePrestamo(Prestamo prestamo) {
		prestamos.remove(prestamo);		
	}
	
	public Prestamo [] getPrestamos() {
		Prestamo [] res = new Prestamo[prestamos.size()];
		prestamos.toArray(res);
		return res;
	}
}
