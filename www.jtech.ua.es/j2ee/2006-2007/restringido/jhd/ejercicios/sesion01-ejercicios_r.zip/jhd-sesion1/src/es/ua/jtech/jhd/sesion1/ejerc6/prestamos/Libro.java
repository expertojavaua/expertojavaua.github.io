/*
 * Created on 12-oct-2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.jtech.jhd.sesion1.ejerc6.prestamos;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Libro extends MaterialPrestamo {

	private int numPaginas;
	
	/**
	 * @return Returns the numPaginas.
	 */
	public int getNumPaginas() {
		return numPaginas;
	}
	/**
	 * @param numPaginas The numPaginas to set.
	 */
	public void setNumPaginas(int numPaginas) {
		this.numPaginas = numPaginas;
	}
}
