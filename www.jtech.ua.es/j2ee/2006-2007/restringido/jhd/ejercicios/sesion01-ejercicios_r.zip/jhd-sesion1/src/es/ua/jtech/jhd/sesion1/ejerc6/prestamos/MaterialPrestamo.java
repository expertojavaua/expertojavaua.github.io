/*
 * Created on 12-oct-2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.jtech.jhd.sesion1.ejerc6.prestamos;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MaterialPrestamo {

	private int cod;
	private String autor;
	private String titulo;
	
	/**
	 * @return Returns the autor.
	 */
	public String getAutor() {
		return autor;
	}
	/**
	 * @param autor The autor to set.
	 */
	public void setAutor(String autor) {
		this.autor = autor;
	}
	/**
	 * @return Returns the cod.
	 */
	public int getCod() {
		return cod;
	}
	/**
	 * @param cod The cod to set.
	 */
	public void setCod(int cod) {
		this.cod = cod;
	}
	/**
	 * @return Returns the titulo.
	 */
	public String getTitulo() {
		return titulo;
	}
	/**
	 * @param titulo The titulo to set.
	 */
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
}
