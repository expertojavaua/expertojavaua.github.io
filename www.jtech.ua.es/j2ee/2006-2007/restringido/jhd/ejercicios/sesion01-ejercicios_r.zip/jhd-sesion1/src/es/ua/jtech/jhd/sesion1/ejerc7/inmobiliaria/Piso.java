/*
 * Created on 17-sep-2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package es.ua.jtech.jhd.sesion1.ejerc7.inmobiliaria;

/**
 * @author administrador
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public abstract class Piso {

	public String direccion;

	protected int metros;

	protected String descripcion;

	public double precio;

}
