/*
 * Created on 17-sep-2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package es.ua.jtech.jhd.sesion1.ejerc7.inmobiliaria;

/**
 * @author administrador
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class Prestamo {

	public Cliente cliente;

	protected double interes;

	public boolean aval = false;

	protected double cantidad;

	protected int anyos;

}
