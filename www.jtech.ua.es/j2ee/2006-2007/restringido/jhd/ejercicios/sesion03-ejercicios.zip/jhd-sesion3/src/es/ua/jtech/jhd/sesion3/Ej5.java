package es.ua.jtech.jhd.sesion3;
public class Ej5 {
	public Ej5() {
		Recipiente rec = new Recipiente();

		Productor prod = new Productor(rec);
		Consumidor cons = new Consumidor(rec);

		prod.start();
		cons.start();
	}

	public static void main(String[] args) {
		new Ej5();
	}

	// ----------------------------------------------------------------------------
	// Devuelve un n�mero entero aleatorio entre min y max, ambos inclusive
	// ----------------------------------------------------------------------------

	private int getRandom(int min, int max) {
		double rand = Math.random();

		double num = (max - min) * rand + min;

		return (int) Math.round(num);
	}

	// ----------------------------------------------------------------------------
	//  Hilo productor
	// ----------------------------------------------------------------------------

	class Productor extends Thread {
		Recipiente rec;

		int iter = 10;

		int delay = 1000;

		public Productor(Recipiente rec) {
			this.rec = rec;
		}

		public void run() {
			for (int i = 0; i < iter; i++) {

				// Duerme entre 1 y 2 segundos aleatoriamente

				try {
					sleep(getRandom(1000, 2000));
				} catch (InterruptedException e) {
				}

				// Produce el valor de la iteracion actual

				rec.produce(i);
				System.out.println("Produce " + i);
			}
		}
	}

	// ----------------------------------------------------------------------------
	//  Hilo consumidor
	// ----------------------------------------------------------------------------

	class Consumidor extends Thread {
		Recipiente rec;

		int iter = 10;

		public Consumidor(Recipiente rec) {
			this.rec = rec;
		}

		public void run() {
			int valor;

			for (int i = 0; i < iter; i++) {

				// Duerme entre 1 y 2 segundos aleatoriamente

				try {
					sleep(getRandom(1000, 2000));
				} catch (InterruptedException e) {
				}

				// Consume el dato del recipiente y lo muestra

				valor = rec.consume();
				System.out.println("Consume " + valor);
			}
		}
	}

	// ----------------------------------------------------------------------------
	//  Recipiente para depositar datos
	// ----------------------------------------------------------------------------

	class Recipiente {

		// Indica si hay un dato disponible para consumir
		boolean disponible;

		// Valor almacenado
		int valor;

		public Recipiente() {
			disponible = false;
		}

		public int consume() {

			// TODO: Si no hay datos disponibles esperar a que se produzcan

			// TODO: Ya no hay datos disponibles 

			// TODO: Notificar de que el recipiente esta libre a productores en espera 

			return valor;
		}

		public void produce(int valor) {

			// TODO: Si hay datos disponibles esperar a que se consuman 

			this.valor = valor;

			// TODO: Ya hay datos disponibles 

			// TODO: Notificar de la llegada de datos a consumidores a la espera 

		}
	}

}