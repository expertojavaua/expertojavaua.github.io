package es.ua.jtech.jhd.sesion3;

public class Ej2 {

	// TODO: Declarar que el m�todo logaritmo puede lanzar excepciones

	public static double logaritmo(double num) throws WrongParameterException {

		if (num <= 0) {
			// throw new IllegalArgumentException("El logaritmo solo se define
			// para numeros positivos");
			throw new WrongParameterException(
					"El logaritmo solo se define para numeros positivos");

		}

		return Math.log(num);
	}

	public static void main(String[] args) {

		double num = Double.parseDouble(args[0]);

		try {
			System.out.println("Logaritmo = " + logaritmo(num));
		} catch (WrongParameterException e) {
			System.err.println(e.getMessage());
		}
	}
}