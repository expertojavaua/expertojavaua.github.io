package es.ua.jtech.jhd.sesion3;

public class WrongParameterException extends Exception {

	private static final long serialVersionUID = 1L;

	public WrongParameterException(String msg) {
		super(msg);
	}

}
