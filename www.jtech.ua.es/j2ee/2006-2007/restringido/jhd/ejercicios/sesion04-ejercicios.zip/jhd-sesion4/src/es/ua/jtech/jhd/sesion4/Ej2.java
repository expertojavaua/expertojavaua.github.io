package es.ua.jtech.jhd.sesion4;
import java.io.*;

public class Ej2 {

	public Ej2(String origen, String destino) {
		copia(origen, destino);
	}

	public void copia(String origen, String destino) {
		int c;

		// TODO: Eliminar el comentario y a�adir aqu� el c�digo necesario para que compile
		/* BORRAR ESTA LINEA
			// Abre fichero de entrada y de salida

			FileReader in = new FileReader(origen);
			FileWriter out = new FileWriter(destino);
	
			// Copia caracter a caracter
	
			while ((c = in.read()) != -1) {
				out.write(c);
			}
	
			// Cierra ficheros
	
			in.close();
			out.close();
		BORRAR ESTA LINEA */ 
	}

	public static void main(String[] args) {
		if (args.length != 2) {
			System.err.println("Uso: java Ej2 fichero_origen fichero_destino");
			System.exit(1);
		}

		new Ej2(args[0], args[1]);
	}
}
