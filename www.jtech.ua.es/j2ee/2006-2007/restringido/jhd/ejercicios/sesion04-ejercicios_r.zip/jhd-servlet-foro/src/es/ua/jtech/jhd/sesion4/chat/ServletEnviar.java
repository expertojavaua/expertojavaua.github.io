/*
 * Created on 23-oct-2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.jtech.jhd.sesion4.chat;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ServletEnviar extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void init() throws ServletException {
		ServletContext sc = this.getServletContext();

		ListaMensajes lista = new ListaMensajes(20);
		sc.setAttribute("mensajes", lista);
	}

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		ServletContext sc = this.getServletContext();
		ListaMensajes lista = (ListaMensajes)sc.getAttribute("mensajes");

		// Registra el mensaje de un usuario
		InputStream in = req.getInputStream();
		DataInputStream dis = new DataInputStream(in);
		String nick = dis.readUTF();
		String msg = dis.readUTF();

		lista.nuevoMensaje(nick, msg);

		in.close();

		res.setStatus(HttpServletResponse.SC_OK);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doGet(req,res);
	}

}
