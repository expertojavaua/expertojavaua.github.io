package es.ua.jtech.jhd.sesion4;
import java.io.*;

public class Ej1 {

	public static void leeFichero(String filename) {
		String s;

		// TODO:Establecer el tipo de flujo de entrada adecuado.
		BufferedReader in = null;

		try {
			in = new BufferedReader(new FileReader(filename)); 

			// Lee el fichero caracter a caracter

			while ((s = in.readLine()) != null) {
				System.out.println(s);
			}

			in.close();

			/*
			int c;

			in = new BufferedReader(new FileReader(filename)); 

			// Lee el fichero caracter a caracter

			while ((c = in.read()) != -1) {
				System.out.print((char) c);
			}

			in.close();
			*/
		} catch (IOException e) {
			System.err.println("Error en la E/S");
		}
	}

	public static void main(String[] args) {

		if (args.length != 1) {
			System.out.println("Uso: java Ej1 nombre_fichero");
			System.exit(1);
		}

		leeFichero(args[0]);
	}
}
