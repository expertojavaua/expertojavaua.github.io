package es.ua.jtech.jhd.sesion4;
import java.io.*;

public class Ej2 {

	public Ej2(String origen, String destino) {
		try {
			copia(origen, destino);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void copia(String origen, String destino) throws IOException {
		int c;

			// Abre fichero de entrada y de salida

			//FileReader in = new FileReader(origen);
			//FileWriter out = new FileWriter(destino);
			FileInputStream in = new FileInputStream(origen);
			FileOutputStream out = new FileOutputStream(destino);
	
			// Copia caracter a caracter
	
			while ((c = in.read()) != -1) {
				out.write(c);
			}
	
			// Cierra ficheros
	
			in.close();
			out.close();
	}

	public static void main(String[] args) {
		if (args.length != 2) {
			System.err.println("Uso: java Ej2 fichero_origen fichero_destino");
			System.exit(1);
		}

		new Ej2(args[0], args[1]);
	}
}
