package es.ua.jtech.jhd.sesion4;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

import es.ua.jtech.jhd.sesion4.io.EntradaConsola;

public class Ej4 {

	private final static String URL_LISTA =
		"http://jtech.ua.es/ejemplos-j2ee/jhd/foro/servlet/ServletLista";
	private final static String URL_ENVIAR =
		"http://jtech.ua.es/ejemplos-j2ee/jhd/foro/servlet/ServletEnviar";

	String nick;
	EntradaConsola ec;

	public Ej4() throws IOException {
		ec = new EntradaConsola();

		menu();
	}

	public void menu() throws IOException {
		nick = ec.promptLine("Nick: ");

		while (true) {
			System.out.println("(1) Ver mensajes");
			System.out.println("(2) Enviar mensaje");
			System.out.println("(0) Salir");

			String opcion = ec.promptLine("Opcion: ");

			if (opcion.trim().equals("1")) {
				leeMensajes();
			} else if (opcion.trim().equals("2")) {
				enviaMensaje();
			} else if (opcion.trim().equals("0")) {
				break;
			}
		}
	}

	private void leeMensajes() throws IOException {

		URL url = new URL(URL_LISTA);
		URLConnection con = url.openConnection();
		InputStream in = con.getInputStream();

		DataInputStream dis = new DataInputStream(in);
		try {
		  while(true) {
		    String msg = dis.readUTF();
		    System.out.println(msg);
		  }
		} catch(EOFException e) {}
	}

	private void enviaMensaje() throws IOException {
		String msg = ec.promptLine("Mensaje: ");

		URL url = new URL(URL_ENVIAR);
		URLConnection con = url.openConnection();
		con.setDoOutput(true);
		OutputStream out = con.getOutputStream();
		
		DataOutputStream dos = new DataOutputStream(out);
		dos.writeUTF(nick);
		dos.writeUTF(msg);
		
		con.getInputStream();
	}

	public static void main(String[] args) {
		try {
			new Ej4();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
