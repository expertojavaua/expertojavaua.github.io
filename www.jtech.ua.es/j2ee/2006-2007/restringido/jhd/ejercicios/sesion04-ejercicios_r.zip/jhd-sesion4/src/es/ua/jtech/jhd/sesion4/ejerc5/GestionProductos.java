package es.ua.jtech.jhd.sesion4.ejerc5;

import java.util.*;
import java.io.*;

public class GestionProductos {

	private final static String FICHERO_DATOS = "prod.dat";

	ArrayList<Producto> productos;

	public GestionProductos() {
		try {
			productos = recuperar();
		} catch(IOException e) {
			productos = new ArrayList<Producto>();
		}
	}

	public void nuevoProducto(Producto prod) {
		productos.add(prod);
	}

	public Producto[] leeProductos() {
		int tam = productos.size();
		Producto[] lista = new Producto[tam];

		productos.toArray(lista);
		return lista;
	}

	public void eliminaProducto(int indice) {
		productos.remove(indice);
	}

	public void guardar() throws IOException {
		almacenar(productos);
	}

	private static void almacenar(ArrayList<Producto> productos) throws IOException {

		FileOutputStream fos = new FileOutputStream(FICHERO_DATOS);
		
/*
		DataOutputStream dos = new DataOutputStream(fos);
		
		Iterator iter = productos.iterator();
		while (iter.hasNext()) {
			Producto prod = (Producto) iter.next();

			dos.writeUTF(prod.titulo);
			dos.writeUTF(prod.autor);
			dos.writeFloat(prod.precio);
			dos.writeBoolean(prod.stock);
		}

		dos.close();
*/
		
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		Iterator iter = productos.iterator();
		while (iter.hasNext()) {
			Producto prod = (Producto) iter.next();
			oos.writeObject(prod);
		}

		oos.close();

	}

	private static ArrayList<Producto> recuperar() throws IOException {

		ArrayList<Producto> productos = new ArrayList<Producto>();

		FileInputStream fis = new FileInputStream(FICHERO_DATOS);
/*
		DataInputStream dis = new DataInputStream(fis);

		try {
			while (true) {
				String titulo = dis.readUTF();
				String autor = dis.readUTF();
				float precio = dis.readFloat();
				boolean stock = dis.readBoolean();

				productos.add(new Producto(titulo, autor, precio, stock));
			}
		} catch (EOFException e) {
		}
*/
		ObjectInputStream ois = new ObjectInputStream(fis);

		try {
			while (true) {
				Producto prod = (Producto)ois.readObject();
				productos.add(prod);
			}
		} catch (EOFException e) {
		} catch (ClassNotFoundException e2) {
			System.err.println("Error leyendo datos");
		}

		return productos;
	}

}
