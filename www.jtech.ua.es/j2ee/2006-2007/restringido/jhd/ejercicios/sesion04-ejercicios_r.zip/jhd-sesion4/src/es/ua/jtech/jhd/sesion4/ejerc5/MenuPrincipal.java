package es.ua.jtech.jhd.sesion4.ejerc5;

import java.io.*;
import es.ua.jtech.jhd.sesion4.io.EntradaConsola;

public class MenuPrincipal {

	EntradaConsola ec;
	GestionProductos gp;

	public MenuPrincipal() {
		gp = new GestionProductos();
		ec = new EntradaConsola();
	}

	public void menu() {
		while(true) {
			System.out.println("(1) Ver productos");
			System.out.println("(2) Nuevo producto");
			System.out.println("(3) Eliminar producto");
			System.out.println("(0) Salir");

			String opcion = ec.promptLine("Opcion: ");
		
			if(opcion.trim().equals("1")) {
				listaProductos();
			} else if(opcion.trim().equals("2")) {
				datosProducto();
			} else if(opcion.trim().equals("3")) {
				eliminaProducto(); 
			} else if(opcion.trim().equals("0")) {
				salir();
			}
		}
	}
	
	public void salir() {
		try {
			gp.guardar();
		} catch(IOException e) {
			System.err.println("Error al guardar los datos");
		}
		
		System.exit(0);
	}
	
	public void datosProducto() {		

		boolean correcto;

		float precio = 0.0f;
		boolean disponible = false;
		String titulo = ec.promptLine("Titulo: ");
		String autor = ec.promptLine("Autor: ");

		do {
			String aux = ec.promptLine("Precio: ");

			try {
				precio = Float.parseFloat(aux);
				correcto = true;
			} catch(NumberFormatException e) {
				correcto = false;
			}
		} while(!correcto);

		do {
			String aux = ec.promptLine("En stock (s/n): ");
			correcto = true;
			if(aux.trim().toLowerCase().equals("s")) {
				disponible = true;
			} else if(aux.trim().toLowerCase().equals("n")) { 
				disponible = false;
			} else {
				correcto = false;
			}
		} while(!correcto);

		gp.nuevoProducto(new Producto(titulo, autor, precio, disponible));
	}
	
	public void listaProductos() {

		Producto [] productos = gp.leeProductos();
		
		for(int i=0;i<productos.length;i++) {
			System.out.println("Producto " + i + ":");
			System.out.println("============");
			System.out.println(productos[i]);
			System.out.println("");
		}
	}
	
	public void eliminaProducto() {
		String indice = ec.promptLine("Numero del producto a eliminar: ");

		try {
			int i = Integer.parseInt(indice);
			gp.eliminaProducto(i);
		} catch(Exception e) {
			System.err.println("Error: No se puede eliminar el producto");
		}
	}
	
	public static void main(String [] args) {
		MenuPrincipal mp = new MenuPrincipal();
		mp.menu();
	}
}
