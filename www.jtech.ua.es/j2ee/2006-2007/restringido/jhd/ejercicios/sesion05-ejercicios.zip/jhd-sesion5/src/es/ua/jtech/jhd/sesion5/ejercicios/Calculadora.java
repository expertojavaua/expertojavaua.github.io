package es.ua.jtech.jhd.sesion5.ejercicios;

import java.awt.*;
import java.awt.event.*;

// Clase que implementa una calculadora sencilla

public class Calculadora extends Frame
{
	// Operandos
	TextField txtOp1;
		
	// Constructor
	public Calculadora()
	{
		setSize(300, 150);
		setLayout(new GridLayout(4, 2));
		
		// Primer operando
		Label lblOp1 = new Label("Primer operando:");
		txtOp1 = new TextField();
		add(lblOp1);
		add(txtOp1);
		
		// Aqu� deber�is colocar el resto de vuestro c�digo...
		
		// Operador
		

		// Segundo operando

		
		// Resultado

		
		// Evento sobre el bot�n

	}
	
	// Funcion principal
	public static void main (String[] args)
	{
		Calculadora c = new Calculadora();
		c.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
		c.setVisible(true);
	}
	
	
}