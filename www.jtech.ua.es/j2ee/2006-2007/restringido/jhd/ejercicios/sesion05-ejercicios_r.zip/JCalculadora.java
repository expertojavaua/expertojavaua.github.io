import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

// Clase que implementa una calculadora sencilla

public class JCalculadora extends JFrame
{
	// Operandos
	JTextField txtOp1, txtOp2;
	
	// Resultado
	JTextField txtRes;
	
	// Operadores
	JComboBox operadores;
	
	// Boton de resultado
	JButton btnRes;
	
	// Constructor
	public JCalculadora()
	{
		setSize(300, 150);
		getContentPane().setLayout(new GridLayout(4, 2));
		
		// Primer operando
		JLabel lblOp1 = new JLabel("Primer operando:");
		txtOp1 = new JTextField();
		getContentPane().add(lblOp1);
		getContentPane().add(txtOp1);
		
		// Operador
		JLabel lblOper = new JLabel ("Operador:");
		operadores = new JComboBox();
		operadores.addItem("+");
		operadores.addItem("-");
		operadores.addItem("*");
		getContentPane().add(lblOper);
		getContentPane().add(operadores);
		
		// Segundo operando
		JLabel lblOp2 = new JLabel("Segundo operando:");
		txtOp2 = new JTextField();
		getContentPane().add(lblOp2);
		getContentPane().add(txtOp2);
		
		// Resultado
		btnRes = new JButton ("Calcular");
		txtRes = new JTextField();
		getContentPane().add(btnRes);
		getContentPane().add(txtRes);
		
		// Evento sobre el bot�n
		btnRes.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				int op1, op2;
				try
				{
					op1 = Integer.parseInt(txtOp1.getText());
					op2 = Integer.parseInt(txtOp2.getText());	
					
					if (((String)(operadores.getSelectedItem())).equals("+"))
						txtRes.setText("" + (op1 + op2));
					else if (((String)(operadores.getSelectedItem())).equals("-"))
						txtRes.setText("" + (op1 - op2));
					else if (((String)(operadores.getSelectedItem())).equals("*"))
						txtRes.setText("" + (op1 * op2));					
				} catch (Exception ex) {
					txtRes.setText("ERROR EN LOS OPERANDOS");
				}
			}
		});
	}
	
	// Funcion principal
	public static void main (String[] args)
	{
		JCalculadora c = new JCalculadora();
		c.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
		c.show();
	}
	
	
}