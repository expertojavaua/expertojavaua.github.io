package es.ua.jtech.jhd.sesion6.ejemplos;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class EjemploAction extends JFrame
{
	// Cuadro de texto
	JTextField txt;
	
	// Boton
	JButton btn;
	
	// Cuadro de texto resultado
	JTextField txtRes;
	
	// Constructor
	public EjemploAction()
	{
		setSize(200, 200);
		
		Action ac = new MiAction();
		
		txt = new JTextField();
		btn = new JButton("Copiar");
		txtRes = new JTextField();
		
		txt.addActionListener(ac);
		btn.addActionListener(ac);
		
		add(txt, BorderLayout.NORTH);
		add(btn, BorderLayout.CENTER);
		add(txtRes, BorderLayout.SOUTH);
	}

	// Funcion principal
	public static void main (String[] args)
	{
		EjemploAction ea = new EjemploAction();
		ea.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
		ea.pack();
		ea.setVisible(true);
	}

	// Clase que implementa la accion
	class MiAction extends AbstractAction
	{
		// Constructor
		public MiAction()
		{
		}
		
		// Evento de disparo de accion
		public void actionPerformed(ActionEvent e)
		{
			txtRes.setText(txt.getText());
		}
	}
}
