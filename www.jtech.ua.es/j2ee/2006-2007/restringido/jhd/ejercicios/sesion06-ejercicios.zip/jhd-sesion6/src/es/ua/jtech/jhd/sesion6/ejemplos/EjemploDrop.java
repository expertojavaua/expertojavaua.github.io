package es.ua.jtech.jhd.sesion6.ejemplos;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class EjemploDrop extends JFrame
{
	// Cuadro de texto
	JTextField txt;
	
	// Lista
	JList lst;
		
	// Constructor
	public EjemploDrop()
	{
		setSize(200, 200);
			
		txt = new JTextField();

		DefaultListModel dlm = new DefaultListModel();
		dlm.addElement("Elemento 1");
		dlm.addElement("Elemento 2");
		lst = new JList(dlm);
		lst.setDragEnabled(true);
				
		add(txt, BorderLayout.NORTH);
		add(lst, BorderLayout.CENTER);
	}

	// Funcion principal
	public static void main (String[] args)
	{
		EjemploDrop ed = new EjemploDrop();
		ed.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
		ed.pack();
		ed.setVisible(true);
	}
}
