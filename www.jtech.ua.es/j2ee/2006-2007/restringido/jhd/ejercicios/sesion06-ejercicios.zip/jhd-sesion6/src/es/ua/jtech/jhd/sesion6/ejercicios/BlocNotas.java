package es.ua.jtech.jhd.sesion6.ejercicios;

import javax.swing.*;
import java.awt.event.*;

public class BlocNotas extends JFrame
{	
	// Constructor
	public BlocNotas()
	{		
	}

	// Funcion principal
	public static void main (String[] args)
	{
		BlocNotas bd = new BlocNotas();
		bd.setSize(400, 400);
		bd.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
		bd.setVisible(true);
	}	
}