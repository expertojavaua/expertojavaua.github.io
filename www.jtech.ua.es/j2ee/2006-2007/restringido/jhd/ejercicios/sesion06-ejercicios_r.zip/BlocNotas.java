import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class BlocNotas extends JFrame
{
	// Cuadro de texto para elegir el fichero
	JTextField txt;
	
	// Area de texto donde escribir
	JTextArea txtMain;
	
	// Etiqueta con icono
	JLabel lblInf;
	
	// Contador de grabaciones
	int cont = 0;
	
	// Este frame (para tener una referencia en los dialogos)
	JFrame padre = this;
	
	// Constructor
	public BlocNotas()
	{		
		// Panel superior con el cuadro de texto y el boton para elegir fichero
		
		JPanel p = new JPanel();			

		txt = new JTextField(20);
		JButton btnChoose = new JButton("...");
		
		p.add(txt);
		p.add(btnChoose);
		
		// Cuadro de texto central y etiqueta inferior
		
		txtMain = new JTextArea();
		JScrollPane panelBuffer = new JScrollPane(txtMain);

		lblInf = new JLabel("0 grabaciones", new ImageIcon("ejercicio_save.gif"), SwingConstants.CENTER);
		
		// Accion para coordinar grabaciones del timer y del CTRL+G
		
		BlocAction ba = new BlocAction();
		
		// Timer para grabar cada 10 seg.
		
		Timer t = new Timer(10000, ba);
		t.setRepeats(true);
		t.start();
		
		// Asignacion de pulsacion CTRL+G para grabar

		txtMain.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke('G',InputEvent.CTRL_MASK), "grabar");
		txtMain.getActionMap().put("grabar", ba);

		// A�adir todo al frame
						
		getContentPane().add(p, BorderLayout.NORTH);
		getContentPane().add(panelBuffer, BorderLayout.CENTER);
		getContentPane().add(lblInf, BorderLayout.SOUTH);
		
		// Evento del boton de elegir fichero
		
		btnChoose.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				JFileChooser fc = new JFileChooser(".");
				int res = fc.showSaveDialog(padre.getContentPane());
				if (res == JFileChooser.APPROVE_OPTION)
					txt.setText(fc.getSelectedFile().getAbsolutePath());
				else
					System.out.println ("res = " + res);
			}
		});
	}

	// Funcion principal
	public static void main (String[] args)
	{
		BlocNotas bd = new BlocNotas();
		bd.setSize(400, 400);
		bd.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
		bd.show();
	}
	
	// Action para coordinar la pulsacion de teclas y el evento de timer
	class BlocAction extends AbstractAction
	{
		public BlocAction()
		{
		}
		
		public void actionPerformed(ActionEvent e)
		{
			if (txt.getText().length() > 0)
			{
				try
				{
					PrintWriter pw = new PrintWriter(new FileOutputStream(txt.getText()));
					pw.print(txtMain.getText());
					pw.close();
					cont++;
					lblInf.setText("" + cont + " grabaciones");
				} catch(Exception ex) {
					System.out.println ("Error al escribir en fichero");
				}
			}
		}
	}
}