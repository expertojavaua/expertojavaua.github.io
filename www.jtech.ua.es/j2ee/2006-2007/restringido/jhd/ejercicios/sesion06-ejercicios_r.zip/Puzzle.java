import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Puzzle extends JFrame implements ActionListener
{
	// Array de botones 3 x 3
	JButton[][] botones = new JButton[3][3];
	
	// Panel donde colocar los botones
	JPanel panel = new JPanel();
	
	public Puzzle()
	{
		panel.setLayout(new GridLayout(3, 3));
		
		int cont = 1;
		
		// Crear los botones
		
		for (int i = 0; i < 3; i++)
		{
			for(int j = 0; j < 3; j++)
			{
				botones[i][j] = new JButton("" + cont);
				cont++;
				botones[i][j].addActionListener(this);
			}
		}
		botones[2][2] = null;
		
		actualizaPanel();
		
		getContentPane().add(panel, BorderLayout.CENTER);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		String accion = e.getActionCommand();
		
		// Buscar el boton con el texto de la accion en el array
		int iBoton = -1, jBoton = -1;
		for (int i = 0; i < botones.length; i++)
		{
			for (int j = 0; j < botones[i].length; j++)
			{
				if (botones[i][j] != null)
				{
					if (botones[i][j].getText().equals(accion))
					{
						iBoton = i;
						jBoton = j;
					}
				}
			}
		}
		
		// Buscar la casilla vac�a
		int iVacia = -1, jVacia = -1;
		for (int i = 0; i < botones.length; i++)
		{
			for (int j = 0; j < botones[i].length; j++)
			{
				if (botones[i][j] == null)
				{
					iVacia = i;
					jVacia = j;
				}
			}
		}
		
		// Comprobar si pueden intercambiarse
		if ((iBoton == iVacia && Math.abs(jBoton - jVacia) == 1) || (jBoton == jVacia && Math.abs(iBoton - iVacia) == 1))
		{
			botones[iVacia][jVacia] = botones[iBoton][jBoton];
			botones[iBoton][jBoton] = null;
			actualizaPanel();
		}
	}
	
	// Actualiza el panel central
	public void actualizaPanel()
	{
		panel.removeAll();
	
		for (int i = 0; i < 3; i++)
		{
			for(int j = 0; j < 3; j++)
			{
				if (botones[i][j] != null)
					panel.add(botones[i][j]);
				else
					panel.add(new JLabel());
			}
		}
		
		panel.updateUI();
	}
	
	public static void main (String[] args)
	{
		Puzzle p = new Puzzle();
		p.setSize(200, 200);
		p.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
		p.show();
	}
}