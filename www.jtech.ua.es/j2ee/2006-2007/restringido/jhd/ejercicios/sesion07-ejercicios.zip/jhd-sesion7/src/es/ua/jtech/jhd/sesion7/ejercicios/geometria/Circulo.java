package es.ua.jtech.jhd.sesion7.ejercicios.geometria;

public class Circulo
{
	// Coordenadas X e Y
	int x, y;
	
	// Radio
	int radio;
	
	// Constructor
	public Circulo(int x, int y, int radio)
	{
		this.x = x;
		this.y = y;
		this.radio = radio;
	}
	
	// Area del circulo
	public int area()
	{
		return (int)(Math.PI * radio * radio);
	}
	
	// Longitud del circulo
	public int longitud()
	{
		return (int)(2 * Math.PI * radio);
	}
}