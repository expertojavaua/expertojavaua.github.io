package es.ua.jtech.jhd.sesion7.ejemplos;

import junit.framework.Test;
import junit.framework.TestSuite;

public class MatrizSuite {

	public static Test suite()
	{
		TestSuite suite  = new TestSuite("suiteRaiz");
		TestSuite suiteA = new TestSuite("suiteSuma");
		TestSuite suiteB = new TestSuite("suiteResta");

		suiteA.addTest(new MatrizTest("testSuma"));

		suiteB.addTest(new MatrizTest("testResta"));
		suiteB.addTest(new MatrizTest("testResta2"));

		suite.addTest(suiteA);
		suite.addTest(suiteB);

		return suite;
	}

	public static void main (String[] args)
	{
		junit.swingui.TestRunner.run(MatrizSuite.class);
	}
}
