package es.ua.jtech.jhd.sesion7.ejemplos;

import junit.framework.*;

public class MatrizTest extends TestCase
{
	final static int[][] MATRIZ =  {{1, 0, 0},
					{0, 1, 0},
					{0, 0, 1}};

	final static int[][] SUMA   =  {{2, 0, 0},
					{0, 2, 0},
					{0, 0, 2}};

	final static int[][] RESTA  =  {{0, 0, 0},
					{0, 0, 0},
					{0, 0, 0}};

	Matriz m1, m2;

	public MatrizTest(String nombre)
	{
		super(nombre);
	}

	public void setUp()
	{
		m1 = new Matriz(MATRIZ);
		m2 = new Matriz(MATRIZ);
	}

	public void testSuma()
	{
		Matriz msumaOK   = new Matriz(SUMA);
		Matriz msumaTest = m1.suma(m2);

		assertTrue(msumaOK.equals(msumaTest));
	}

	public void testResta()
	{
		Matriz mrestaOK   = new Matriz(RESTA);
		Matriz mrestaTest = m1.resta(m2);

		assertTrue(mrestaOK.equals(mrestaTest));
	}

	public void testResta2()
	{
		Matriz mrestaOK   = new Matriz(RESTA);
		Matriz mrestaTest = m1.resta2(m2);

		assertTrue(mrestaOK.equals(mrestaTest));
	}
	
	public static void main (String[] args)
	{
		junit.swingui.TestRunner.run(MatrizTest.class);
	}
}