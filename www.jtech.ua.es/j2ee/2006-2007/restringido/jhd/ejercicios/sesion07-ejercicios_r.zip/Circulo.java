
public class Circulo
{
	// Coordenadas X e Y
	int x, y;
	
	// Radio
	int radio;
	
	// Constructor
	public Circulo(int x, int y, int radio)
	{
		this.x = x;
		this.y = y;
		this.radio = radio;
	}
	
	// Area del circulo
	public double area()
	{
		return Math.PI * radio * radio;
	}
	
	// Longitud del circulo
	public double longitud()
	{
		return 2 * Math.PI * radio;
	}
}