import junit.framework.*;

public class CirculoTest extends TestCase
{
	public CirculoTest(String nombre)
	{
		super(nombre);
	}
	
	Circulo c;
	
	public void setUp()
	{
		c = new Circulo(0, 0, 1);
	}

	public void testArea()
	{
		assertTrue(c.area() == Math.PI);
	}

	public void testLongitud()
	{
		assertTrue(c.longitud() == 2 * Math.PI);
	}

	public static void main (String[] args)
	{
		junit.swingui.TestRunner.run(CirculoTest.class);
	}
}