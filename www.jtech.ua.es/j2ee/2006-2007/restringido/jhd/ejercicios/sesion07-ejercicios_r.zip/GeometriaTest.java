import junit.framework.*;

public class GeometriaTest extends TestCase
{
	public GeometriaTest(String nombre)
	{
		super(nombre);
	}

	public static Test suite()
	{
		TestSuite suite  = new TestSuite("suiteRaiz");
		suite.addTest(new TestSuite(MiVectorTest.class));
		suite.addTest(new TestSuite(CirculoTest.class));

		return suite;
	}

	public static void main (String[] args)
	{
		junit.swingui.TestRunner.run(GeometriaTest.class);
	}
}