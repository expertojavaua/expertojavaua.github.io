import junit.framework.*;

public class MatrizTest extends TestCase
{
	final static int[][] MATRIZ =  {{1, 0, 0},
					{0, 1, 0},
					{0, 0, 1}};

	final static int[][] SUMA   =  {{2, 0, 0},
					{0, 2, 0},
					{0, 0, 2}};

	final static int[][] RESTA  =  {{0, 0, 0},
					{0, 0, 0},
					{0, 0, 0}};

	Matriz m1, m2;

	public MatrizTest(String nombre)
	{
		super(nombre);
	}

	public void setUp()
	{
		m1 = new Matriz(MATRIZ);
		m2 = new Matriz(MATRIZ);
	}

	public void testSuma()
	{
		Matriz msumaOK   = new Matriz(SUMA);
		Matriz msumaTest = m1.sumar(m2);

		assertTrue(msumaOK.equals(msumaTest));
	}

	public void testResta()
	{
		Matriz mrestaOK   = new Matriz(RESTA);
		Matriz mrestaTest = m1.restar(m2);

		assertTrue(mrestaOK.equals(mrestaTest));
	}

	public void testResta2()
	{
		Matriz mrestaOK   = new Matriz(RESTA);
		Matriz mrestaTest = m1.restar2(m2);

		assertTrue(mrestaOK.equals(mrestaTest));
	}
	
	public void testMultiplicar()
	{
		Matriz mmulOK   = new Matriz(MATRIZ);
		Matriz mmulTest = m1.multiplicar(m2);

		assertTrue(mmulOK.equals(mmulTest));
	}


	public static Test suite()
	{
		TestSuite suite  = new TestSuite("suiteRaiz");
		TestSuite suiteA = new TestSuite("suiteSuma");
		TestSuite suiteB = new TestSuite("suiteResta");
		TestSuite suiteC = new TestSuite("suiteMultiplicacion");

		suiteA.addTest(new MatrizTest("testSuma"));

		suiteB.addTest(new MatrizTest("testResta"));
		suiteB.addTest(new MatrizTest("testResta2"));
		
		suiteC.addTest(new MatrizTest("testMultiplicar"));

		suite.addTest(suiteA);
		suite.addTest(suiteB);
		suite.addTest(suiteC);

		return suite;
	}

	public static void main (String[] args)
	{
		junit.swingui.TestRunner.run(MatrizTest.class);
	}
}