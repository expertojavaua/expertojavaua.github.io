
public class MiVector
{
	// Array de enteros
	int[] elementos;
	
	// Constructor
	public MiVector(int[] elementos)
	{
		this.elementos = elementos;
	}
	
	// Devuelve el maximo entero del array
	public int maximo()
	{
		int solucion = 0;
		for (int i = 0; i < elementos.length; i++)
			if (solucion < elementos[i])
				solucion = elementos[i];
		return solucion;
	}
}