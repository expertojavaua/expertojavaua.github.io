import junit.framework.*;

public class MiVectorTest extends TestCase
{
	final static int[] VECTOR =  {9, 3, 5, 7, 1};

	public MiVectorTest(String nombre)
	{
		super(nombre);
	}

	public void testMaximo()
	{
		MiVector mv = new MiVector(VECTOR);

		assertTrue(mv.maximo() == 9);
	}

	public static void main (String[] args)
	{
		junit.swingui.TestRunner.run(MiVectorTest.class);
	}
}