package es.ua.jtech.jhd.sesion8.ejemplos.logging;

import org.apache.log4j.*;
import org.apache.log4j.xml.*;

public class LogXML 
{
	static Logger logger = Logger.getLogger(LogXML.class);
	
	public static void main(String[] args) 
	{
		DOMConfigurator.configure("ejemplo_log4j_xml.xml");
		logger.info("Iniciando el programa...");
		ClaseAuxiliar caux = new ClaseAuxiliar();
		logger.info("Obteniendo mensaje...");
		String mensaje = caux.mensaje();
		if (mensaje.equals(""))
			logger.warn("Mostrando mensaje vacio...");
		logger.info("Mensaje: " + mensaje);
	}
}
