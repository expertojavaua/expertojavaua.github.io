package es.ua.jtech.jhd.sesion8.ejercicios.logging;

import java.io.*;
import org.apache.log4j.*;

public class PruebaFichero
{
	static Logger logger = Logger.getLogger(PruebaFichero.class);	
	
	public static void main(String[] args)
	{
		BasicConfigurator.configure();
		String fichero = "fich_prueba.txt";
		
		try
		{
			// Mensaje: tomando fichero de entrada
			LeeFichero lf = new LeeFichero(fichero);
			
			// Mensaje: leyendo fichero
			String texto = lf.lee();
			
			// Mensaje: finalizado
			
		} catch (FileNotFoundException e1) {
	
			logger.error("Fichero '" + fichero + "' no encontrado");
			
		} catch (IOException e2) {
			
			logger.error("Error leyendo fichero '" + fichero + "'");
		}
	}
}