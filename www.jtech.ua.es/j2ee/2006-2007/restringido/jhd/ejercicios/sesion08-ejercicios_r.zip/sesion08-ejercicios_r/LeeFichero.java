import java.io.*;

public class LeeFichero
{
	BufferedReader r = null;
	
	public LeeFichero(String fichero) throws FileNotFoundException
	{
		// Mensaje: inicializando clase
		r = new BufferedReader(new FileReader(fichero));
	}
	
	public String lee() throws IOException
	{
		String result = "";
		String linea = "";
		
		// Mensaje: leyendo 5 primeras lineas
		for (int i = 0; i < 5; i++)
		{
			linea = r.readLine();
			if (linea == null)
				throw new IOException ("Error al leer el fichero");
			else
				result += linea;
		}
		
		// Mensaje: leyendo lineas restantes
		while ((linea = r.readLine()) != null)
		{
			result += linea;
		}
		
		// Mensaje: devolviendo el resultado
		return result;
	}
}