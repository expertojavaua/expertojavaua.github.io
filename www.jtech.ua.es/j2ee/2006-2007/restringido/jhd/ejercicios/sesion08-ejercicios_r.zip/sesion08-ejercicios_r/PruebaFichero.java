import java.io.*;
import org.apache.log4j.*;

public class PruebaFichero
{
	static Logger logger = Logger.getLogger(PruebaFichero.class);	
	
	public static void main(String[] args)
	{
		PropertyConfigurator.configure("logging.conf");
		
		try
		{
			// Mensaje: tomando fichero de entrada
			logger.debug("Tomando fichero de entrada");
			LeeFichero lf = new LeeFichero(args[0]);
			
			// Mensaje: leyendo fichero
			logger.debug("Leyendo fichero");
			String texto = lf.lee();
			
			// Mensaje: finalizado
			
		} catch (FileNotFoundException e1) {
	
			logger.error("Fichero '" + args[0] + "' no encontrado");
			
		} catch (IOException e2) {
			
			logger.error("Error leyendo fichero '" + args[0] + "'");
		}
	}
}