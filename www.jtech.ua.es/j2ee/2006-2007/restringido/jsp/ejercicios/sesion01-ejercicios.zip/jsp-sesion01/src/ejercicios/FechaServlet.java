package ejercicios;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class FechaServlet extends HttpServlet
{
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		// ...
	}
}