package ejercicios;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class FechaServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String fecha = "" + new java.util.Date();
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head><title>" + fecha + "</title></head>");
		out.println("<body><h3>" + fecha + "</h3></body>");
		out.println("</html>");
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);
	}
}