package ejercicios;
import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class ParamIniServlet extends HttpServlet
{	
	ServletConfig sc;

	public void init(ServletConfig s) throws ServletException
	{
		super.init(s);
		sc = s;
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String fecha = "" + new java.util.Date();
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<body><table border=\"1\">");

		java.util.Enumeration nombres = sc.getInitParameterNames();
		while (nombres.hasMoreElements())
		{
			String nombre = (String)(nombres.nextElement());
			String valor = sc.getInitParameter(nombre);
			out.println("<tr><td>" + nombre + "</td><td>" + valor + "</td></tr>");
		}
				
		out.println("</table></body>");
		out.println("</html>");
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);
	}
}