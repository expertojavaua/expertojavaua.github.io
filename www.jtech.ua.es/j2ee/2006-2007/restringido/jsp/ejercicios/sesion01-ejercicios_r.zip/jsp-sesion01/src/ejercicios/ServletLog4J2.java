package ejercicios;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import org.apache.commons.logging.*;

// Ejemplo de servlet que genera texto plano

public class ServletLog4J2 extends HttpServlet
{
	// Cargar el logger
	static Log logger = LogFactory.getLog(ServletLog4J2.class);
	
	// Metodo para procesar una peticion GET
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// Mensaje indicando que se esta atendiendo peticion en este servlet
		logger.info("Atendiendo peticion Servlet Log4J 2");
		PrintWriter out = response.getWriter();
		out.println ("Hola, este es un servlet sencillo de prueba para logging (2)");
		logger.info("Fin peticion Servlet Log4J 2");
	}
}