package ejercicios;
import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class DatosServlet2 extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		boolean error = false;

		java.util.Enumeration nombres = request.getParameterNames();
		while (nombres.hasMoreElements())
		{
			String nombre = (String)(nombres.nextElement());
			String valor = request.getParameter(nombre);
			if (valor.equals(""))
				error = true;
		}
		
		if (error)
			response.sendRedirect("../form_datos2.html");
		else
			response.sendRedirect("../index.html");				
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);
	}
}