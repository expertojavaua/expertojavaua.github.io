package ejercicios;

import org.apache.cactus.*;

public class DatosServlet2Test extends ServletTestCase
{
	public void beginPeticion(WebRequest theRequest)
	{
	    // Inicializa los par�metros HTTP relacionados
	    theRequest.setURL("localhost:8080", "/appforms", "/servlet/ejercicios.DatosServlet2",
	        null, "aaa=&bbb=1");
	}

	public void testPeticion()
	{
		boolean error = false;

		java.util.Enumeration nombres = request.getParameterNames();
		while (nombres.hasMoreElements())
		{
			String nombre = (String)(nombres.nextElement());
			String valor = request.getParameter(nombre);
			System.out.println("*****" + nombre + "=" + valor);
			if (valor.equals(""))
				error = true;
		}
		
		assertTrue(!error);
	}
}
