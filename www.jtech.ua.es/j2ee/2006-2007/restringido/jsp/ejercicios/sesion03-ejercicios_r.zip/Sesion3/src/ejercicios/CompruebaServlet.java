package ejercicios;
import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class CompruebaServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String nick = request.getParameter("nick");
		String passw = request.getParameter("password");
		String email = request.getParameter("email");
		
		if (nick.equals(""))
			response.sendRedirect("ejercicios.ErrorCompruebaServlet?error=falta+nick");
		else if (passw.equals(""))
			response.sendRedirect("ejercicios.ErrorCompruebaServlet?error=falta+password");
		else if (email.equals(""))
			response.sendRedirect("ejercicios.ErrorCompruebaServlet?error=falta+email");
		else
		{
			PrintWriter out = response.getWriter();
			out.println("Los datos son correctos");
		}
	}
}