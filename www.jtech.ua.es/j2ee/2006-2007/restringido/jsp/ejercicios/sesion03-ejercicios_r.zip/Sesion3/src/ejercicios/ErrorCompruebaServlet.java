package ejercicios;
import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class ErrorCompruebaServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.setHeader("Refresh", ("5;url=../form_datos.html"));
		PrintWriter out = response.getWriter();
		out.println("Error:" +  request.getParameter("error"));
	}
}