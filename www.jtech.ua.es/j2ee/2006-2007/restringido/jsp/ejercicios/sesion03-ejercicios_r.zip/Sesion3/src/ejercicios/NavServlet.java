package ejercicios;
import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class NavServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		boolean error = false;
		String nav = request.getHeader("User-Agent");
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		if (nav.indexOf("Netscape") == -1)
		{
			out.println("<img src=\"../kde_logo.gif\">");
		} else {			
			out.println("<img src=\"../netscape_logo.gif\">");
		}
		out.println("</body></html>");
	}
}