package ejercicios;

import java.io.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class CarroServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		HttpSession sesion = request.getSession();
		String articulo = request.getParameter("articulo");
		int precio = Integer.parseInt(request.getParameter("precio"));
		Vector carro = new Vector();

		if (sesion.isNew())
		{
			carro.addElement(new ObjetoCarro(articulo, precio));
			sesion.setAttribute("miCarro", carro);
		} else {
			carro = (Vector)(sesion.getAttribute("miCarro"));
			carro.addElement(new ObjetoCarro(articulo, precio));
			sesion.setAttribute("miCarro", carro);
		}
		
		PrintWriter out = response.getWriter();
		for (int i = 0; i < carro.size(); i++)
		{
			ObjetoCarro oc = (ObjetoCarro)(carro.elementAt(i));
			out.println("Articulo " + oc.getArticulo() + ", precio = " + oc.getPrecio());
		}
	}
}

class ObjetoCarro
{
	String articulo;
	int precio;

	public ObjetoCarro(String articulo, int precio)
	{
		this.articulo = articulo;
		this.precio = precio;
	}

	public String getArticulo()
	{
		return articulo;
	}

	public int getPrecio()
	{
		return precio;
	}
}
