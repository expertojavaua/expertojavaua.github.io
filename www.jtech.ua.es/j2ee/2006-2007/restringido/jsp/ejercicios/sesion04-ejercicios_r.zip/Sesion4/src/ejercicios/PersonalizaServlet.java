package ejercicios;
import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class PersonalizaServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String nombre = request.getParameter("nombre");
		String color = request.getParameter("color");
		
		Cookie c1 = new Cookie("nombre", nombre);
		Cookie c2 = new Cookie("color", color);
		
		response.addCookie(c1);
		response.addCookie(c2);
		
		response.sendRedirect("../form_pers.html");
	}
}