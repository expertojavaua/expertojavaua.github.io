package es.ua.jtech.jsp.sesion5.chat;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class ListaMensajesServlet extends HttpServlet {

	private static final long serialVersionUID = 427199619647569137L;

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		// TODO: A�adir cabecera para actualizar cada 5 segundos

		// TODO: Incluir /chat/cabecera.htmlf

		// TODO: Mostrar mensajes del chat

		// TODO: Incluir /chat/pie.htmlf
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doGet(req,res);
	}
}
