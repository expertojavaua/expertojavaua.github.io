package es.ua.jtech.jsp.sesion5.chat;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class EnviaMensajeServlet extends HttpServlet {

	private static final long serialVersionUID = -481257371131179080L;

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		ServletContext application = this.getServletContext();
		
		// Si no hay usuario, redireccionar a /chat/error.html
		String nick = (String)req.getSession().getAttribute("es.ua.jtech.jsp.sesion5.chat.nick");
		if(nick == null) {
			RequestDispatcher rd = application.getRequestDispatcher("/chat/error.html");
			rd.forward(req, res);
			return;
		}
		
		// Agregar mensaje enviado a la cola de mensajes
		ColaMensajes cm = (ColaMensajes)application.getAttribute("es.ua.jtech.jsp.sesion5.chat.mensajes");
		Mensaje msg = new Mensaje(nick, req.getParameter("texto"));
		cm.addMessage(msg);
		
		// Redireccionar a /chat/enviaMensaje.html
		RequestDispatcher rd = application.getRequestDispatcher("/chat/enviaMensaje.html");
		rd.forward(req, res);		
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doGet(req,res);
	}
}
