package es.ua.jtech.jsp.sesion5.chat;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class ListaMensajesServlet extends HttpServlet {

	private static final long serialVersionUID = 427199619647569137L;

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		ServletContext application = this.getServletContext();
		PrintWriter out = res.getWriter();
		
		// A�adir cabecera para actualizar cada 5 segundos
		res.addHeader("Refresh", "5");
		
		// Incluir /chat/cabecera.htmlf
		RequestDispatcher rdCab = application.getRequestDispatcher("/chat/cabecera.htmlf");
		rdCab.include(req, res);

		// Mostrar mensajes del chat
		String nick = (String)req.getSession().getAttribute("es.ua.jtech.jsp.sesion5.chat.nick");
		ColaMensajes cm = (ColaMensajes)application.getAttribute("es.ua.jtech.jsp.sesion5.chat.mensajes");
		for(Mensaje msg: cm) {
			if(msg.emisor.equals(nick)) {
				out.println("<strong>&lt;" + msg.emisor + "&gt;</strong> " + msg.texto + "<br/>");
			} else {
				out.println("&lt;" + msg.emisor + "&gt; " + msg.texto + "<br/>");				
			}
		}

		// Incluir /chat/pie.htmlf
		RequestDispatcher rdPie = application.getRequestDispatcher("/chat/pie.htmlf");
		rdPie.include(req, res);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doGet(req,res);
	}
}
