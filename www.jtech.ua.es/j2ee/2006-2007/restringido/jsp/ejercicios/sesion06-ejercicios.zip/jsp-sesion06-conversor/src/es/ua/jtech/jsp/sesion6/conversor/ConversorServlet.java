package es.ua.jtech.jsp.sesion6.conversor;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class for Servlet: ConversorServlet
 *
 */
 public class ConversorServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {

	private static final long serialVersionUID = 4704492786138452733L;

	public ConversorServlet() {
		super();
	}   	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
		out.println("<head><title>Resultado de la conversi�n</title></head>");
		out.println("<body>");
		
		try {
			float numero = Float.parseFloat(request.getParameter("numero"));
			int ptas = (int)Math.round(numero*166.386f);
			
			out.println("<h1>Resultado</h1>");
			out.println("<p>La cantidad equivalente a " + numero + " euros son <strong>" + ptas + "</strong> ptas.</p>");
		} catch(Exception e) {
			out.println("<h1>Error</h1>");			
			out.println("<p>Se ha producido un error durante la conversi�n: " + e.getMessage() + "</p>");			
		}
	}  	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}   	  	    
}