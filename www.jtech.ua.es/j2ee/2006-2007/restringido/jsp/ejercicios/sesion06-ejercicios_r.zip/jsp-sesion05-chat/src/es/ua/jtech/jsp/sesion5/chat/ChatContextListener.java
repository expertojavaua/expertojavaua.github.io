package es.ua.jtech.jsp.sesion5.chat;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class ChatContextListener implements ServletContextListener {

	public void contextDestroyed(ServletContextEvent sce) {
	}

	public void contextInitialized(ServletContextEvent sce) {
		ColaMensajes cm = new ColaMensajes();
		ServletContext application = sce.getServletContext();
		application.setAttribute("es.ua.jtech.jsp.sesion5.chat.mensajes", cm);
	}

}
