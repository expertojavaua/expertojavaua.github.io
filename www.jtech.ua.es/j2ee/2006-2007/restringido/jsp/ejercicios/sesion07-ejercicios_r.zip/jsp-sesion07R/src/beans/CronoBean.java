package beans;

public class CronoBean
{
	private long creacion;
	long segundos;
	
	public CronoBean()
	{
		creacion = System.currentTimeMillis();
	}
	
	public void setSegundos(long s)
	{
		segundos = s;
	}
	
	public long getSegundos()
	{
		segundos = (System.currentTimeMillis() - creacion) / 1000;
		return segundos;
	}
}