package es.ua.jtech.jsp.sesion10.libtags1;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

// Tag para formatear un double con N decimales

public class FormateaDoubleTag 
{
}