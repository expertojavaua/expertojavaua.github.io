package es.ua.jtech.jsp.sesion10.pruebatags;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

// Este tag repite el contenido de su cuerpo tantas veces como se le indique

public class Iterador extends BodyTagSupport
{
	private static final long serialVersionUID = -8242069699443916948L;

	private PageContext contexto;		// Contexto del tag
	private Tag padre; 					// Tag padre del actual
	int veces = 10;						// Numero de iteraciones
	int valorActual = 0;				// Valor actual del contador
	
	// Metodo llamado cuando se comienza el tag
	public int doStartTag() throws JspException 
	{ 
		if (valorActual >= veces)
			return SKIP_BODY;
		else
		{
			valorActual++;
			return EVAL_BODY_BUFFERED;
		}
	} 

	// Metodo llamado tras cada evaluacion del cuerpo del tag
	public int doAfterBody() throws JspException 
	{ 
		if (valorActual >= veces)
			return SKIP_BODY;
		else
		{
			valorActual++;
			return EVAL_BODY_BUFFERED;
		}
	} 
	
	// Metodo llamado cuando se termina el tag
	public int doEndTag() throws JspException 
	{
		try
		{ 
			if(bodyContent != null)
				bodyContent.writeOut(bodyContent.getEnclosingWriter()); 
		} catch(java.io.IOException e) { 
			throw new JspException("IO Error: " + e.getMessage()); 
		}		
		return EVAL_PAGE;
	} 
	
	// Establece el numero de iteraciones
	public void setVeces(int veces) 
	{
		this.veces = veces; 
	} 	
}