package es.ua.jtech.jsp.sesion10.libtags1;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.Tag;

public class CarActualTag implements Tag {

	private PageContext contexto; 	// Contexto del tag
	private Tag padre; 				// Tag padre del actual

	public int doEndTag() throws JspException {
		try {
			IteraCadenaTag miPadre = (IteraCadenaTag)getParent();
			
			if(miPadre==null)
				throw new JspException("Tag 'carActual' sin tag 'iteraCadena' padre");
			
			// Mostramos el saludo
			contexto.getOut().write(miPadre.getCarActual());
		} catch (java.io.IOException e) {
			throw new JspException("Error: " + e.getMessage());
		}
		return EVAL_PAGE;
	}

	public int doStartTag() throws JspException {
		return SKIP_BODY;
	}

	public Tag getParent() {
		return padre;
	}

	public void release() {
	}

	public void setPageContext(PageContext contexto) {
		this.contexto = contexto;
	}

	public void setParent(Tag padre) {
		this.padre = padre;
	}

}
