package es.ua.jtech.jsp.sesion10.libtags1;

import java.text.NumberFormat;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

// Tag para formatear un double con N decimales

public class FormateaDoubleTag implements Tag {

	private PageContext contexto; 	// Contexto del tag
	private Tag padre; 				// Tag padre del actual
	private double valor;
	private int decimales=0;

	public int doEndTag() throws JspException {
		try {
			NumberFormat nf = NumberFormat.getInstance();
			nf.setMaximumFractionDigits(decimales);
			nf.setMinimumFractionDigits(decimales);
			
			// Mostramos el saludo
			contexto.getOut().write(nf.format(valor));
		} catch (java.io.IOException e) {
			throw new JspException("Error: " + e.getMessage());
		}
		return EVAL_PAGE;
	}

	public int doStartTag() throws JspException {
		return SKIP_BODY;
	}

	public Tag getParent() {
		return padre;
	}

	public void release() {
	}

	public void setPageContext(PageContext contexto) {
		this.contexto = contexto;
	}

	public void setParent(Tag padre) {
		this.padre = padre;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public void setDecimales(int decimales) {
		this.decimales = decimales;
	}
}