package es.ua.jtech.jsp.sesion10.libtags1;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.BodyTagSupport;
import javax.servlet.jsp.tagext.Tag;

public class IteraCadenaTag extends BodyTagSupport {
	private static final long serialVersionUID = -8242069699443916948L;

	private PageContext contexto;		// Contexto del tag
	private Tag padre; 					// Tag padre del actual
	String cadena = "";					// Numero de iteraciones
	int valorActual = 0;				// Valor actual del contador
	
	// Metodo llamado cuando se comienza el tag
	public int doStartTag() throws JspException 
	{ 
		if (valorActual >= cadena.length())
			return SKIP_BODY;
		else
		{
			valorActual++;
			return EVAL_BODY_BUFFERED;
		}
	} 

	// Metodo llamado tras cada evaluacion del cuerpo del tag
	public int doAfterBody() throws JspException 
	{ 
		if (valorActual >= cadena.length())
			return SKIP_BODY;
		else
		{
			valorActual++;
			return EVAL_BODY_BUFFERED;
		}
	} 
	
	// Metodo llamado cuando se termina el tag
	public int doEndTag() throws JspException 
	{
		try
		{ 
			if(bodyContent != null)
				bodyContent.writeOut(bodyContent.getEnclosingWriter()); 
		} catch(java.io.IOException e) { 
			throw new JspException("IO Error: " + e.getMessage()); 
		}		
		return EVAL_PAGE;
	} 
	
	// Establece la cadena
	public void setCadena(String cadena) 
	{
		this.cadena = cadena; 
	} 	

	public char getCarActual() {
		return cadena.charAt(valorActual-1); 
	}
}
