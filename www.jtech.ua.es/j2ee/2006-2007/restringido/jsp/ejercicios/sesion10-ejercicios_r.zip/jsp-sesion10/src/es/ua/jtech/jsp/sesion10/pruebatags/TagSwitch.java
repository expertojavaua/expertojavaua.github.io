package es.ua.jtech.jsp.sesion10.pruebatags;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

// Este tag realiza un switch para un tag switch-case

public class TagSwitch implements Tag
{
	private PageContext contexto;		// Contexto del tag
	private Tag padre; 					// Tag padre del actual
	String valor;						// Valor para comparar con los case
	
	// Metodo llamado cuando se comienza el tag
	public int doStartTag() throws JspException 
	{ 
		return EVAL_BODY_INCLUDE; 
	} 
	
	// Metodo llamado cuando se termina el tag
	public int doEndTag() throws JspException 
	{
		return EVAL_PAGE;
	} 
	
	// Metodo de limpieza
	public void release() {}
	
	// Metodo para asignar el contexto
	public void setPageContext(final PageContext contexto) 
	{
		this.contexto = contexto; 
	} 
	
	// Metodo para asignar el tag padre
	public void setParent(final Tag padre) 
	{
		this.padre = padre;
	} 
	
	// Metodo para obtener el padre
	public Tag getParent() 
	{
		return padre;
	}
	
	// Obtiene el valor con que comparar con los case
	public String getValor()
	{
		return valor;
	}		

	// Establece el valor con que comparar con los case
	public void setValor(String valor)
	{
		this.valor = valor;
	}		
}