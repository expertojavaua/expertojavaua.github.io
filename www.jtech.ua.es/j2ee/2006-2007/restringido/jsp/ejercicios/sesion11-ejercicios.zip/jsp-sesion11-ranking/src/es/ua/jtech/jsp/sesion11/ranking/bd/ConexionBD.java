package es.ua.jtech.jsp.sesion11.ranking.bd;

import java.sql.*;

public class ConexionBD {

	Connection con;
	Statement stmt;

	public ConexionBD(String driver, String url, String login, String password)
		throws SQLException, ClassNotFoundException {
		Class.forName(driver);
		con = DriverManager.getConnection(url, login, password);
		stmt = con.createStatement();
	}

	public void executeUpdate(String upd) throws SQLException {
		stmt.executeUpdate(upd);
	}

	public ResultSet executeQuery(String query) throws SQLException {
		ResultSet rs = stmt.executeQuery(query);

		return rs;
	}

	public void close() throws SQLException {
		stmt.close();
		con.close();
	}
}
