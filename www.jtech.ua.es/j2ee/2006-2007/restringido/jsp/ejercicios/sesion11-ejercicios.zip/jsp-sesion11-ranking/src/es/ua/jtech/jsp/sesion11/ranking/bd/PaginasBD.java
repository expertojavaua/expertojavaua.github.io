package es.ua.jtech.jsp.sesion11.ranking.bd;

import java.sql.*;
import java.util.*;

public class PaginasBD extends ConexionBD {

	public PaginasBD(String driver, String url, String login, String password)
		throws SQLException, ClassNotFoundException {
		super(driver, url, login, password);
	}

	public synchronized boolean estaRegistrada(String url) {
		String query = "SELECT * FROM paginas WHERE ruta='" + url + "'";
		boolean result = false;

		try {
			ResultSet rs = executeQuery(query);
			result = rs.next();
		} catch (SQLException e) {
			return false;
		}

		return result;
	}

	public synchronized void registraPagina(String url, String titulo) {
		String query =
			"INSERT INTO paginas(ruta, titulo, accesos) values('"
				+ url
				+ "', '"
				+ titulo
				+ "', 1)";

		try {
			executeUpdate(query);
		} catch (SQLException e) {
		}
	}

	public synchronized void incrementaAccesos(String url) {
		String query =
			"UPDATE paginas SET accesos=accesos+1 WHERE ruta='" + url + "'";

		try {
			executeUpdate(query);
		} catch (SQLException e) {
		}
	}

	public synchronized ArrayList<Pagina> listaPaginas() {
		String query = "SELECT * FROM paginas ORDER BY accesos DESC";
		ArrayList<Pagina> lista = new ArrayList<Pagina>();

		String ruta, titulo;
		int accesos;
		Pagina pagina;

		try {
			ResultSet rs = executeQuery(query);

			while (rs.next()) {
				ruta = rs.getString("ruta");
				titulo = rs.getString("titulo");
				accesos = rs.getInt("accesos");

				pagina = new Pagina(ruta, titulo, accesos);
				lista.add(pagina);
			}
		} catch (SQLException e) {
			return null;
		}

		return lista;
	}
}
