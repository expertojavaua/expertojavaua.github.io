package es.ua.jtech.jsp.sesion11.ranking.filtro;

import java.io.*;
import javax.servlet.*;

public final class AccesoPaginaFilter implements Filter {

	private FilterConfig filterConfig = null;

	/**
	  *	Efectua el filtrado de una peticin.
	  * @param request Peticin realizada al servidor
	  * @param response Respuesta para enviar al cliente
	  * @param chain Cadena de filtros para procesar la peticin
	  */

	public void doFilter(
		ServletRequest request,
		ServletResponse response,
		FilterChain chain)
		throws IOException, ServletException {

		// TODO: Si la pagina solicitada esta registrada, incrementa el numero de accesos

		// TODO: Si no, registra la pagina (ruta, titulo) en la base de datos
	}

	/**
	  * Destruye el filtro. Cierra conexin a base de datos
	  */

	public void destroy() {
		this.filterConfig = null;

		// TODO: Cerrar conexion con base de datos
	}

	/**
	  * Inicializa el filtro. Abre conexi�n a BD y lee par�metros.
	  * @param filterConfig Configuraci�n del filtro y de la aplicaci�n.
	  */

	public void init(FilterConfig filterConfig) throws ServletException {
		this.filterConfig = filterConfig;

		// TODO: Abrir conexion con base de datos
	}

}
