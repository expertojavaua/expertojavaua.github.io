package es.ua.jtech.jsp.sesion11.wrapper.filtro;

import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.ua.jtech.jsp.sesion11.wrapper.parse.AnalisisHTML;
import es.ua.jtech.jsp.sesion11.wrapper.wrapper.GenericResponseWrapper;

public final class RegistrarAccesosFilter implements Filter {

	private FilterConfig filterConfig = null;

	/**
	  *	Efectua el filtrado de una petici�n.
	  * @param request Petici�n realizada al servidor
	  * @param response Respuesta para enviar al cliente
	  * @param chain Cadena de filtros para procesar la petici�n
	  */

	public void doFilter(
		ServletRequest request,
		ServletResponse response,
		FilterChain chain)
		throws IOException, ServletException {

		HttpServletRequest http_request = null;
		HttpServletResponse http_response = null;

		if (request instanceof HttpServletRequest) {
			http_request = (HttpServletRequest) request;
		}

		if (response instanceof HttpServletResponse) {
			http_response = (HttpServletResponse) response;
		}

		// Tratamos solo peticiones HTTP

		if (http_request != null && http_response != null) {

			// Creamos un wrapper

			GenericResponseWrapper responseWrapper =
				new GenericResponseWrapper(http_response);

			// Solicitamos la URL al servidor

			chain.doFilter(http_request, responseWrapper);

			// Procesamos los datos generados

			byte[] datos = responseWrapper.getData();

			String responseString = new String(datos);

			AnalisisHTML parser = new AnalisisHTML();

			parser.parse(responseString.toCharArray());

			ServletContext sc = filterConfig.getServletContext();

			sc.log("Ha accedido a la pagina " + parser.getTitulo());

			// Devolvemos el contenido al cliente

			OutputStream out = http_response.getOutputStream();
			out.write(datos);
			out.close();

		} else {
			chain.doFilter(request, response);
		}

	}

	/**
	  * Destruye el filtro. Cierra conexi�n a base de datos
	  */
	public void destroy() {
		this.filterConfig = null;
	}

	/** 
	  * Inicializa el filtro. Abre conexi�n a BD y lee par�metros.
	  * @param filterConfig Configuraci�n del filtro y de la aplicaci�n.
	  */
	public void init(FilterConfig filterConfig) throws ServletException {
		this.filterConfig = filterConfig;
	}

}
