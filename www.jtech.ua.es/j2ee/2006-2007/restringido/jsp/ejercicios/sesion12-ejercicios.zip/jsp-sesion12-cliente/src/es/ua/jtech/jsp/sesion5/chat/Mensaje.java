package es.ua.jtech.jsp.sesion5.chat;

import java.io.Serializable;

public class Mensaje implements Serializable {
	
	private static final long serialVersionUID = 5261283062848807646L;

	public String emisor;
	public String texto;

	public Mensaje(String emisor, String texto) {
		this.emisor = emisor;
		this.texto = texto;
	}
}
