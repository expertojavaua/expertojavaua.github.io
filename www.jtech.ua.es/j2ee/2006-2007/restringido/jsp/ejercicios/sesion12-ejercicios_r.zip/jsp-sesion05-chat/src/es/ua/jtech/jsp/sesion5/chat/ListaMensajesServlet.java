package es.ua.jtech.jsp.sesion5.chat;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class ListaMensajesServlet extends HttpServlet {

	private static final long serialVersionUID = 427199619647569137L;

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{		
		ServletContext application = this.getServletContext();
		ColaMensajes cm = (ColaMensajes)application.getAttribute("es.ua.jtech.jsp.sesion5.chat.mensajes");

		String formato = req.getParameter("formato");
		
		if(formato==null || formato.equals("0")) {
			req.setAttribute("es.ua.jtech.jsp.sesion6.chat.mensajes", cm);
			RequestDispatcher rd = application.getRequestDispatcher("/jsp/listaMensajes.jsp");
			rd.forward(req, res);
			
		} else if(formato.equals("1")) {
			req.setAttribute("es.ua.jtech.jsp.sesion6.chat.mensajes", cm);
			RequestDispatcher rd = application.getRequestDispatcher("/jsp/listaMensajesXml.jsp");
			rd.forward(req, res);
			
		} else if(formato.equals("2")) {
			res.setContentType("application/x-java-serialized-object");
			ObjectOutputStream oos = new ObjectOutputStream(res.getOutputStream());
			oos.writeObject(cm);
			oos.flush();
			oos.close();
			
		} else {
			req.setAttribute("es.ua.jtech.jsp.sesion5.chat.error", "Tipo de formato no valido: " + formato);
			RequestDispatcher rd = application.getRequestDispatcher("/jsp/error.jsp");
			rd.forward(req, res);			
		}

	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doGet(req,res);
	}
}
