package es.ua.jtech.jsp.sesion5.chat;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class LoginUsuarioServlet extends HttpServlet {

	private static final long serialVersionUID = -702692997050321714L;

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		HttpSession session = req.getSession();
		ServletContext sc = getServletContext();

		String nick = req.getParameter("nick");
		
		if(nick!=null) {
			session.setAttribute("es.ua.jtech.jsp.sesion5.chat.nick", nick);
			res.setHeader("url-enviar", res.encodeURL("http://localhost:8080" + req.getContextPath() + "/servlet/EnviaMensajeServlet"));

			try {
				RequestDispatcher rd = getServletConfig().getServletContext().getRequestDispatcher("/chat/chatAjax.html");
				rd.forward(req, res);
			} catch(Exception e) {
				e.printStackTrace();
			}
		} else {
			RequestDispatcher rd = sc.getRequestDispatcher("/index.html");
			rd.forward(req, res);
		}

	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doGet(req,res);
	}
}
