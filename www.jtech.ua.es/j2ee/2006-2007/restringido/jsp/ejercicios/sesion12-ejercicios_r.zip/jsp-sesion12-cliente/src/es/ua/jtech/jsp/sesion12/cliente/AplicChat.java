package es.ua.jtech.jsp.sesion12.cliente;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ListIterator;

import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import es.ua.jtech.jsp.sesion5.chat.ColaMensajes;
import es.ua.jtech.jsp.sesion5.chat.Mensaje;

/**
  * Aplicacion para chat con servlets
  */
public class AplicChat extends JApplet implements Runnable
{
	private static final long serialVersionUID = -3548422347618814103L;
	
	// Constantes para el acceso a las URLs de la aplicacion

	public final static String PROTOCOL = "http";
	public final static String HOST = "localhost";
	public final static int PORT = 8080;
	public final static String FILE_LOGIN = "/jsp-sesion05-chat/servlet/LoginUsuarioServlet";
	public final static String FILE_SEND = "/jsp-sesion05-chat/servlet/EnviaMensajeServlet";
	public final static String FILE_LIST = "/jsp-sesion05-chat/servlet/ListaMensajesServlet?formato=2";

	// Retardo para leer los mensajes del chat

	public final static int DELAY = 5000;

	/**
	  * Puntero al frame (para el hilo)
	  */
	AplicChat frame = this;

	/**
	  * Texto a enviar al chat
	  */
	TextField txtMensaje;

	/**
	  * Buffer de mensajes del chat
	  */
	JTextArea txtBuffer;

	/**
	  * Hilo para recibir mensajes del servidor
	  */
	Thread t;

	/**
	 * URL reescrita para enviar mensajes
	 */
	String urlEnviar;
	
	/**
	  * Metodo para inicializar los componentes
	  */
	public void init()
	{
		getContentPane().setLayout(new BorderLayout());

		/******** Panel central con el buffer del chat *********/

		txtBuffer = new JTextArea("", 10, 450);
		txtBuffer.setEditable(false);
		txtBuffer.setAutoscrolls(true);
		JScrollPane scrllBuffer = new JScrollPane(txtBuffer);

		getContentPane().add(scrllBuffer, BorderLayout.CENTER);


		/******** Panel inferior para enviar mensajes al chat *********/

		JPanel panelInf = new JPanel();
		panelInf.setLayout(new GridLayout(2, 1));

		txtMensaje = new TextField();
		panelInf.add(txtMensaje);

		JButton btnEnviar = new JButton("Enviar");
		btnEnviar.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try {
					envia(txtMensaje.getText());
					txtMensaje.setText("");
				} catch(IOException e1) {
					System.err.println("Error enviando mensaje: " + e1.getMessage());
				}
			}
		});
		panelInf.add(btnEnviar);

		getContentPane().add(panelInf, BorderLayout.SOUTH);
	}

	public void start() {
		t = new Thread(this);
		t.start();
	}

	public void stop() {
		t = null;
	}

	/**
	  * Funcion principal del hilo
	  */
	public void run()
	{
		// Recibe los mensajes del servidor

		while(t==Thread.currentThread()) {
			try {
				Thread.sleep(DELAY);

				txtBuffer.setText(recibe());
				txtBuffer.setCaretPosition(txtBuffer.getDocument().getLength());
			} catch(InterruptedException e1) {
			} catch(IOException e2) {
				System.err.println("Error leyendo mensajes: " + e2.getMessage());
			}

		}
	}

	public String recibe() throws IOException {
		// Recibe lista de mensajes del chat

		URL url = new URL(PROTOCOL, HOST, PORT, FILE_LIST);

		// Lee el objeto (ColaMensajes) devuelto por el servlet

		ObjectInputStream ois = new ObjectInputStream(url.openStream());

		ColaMensajes cm = null;
		try {
			cm = (ColaMensajes)ois.readObject();
		} catch(ClassNotFoundException e) {
			System.err.println("No se encuentran las clases necesarias");
			return "";
		}

		// Itera por los mensajes de la cola y formatea la salida

		ListIterator li = cm.listIterator();

		Mensaje msg;
		String buffer = "";

		while(li.hasNext()) {
			msg = (Mensaje)li.next();

			buffer += "<" + msg.emisor + "> " + msg.texto + "\n";
		}

		return buffer;
	}

	public void envia(String mensaje) throws IOException {
		// Envia un mensaje al chat
		URL url = new URL(urlEnviar + "?texto=" + URLEncoder.encode(mensaje, "UTF-8"));
		url.openStream().close();
	}

	public void login(String nick) throws IOException {
		// Inicia una sesi�n en el servidor 
		URL urlLogin = new URL(PROTOCOL, HOST, PORT, FILE_LOGIN + "?nick=" + URLEncoder.encode(nick,"UTF-8") );
		URLConnection conLogin = urlLogin.openConnection();
		urlEnviar = conLogin.getHeaderField("url-enviar");
	}

	/**
	  * Main
	  */
	public static void main (String[] args)
	{
		String nick = JOptionPane.showInputDialog("Introduzca el nick", "");		
		if(nick==null) {
			System.exit(-1);
		}
		
		AplicChat ac = new AplicChat();
		ac.init();
		ac.start();

		try {
			ac.login(nick);
		} catch (IOException e1) {
			e1.printStackTrace();
			System.exit(-1);
		}
		
		JFrame frm = new JFrame();
		frm.setTitle("Chat");
		frm.setSize(400, 300);
		frm.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});

		frm.getContentPane().add(ac, BorderLayout.CENTER);

		frm.setVisible(true);
	}

}
