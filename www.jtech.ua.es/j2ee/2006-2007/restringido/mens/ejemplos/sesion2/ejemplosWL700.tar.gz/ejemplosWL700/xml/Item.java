package examples.jms.xml; 

public class Item {

  String id; 
  String name; 
  String price; 

}
