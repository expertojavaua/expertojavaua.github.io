package es.ua.jtech.servcweb.sesion1.hola;

import es.ua.jtech.servcweb.sesion1.hola.stub.HolaMundoSW;
import es.ua.jtech.servcweb.sesion1.hola.stub.HolaMundoSWService;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HolaMundoSWService service = new HolaMundoSWService();
		HolaMundoSW port = service.getHolaMundoSW();
		
		System.out.println("Resultado: " + port.saluda("Miguel"));
		
	}

}
