@javax.xml.bind.annotation.XmlSchema(namespace = "http://sw.hola.servcweb.jtech.ua.es")
package es.ua.jtech.servcweb.sesion1.hola.stub;
