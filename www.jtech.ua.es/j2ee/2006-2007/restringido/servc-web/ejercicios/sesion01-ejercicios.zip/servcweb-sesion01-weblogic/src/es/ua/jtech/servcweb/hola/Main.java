package es.ua.jtech.servcweb.hola;

import es.ua.jtech.servcweb.hola.stub.HolaMundoSW;
import es.ua.jtech.servcweb.hola.stub.HolaMundoSWService;
import es.ua.jtech.servcweb.hola.stub.HolaMundoSWService_Impl;

public class Main {

	public static void main(String[] args) throws Exception {
		HolaMundoSWService service = new HolaMundoSWService_Impl();
		HolaMundoSW port = service.getHolaMundoSW();
		
		System.out.println("Resultado: " + port.saluda("Miguel"));
	}

}
