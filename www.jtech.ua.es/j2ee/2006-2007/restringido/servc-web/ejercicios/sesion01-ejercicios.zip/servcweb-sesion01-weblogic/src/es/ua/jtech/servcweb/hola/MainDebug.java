package es.ua.jtech.servcweb.hola;

import java.util.List;

import javax.xml.namespace.QName;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.HandlerRegistry;

import es.ua.jtech.servcweb.hola.stub.HolaMundoSW;
import es.ua.jtech.servcweb.hola.stub.HolaMundoSWService;
import es.ua.jtech.servcweb.hola.stub.HolaMundoSWService_Impl;

public class MainDebug {

	public static void main(String[] args) throws Exception {
		HolaMundoSWService service = new HolaMundoSWService_Impl();

		// Registra handler
		HandlerRegistry hr = service.getHandlerRegistry();
		List chain = hr.getHandlerChain(new QName(
				"http://sw.hola.servcweb.jtech.ua.es", "HolaMundoSW"));
		HandlerInfo hi = new HandlerInfo(
				es.ua.jtech.servcweb.hola.handler.HandlerEspia.class, null,
				null);
		chain.add(hi);

		HolaMundoSW port = service.getHolaMundoSW();

		System.out.println("Resultado: " + port.saluda("Miguel"));
	}

}
