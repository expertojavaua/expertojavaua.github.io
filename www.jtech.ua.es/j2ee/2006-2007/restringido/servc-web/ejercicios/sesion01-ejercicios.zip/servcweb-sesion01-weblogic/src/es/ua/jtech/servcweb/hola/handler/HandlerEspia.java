
package es.ua.jtech.servcweb.hola.handler;

import java.io.*;
import javax.xml.soap.*;
import javax.xml.rpc.handler.*;
import javax.xml.rpc.handler.soap.*;
import javax.xml.namespace.QName;

public class HandlerEspia implements Handler {
    private HandlerInfo handlerInfo;
    
    public void init(HandlerInfo hi) {
        handlerInfo = hi;
    }
    
    public void destroy() {}
    
    public QName[] getHeaders() {
        return handlerInfo.getHeaders();
    }
    
    public boolean handleRequest(MessageContext context) {
        System.out.println("PETICION :");
        
        try {
            SOAPMessageContext smc = (SOAPMessageContext)context;
            SOAPMessage msg = smc.getMessage();
            
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            msg.writeTo(baos);
            System.out.println(baos.toString());
        } catch(Exception ex) {
        }
        
        return true;
    }
    
    public boolean handleResponse(MessageContext context) {
        System.out.println("RESPUESTA :");
        
        try {
            SOAPMessageContext smc = (SOAPMessageContext)context;
            SOAPMessage msg = smc.getMessage();
            
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            msg.writeTo(baos);
            System.out.println(baos.toString());
        } catch(Exception ex) {
        }
        
        return true;
    }
    
    public boolean handleFault(MessageContext context) {
        return true;
    }
    
}
