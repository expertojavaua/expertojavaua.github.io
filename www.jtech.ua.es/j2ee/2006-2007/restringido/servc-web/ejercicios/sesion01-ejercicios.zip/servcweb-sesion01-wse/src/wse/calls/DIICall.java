/*
 * DIICall.java, Invoke web services with DII
 * Copyright (C) 2003 DCCIA
 *
 * This file is part of Web Services Explorer.
 *
 * Web Services Explorer is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Web Services Explorer is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with Web Services Explorer; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package wse.calls;

import java.net.URL;
import java.util.*;
import javax.xml.rpc.ServiceFactory;
import javax.xml.rpc.Service;
import javax.xml.rpc.Call;
import javax.xml.rpc.encoding.TypeMapping;
import javax.xml.rpc.encoding.TypeMappingRegistry;
import javax.xml.rpc.handler.*;
import javax.xml.soap.SOAPConstants;
import javax.xml.namespace.QName;

public class DIICall {

	public static Object call(
		URL wsdl,
		QName serviceName,
		QName portName,
		QName opName,
		QName resultName,
		Object[] params)
		throws Exception {
		System.setProperty(
			"javax.xml.soap.MessageFactory",
			"weblogic.webservice.core.soap.MessageFactoryImpl");
		System.setProperty(
			"javax.xml.rpc.ServiceFactory",
			"weblogic.webservice.core.rpc.ServiceFactoryImpl");

		ServiceFactory factory = ServiceFactory.newInstance();

		Service srv = factory.createService(wsdl, serviceName);

		// Registra serializadores y deserializadores
		TypeMappingRegistry registry = srv.getTypeMappingRegistry();

		TypeMapping mapping =
			registry.getTypeMapping(SOAPConstants.URI_NS_SOAP_ENCODING);

		if(resultName!=null) {
			mapping.register(
				javax.xml.soap.SOAPElement.class,
				resultName,
				new GenericCodec(),
				new GenericCodec());
		}

		// Registra handlers
		HandlerRegistry hr = srv.getHandlerRegistry();
		List chain = hr.getHandlerChain(portName);
		HandlerInfo hi =
			new HandlerInfo(wse.calls.SpyHandler.class, null, null);
		chain.add(hi);

		// Invoca el servicio
		Call call = srv.createCall(portName, opName);
		Object result = call.invoke(params);

		return result;
	}
}
