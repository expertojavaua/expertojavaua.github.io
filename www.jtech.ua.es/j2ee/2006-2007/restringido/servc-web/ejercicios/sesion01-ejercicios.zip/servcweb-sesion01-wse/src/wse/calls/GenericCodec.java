/*
 * Created on 19/04/2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package wse.calls;

import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.encoding.Deserializer;
import javax.xml.rpc.encoding.Serializer;

import weblogic.xml.schema.binding.DeserializationContext;
import weblogic.xml.schema.binding.DeserializationException;
import weblogic.xml.schema.binding.JAXRPCCodecBase;
import weblogic.xml.schema.binding.SerializationContext;
import weblogic.xml.schema.binding.SerializationException;
import weblogic.xml.stream.Attribute;
import weblogic.xml.stream.CharacterData;
import weblogic.xml.stream.XMLEvent;
import weblogic.xml.stream.XMLInputStream;
import weblogic.xml.stream.XMLName;
import weblogic.xml.stream.XMLOutputStream;
import weblogic.xml.stream.XMLStreamException;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class GenericCodec extends JAXRPCCodecBase {

	/* (non-Javadoc)
	 * @see weblogic.xml.schema.binding.Deserializer#deserialize(weblogic.xml.stream.XMLName, weblogic.xml.stream.Attribute, weblogic.xml.schema.binding.DeserializationContext)
	 */
	public Object deserialize(
		XMLName arg0,
		Attribute arg1,
		DeserializationContext arg2)
		throws DeserializationException {

		return "No implementado";
	}

	/* (non-Javadoc)
	 * @see weblogic.xml.schema.binding.Deserializer#deserialize(weblogic.xml.stream.XMLName, weblogic.xml.stream.XMLInputStream, weblogic.xml.schema.binding.DeserializationContext)
	 */
	public Object deserialize(
		XMLName xmlName,
		XMLInputStream xis,
		DeserializationContext dc)
		throws DeserializationException {

		String s = "";
		int nItem = 1;

		try {
				XMLEvent event = null;
				while((event=xis.next())!=null) {

					if(event.isStartElement()) {
						String name = event.getName().getLocalName(); 
						if(name.equals("result")) {
						} else if(name.equals("item")) {
							s += "*** Item " + nItem + " ***\n";
							nItem++;
						} else {
							s += "[" + name + "] ";
						}
					}
					if(event instanceof CharacterData) {
						CharacterData cdata = (CharacterData) event;
						s += cdata.getContent() + "\n";
					}
					
				}
		} catch (XMLStreamException xse) {
			throw new DeserializationException("stream error", xse);
		}

		return s;
	}

	/* (non-Javadoc)
	 * @see weblogic.xml.schema.binding.Serializer#serialize(java.lang.Object, weblogic.xml.stream.XMLName, weblogic.xml.stream.XMLOutputStream, weblogic.xml.schema.binding.SerializationContext)
	 */
	public void serialize(
		Object arg0,
		XMLName arg1,
		XMLOutputStream arg2,
		SerializationContext arg3)
		throws SerializationException {

		System.out.println("Llamando a serialize (no hace nada)");

	}

	/* (non-Javadoc)
	 * @see javax.xml.rpc.encoding.SerializerFactory#getSerializerAs(java.lang.String)
	 */
	public Serializer getSerializerAs(String arg0) throws JAXRPCException {
		return super.getSerializerAs(arg0);
	}

	/* (non-Javadoc)
	 * @see javax.xml.rpc.encoding.DeserializerFactory#getDeserializerAs(java.lang.String)
	 */
	public Deserializer getDeserializerAs(String arg0) throws JAXRPCException {
		return super.getDeserializerAs(arg0);
	}

}
