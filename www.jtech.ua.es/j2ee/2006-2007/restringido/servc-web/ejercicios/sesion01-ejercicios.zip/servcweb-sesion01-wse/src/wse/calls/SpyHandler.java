/*
 * SpyHandler.java, Catches SOAP request and response messages
 * Copyright (C) 2003 DCCIA
 *
 * This file is part of Web Services Explorer.
 *
 * Web Services Explorer is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Web Services Explorer is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with Web Services Explorer; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


package wse.calls;

import java.io.*;
import javax.xml.soap.*;
import javax.xml.rpc.handler.*;
import javax.xml.rpc.handler.soap.*;
import javax.xml.namespace.QName;

public class SpyHandler implements Handler
{
	private static String request="";
	private static String response="";

	private HandlerInfo handlerInfo;

	public void init(HandlerInfo hi) {
		handlerInfo = hi;
	}

	public void destroy() {}

	public QName[] getHeaders() {
		return handlerInfo.getHeaders();
	}

	public boolean handleRequest(MessageContext context) {

		try {
			SOAPMessageContext smc = (SOAPMessageContext)context;
			SOAPMessage msg = smc.getMessage();

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			msg.writeTo(baos);
			request = baos.toString();
		}
		catch(Exception ex) {
			// throw exception
		}

		return true;
	}

	public boolean handleResponse(MessageContext context) {

		try {
			SOAPMessageContext smc = (SOAPMessageContext)context;
			SOAPMessage msg = smc.getMessage();

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			msg.writeTo(baos);
			response = baos.toString();
		}
		catch(Exception ex) {
			// throw exception
		}

		return true;
	}

	public boolean handleFault(MessageContext context) {
		return true;
	}

	public static String getRequest() {
		return request;
	}
	
	public static String getResponse() {
		return response;
	}
}
