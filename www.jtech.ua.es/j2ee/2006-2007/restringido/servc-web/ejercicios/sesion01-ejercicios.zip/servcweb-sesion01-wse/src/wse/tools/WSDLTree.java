/*
 * WSDLTree.java, Analyzes WSDL and returns a tree of elements
 * Copyright (C) 2003 DCCIA
 *
 * This file is part of Web Services Explorer.
 *
 * Web Services Explorer is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Web Services Explorer is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with Web Services Explorer; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package wse.tools;

import java.util.*;
import javax.swing.tree.*;
import javax.wsdl.*;
import javax.wsdl.xml.*;
import javax.wsdl.factory.*;
import javax.wsdl.extensions.soap.*;
import wse.tools.wsdl.*;

public class WSDLTree 
{

	public static void creaNodos(String wsdl, DefaultMutableTreeNode root) {

		DefaultMutableTreeNode port_node;
		DefaultMutableTreeNode op_node;
		DefaultMutableTreeNode srv_node;

		WSDLService wsdl_srv;
		WSDLPort wsdl_port;
		WSDLPortType wsdl_type;
		WSDLOperation wsdl_op;

	     try {

		// Get WSDLReader
		WSDLReader in = WSDLFactory.newInstance().newWSDLReader();

		// Read WSDL service implementation document
		Definition def = in.readWSDL(wsdl);

		// Get the service elements
		Map srvs = def.getServices();
		Iterator srvIter = srvs.values().iterator();

		while (srvIter.hasNext()) {
		  Service srv = (Service) srvIter.next();

		  wsdl_srv = new WSDLService(def, srv);
		  srv_node = new DefaultMutableTreeNode(wsdl_srv);
		  root.add(srv_node);

		  // Get the port elements
		  Map ports = srv.getPorts();
		  Iterator portIter = ports.values().iterator();

		  while (portIter.hasNext()) {
		    Port port = (Port) portIter.next();
		  
		    wsdl_port = new WSDLPort(wsdl_srv, port);

		    Binding bind = port.getBinding();
		    PortType type = bind.getPortType();

		    wsdl_type = new WSDLPortType(wsdl_port, type);
		    port_node = new DefaultMutableTreeNode(wsdl_type);
		    srv_node.add(port_node);

		    // Get operations
		    java.util.List bops = bind.getBindingOperations();
		    Iterator bopIter = bops.iterator();

		    while(bopIter.hasNext()) {
			BindingOperation bop = (BindingOperation)bopIter.next();
			Operation op = bop.getOperation();

			// Obtiene el namespace de la operacion
			java.util.List exts = bop.getBindingInput().getExtensibilityElements();
			Iterator extIter = exts.iterator();
			String namespace = wsdl_srv.getTargetNamespace();
			while(extIter.hasNext()) {
				Object obj = extIter.next();
				if(obj instanceof SOAPBody) {
					namespace = ((SOAPBody)obj).getNamespaceURI();
				}
			}

			wsdl_op = new WSDLOperation(wsdl_type, op, namespace);
		        op_node = new DefaultMutableTreeNode(wsdl_op);
		        port_node.add(op_node);
		    }
		  }
		}
	    } catch(Exception e) { e.printStackTrace(); }

	}

	public static WSDLParameter [] expandOperation(WSDLOperation op) {
		ArrayList list = new ArrayList();

		Input input = op.getOperation().getInput();
		Message mess = input.getMessage();

		Iterator partIter = mess.getOrderedParts(null).iterator();
		while(partIter.hasNext()) {
			Part part = (Part)partIter.next();

			list.add(new WSDLParameter(op,part));
		}

		WSDLParameter [] result = new WSDLParameter[list.size()];
		list.toArray(result);

		return result;
	}

	public static WSDLParameter [] expandOperationResult(WSDLOperation op) {
		ArrayList list = new ArrayList();

		Output output = op.getOperation().getOutput();
		Message mess = output.getMessage();

		Iterator partIter = mess.getOrderedParts(null).iterator();
		while(partIter.hasNext()) {
			Part part = (Part)partIter.next();
			list.add(new WSDLParameter(op,part));
		}

		WSDLParameter [] result = new WSDLParameter[list.size()];
		list.toArray(result);

		return result;
	}
}
