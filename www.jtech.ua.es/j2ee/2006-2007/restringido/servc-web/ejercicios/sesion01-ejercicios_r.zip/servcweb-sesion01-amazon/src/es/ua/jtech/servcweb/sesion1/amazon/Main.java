/*
 * Main.java
 *
 * Created on 25 de mayo de 2007, 19:07
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package es.ua.jtech.servcweb.sesion1.amazon;

import java.util.List;
import javax.xml.ws.Holder;

import es.ua.jtech.servcweb.sesion1.amazon.stub.*;


/**
 *
 * @author EPS
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try { // Call Web Service Operation
            es.ua.jtech.servcweb.sesion1.amazon.stub.AWSECommerceService service = new es.ua.jtech.servcweb.sesion1.amazon.stub.AWSECommerceService();
            es.ua.jtech.servcweb.sesion1.amazon.stub.AWSECommerceServicePortType port = service.getAWSECommerceServicePort();
            // TODO initialize WS operation arguments here
            String marketplaceDomain = null;
            String awsAccessKeyId = "15JCR9XWMPTGV91JC1R2";
            String subscriptionId = null;
            String associateTag = null;
            String xmlEscaping = null;
            String validate = null;
            ItemSearchRequest shared = null;
            List<ItemSearchRequest> request = null;
            Holder<OperationRequest> operationRequest = null;
            Holder<List<Items>> items = new Holder<List<Items>>();
            
            shared = new ItemSearchRequest();
            shared.setSearchIndex("DVD");
            shared.setDirector("Kubrick");
            shared.getResponseGroup().add("Offers");
            shared.getResponseGroup().add("Medium");
            
            port.itemSearch(marketplaceDomain, awsAccessKeyId,
                    subscriptionId, associateTag, xmlEscaping,
                    validate, shared, request, operationRequest, items);
            
            List<Items> listaResultados = items.value;
            for(Items resultado: listaResultados) {
                List<Item> listaArticulos = resultado.getItem();
                for(Item articulo: listaArticulos) {
                    ItemAttributes atributos = articulo.getItemAttributes();
                    System.out.println("Titulo: " + atributos.getTitle());
                    
                    List<String> directores = atributos.getDirector();
                    for(String director: directores) {
                        System.out.print(director + "; ");
                    }
                    
                    System.out.println("Precio: " +
                            (atributos.getListPrice()!=null?
                                atributos.getListPrice().getFormattedPrice():
                                "no disponible"));
                }
            }        } catch (Exception ex) {
                // TODO handle custom exceptions here
            }
        // TODO code application logic here
        
    }
    
}
