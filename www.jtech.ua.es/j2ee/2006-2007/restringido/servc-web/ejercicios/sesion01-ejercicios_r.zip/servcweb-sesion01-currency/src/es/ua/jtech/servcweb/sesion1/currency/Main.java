/*
 * Main.java
 *
 * Created on 25 de mayo de 2007, 19:00
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package es.ua.jtech.servcweb.sesion1.currency;

/**
 *
 * @author EPS
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try { // This code block invokes the CurrencyExchangePort:getRate operation on web service
            es.ua.jtech.servcweb.sesion1.currency.stub.CurrencyExchangeService currencyExchangeService = new es.ua.jtech.servcweb.sesion1.currency.stub.CurrencyExchangeService_Impl();
            es.ua.jtech.servcweb.sesion1.currency.stub.CurrencyExchangePortType currencyExchangePort = currencyExchangeService.getCurrencyExchangePort();
            float cambio = currencyExchangePort.getRate("usa", "euro");
            System.out.println("Cambio: " + cambio);
        } catch(javax.xml.rpc.ServiceException ex) {
            // TODO handle ServiceException
        } catch(java.rmi.RemoteException ex) {
            // TODO handle remote exception
        } catch(Exception ex) {
            // TODO handle custom exceptions here
        }

        // TODO code application logic here
        
    }
    
}
