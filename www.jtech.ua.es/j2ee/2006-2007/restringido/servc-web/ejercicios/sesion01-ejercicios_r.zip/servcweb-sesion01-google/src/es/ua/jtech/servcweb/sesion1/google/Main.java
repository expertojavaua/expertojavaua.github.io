/*
 * Main.java
 *
 * Created on 25 de mayo de 2007, 19:03
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package es.ua.jtech.servcweb.sesion1.google;

import es.ua.jtech.servcweb.sesion1.google.stub.GoogleSearchResult;
import es.ua.jtech.servcweb.sesion1.google.stub.ResultElement;

/**
 *
 * @author EPS
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try { // This code block invokes the GoogleSearchPort:doGoogleSearch operation on web service
            es.ua.jtech.servcweb.sesion1.google.stub.GoogleSearchService googleSearchService = new es.ua.jtech.servcweb.sesion1.google.stub.GoogleSearchService_Impl();
            es.ua.jtech.servcweb.sesion1.google.stub.GoogleSearchPort googleSearchPort = googleSearchService.getGoogleSearchPort();
            GoogleSearchResult result =
                    googleSearchPort.doGoogleSearch(
                    "iuH+5SdQFHIYv18KNcIjkg6RvfIUNYc6",
                    "J2EE", 0, 10, true, "", false,
                    "", "UTF8", "UTF8");
            
            ResultElement [] resultados = result.getResultElements();
            for(ResultElement resultado: resultados) {
                System.out.println("Titulo: " + resultado.getTitle());
                System.out.println("Descripcion: " + resultado.getSnippet());
                System.out.println("URL: " + resultado.getURL());
            }
        } catch(javax.xml.rpc.ServiceException ex) {
            // TODO handle ServiceException
        } catch(java.rmi.RemoteException ex) {
            // TODO handle remote exception
        } catch(Exception ex) {
            // TODO handle custom exceptions here
        }
        
        // TODO code application logic here
        
    }
    
}
