/*
 * Main.java
 *
 * Created on 25 de mayo de 2007, 18:57
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package es.ua.jtech.servcweb.sesion1.hola;

/**
 *
 * @author EPS
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try { // Call Web Service Operation
            es.ua.jtech.servcweb.sesion1.hola.stub.HolaMundoSWService service = new es.ua.jtech.servcweb.sesion1.hola.stub.HolaMundoSWService();
            es.ua.jtech.servcweb.sesion1.hola.stub.HolaMundoSW port = service.getHolaMundoSW();
            // TODO initialize WS operation arguments here
            java.lang.String nombre = "Miguel Angel";
            // TODO process result here
            java.lang.String result = port.saluda(nombre);
            System.out.println("Result = "+result);
        } catch (Exception ex) {
            // TODO handle custom exceptions here
        }
        // TODO code application logic here
        
    }
    
}
