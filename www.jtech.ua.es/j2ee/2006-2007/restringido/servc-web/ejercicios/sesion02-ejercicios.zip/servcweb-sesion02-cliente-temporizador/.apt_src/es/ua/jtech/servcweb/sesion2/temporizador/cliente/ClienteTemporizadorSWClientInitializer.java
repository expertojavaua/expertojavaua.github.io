
package es.ua.jtech.servcweb.sesion2.temporizador.cliente;

import java.lang.reflect.Field;
import org.apache.beehive.controls.api.ControlException;
import org.apache.beehive.controls.api.bean.Controls;
import org.apache.beehive.controls.api.versioning.VersionRequired;
import org.apache.beehive.controls.api.context.ControlBeanContext;
import org.apache.beehive.controls.runtime.bean.EventAdaptor;
import org.apache.beehive.controls.runtime.bean.AdaptorPersistenceDelegate;

@SuppressWarnings("all")
public class ClienteTemporizadorSWClientInitializer
extends org.apache.beehive.controls.runtime.bean.ClientInitializer
{
    static final Field _temporizadorSWServiceControlField;
    static
    {
        try
        {
            _temporizadorSWServiceControlField = es.ua.jtech.servcweb.sesion2.temporizador.cliente.ClienteTemporizadorSW.class.getDeclaredField("temporizadorSWServiceControl");
            _temporizadorSWServiceControlField.setAccessible(true);
        }
        catch (NoSuchFieldException __bc_nsfe)
        {
            throw new ExceptionInInitializerError(__bc_nsfe);
        }
    }
    
    public static class TemporizadorSWServiceControlCallbackEventAdaptor 
    implements es.ua.jtech.servcweb.sesion2.temporizador.control.TemporizadorSWServiceControl.Callback, 
    EventAdaptor, java.io.Serializable
    {
        private static final long serialVersionUID = 1L;
        
        es.ua.jtech.servcweb.sesion2.temporizador.cliente.ClienteTemporizadorSW __bc_client;
        
        public TemporizadorSWServiceControlCallbackEventAdaptor(es.ua.jtech.servcweb.sesion2.temporizador.cliente.ClienteTemporizadorSW client) { __bc_client = client; }
        
        public Object getClient() { return __bc_client; }
        
        public void enviaRespuesta(java.lang.String mensaje_arg) 
        {
            __bc_client.temporizadorSWServiceControl_Callback_enviaRespuesta(mensaje_arg);
        }
        public void onAsyncFailure(java.lang.String arg0, java.lang.Object[] arg1) 
        {
        }
    }
    
    
    private static void initializeFields(ControlBeanContext cbc,
    es.ua.jtech.servcweb.sesion2.temporizador.cliente.ClienteTemporizadorSW client)
    {
        try
        {
            String __bc_id;
            //
            // Initialize any nested controls used by the client
            //
            __bc_id = "temporizadorSWServiceControl";
            es.ua.jtech.servcweb.sesion2.temporizador.control.TemporizadorSWServiceControlBean _temporizadorSWServiceControl = (cbc == null ? null : (es.ua.jtech.servcweb.sesion2.temporizador.control.TemporizadorSWServiceControlBean)cbc.getBean(__bc_id));
            if (_temporizadorSWServiceControl == null)
            _temporizadorSWServiceControl = (es.ua.jtech.servcweb.sesion2.temporizador.control.TemporizadorSWServiceControlBean) Controls.instantiate(es.ua.jtech.servcweb.sesion2.temporizador.control.TemporizadorSWServiceControlBean.class, getAnnotationMap(cbc, _temporizadorSWServiceControlField), cbc, __bc_id );
            _temporizadorSWServiceControl.addCallbackListener(new TemporizadorSWServiceControlCallbackEventAdaptor(client));
            
            
            _temporizadorSWServiceControlField.set(client, _temporizadorSWServiceControl);
        }
        catch (RuntimeException __bc_re) { throw __bc_re; }
        catch (Exception __bc_e)
        {
            __bc_e.printStackTrace();
            throw new ControlException("Initializer failure", __bc_e);
        }
    }
    
    public static void initialize(ControlBeanContext cbc, es.ua.jtech.servcweb.sesion2.temporizador.cliente.ClienteTemporizadorSW client)
    {
        
        initializeFields( cbc, client );
    }
}
