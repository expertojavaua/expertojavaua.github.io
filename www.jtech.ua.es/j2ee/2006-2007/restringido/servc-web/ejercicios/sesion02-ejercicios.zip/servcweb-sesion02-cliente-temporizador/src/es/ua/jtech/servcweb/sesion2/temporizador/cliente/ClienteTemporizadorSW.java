package es.ua.jtech.servcweb.sesion2.temporizador.cliente;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.apache.beehive.controls.api.bean.Control;
import org.apache.beehive.controls.api.events.EventHandler;

import es.ua.jtech.servcweb.sesion2.temporizador.control.TemporizadorSWServiceControl;

@WebService
public class ClienteTemporizadorSW {

  static String mensaje = null;
	
  @Control
  private TemporizadorSWServiceControl temporizadorSWServiceControl;

  @WebMethod
  public void programa(java.lang.String mensaje_arg, 
                       int segundos_arg) {
    temporizadorSWServiceControl.programa(mensaje_arg, segundos_arg);
  }

  @WebMethod
  public String getUltimoMensaje() {
    if(mensaje==null) {
      return "No se ha recibido ningun mensaje";
    } else {
      return mensaje;			
    }
  }

  @EventHandler(field = "temporizadorSWServiceControl", 
              eventSet = TemporizadorSWServiceControl.Callback.class, 
              eventName = "enviaRespuesta")
  protected void temporizadorSWServiceControl_Callback_enviaRespuesta(
      java.lang.String mensaje_arg) {
    mensaje = mensaje_arg;
  }
}