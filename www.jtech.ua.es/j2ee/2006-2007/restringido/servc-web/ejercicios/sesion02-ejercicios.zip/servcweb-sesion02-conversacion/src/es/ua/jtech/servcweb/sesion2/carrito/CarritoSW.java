package es.ua.jtech.servcweb.sesion2.carrito;

import java.io.Serializable;

import javax.jws.WebMethod;
import javax.jws.WebService;

import weblogic.jws.Context;
import weblogic.jws.Conversation;
import weblogic.jws.Conversational;
import weblogic.wsee.jws.JwsContext;
import es.ua.jtech.servcweb.sesion2.carrito.to.Articulo;
import es.ua.jtech.servcweb.sesion2.carrito.to.Ticket;

@WebService
@Conversational(runAsStartUser=false, maxIdleTime = "600 seconds", 
                maxAge = "2 day")
public class CarritoSW implements Serializable {

  private static final long serialVersionUID = -1005644027645719969L;

  @Context  
  private JwsContext ctx;
  
  Ticket ticket;
  Articulo articulo;
	
  @WebMethod
  @Conversation(Conversation.Phase.START)
  public void comenzarCompra(String cliente) {
    ticket = new Ticket(cliente);
  }	

  @WebMethod
  @Conversation(Conversation.Phase.FINISH)
  public Ticket finalizarCompra() {
    ticket.calcularTotal();
    return ticket;
  }

  @WebMethod
  @Conversation(Conversation.Phase.CONTINUE)
  public void agregarArticulo(String articulo, double precio) {
    ticket.addArticulo(new Articulo(articulo, precio));
  }

  @WebMethod
  @Conversation(Conversation.Phase.CONTINUE)
  public Articulo [] verArticulos() {
    return ticket.getArticulosArray();
  }
}