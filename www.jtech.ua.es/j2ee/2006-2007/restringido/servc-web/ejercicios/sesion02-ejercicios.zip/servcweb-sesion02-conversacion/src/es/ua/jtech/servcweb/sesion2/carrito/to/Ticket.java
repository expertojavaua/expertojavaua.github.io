package es.ua.jtech.servcweb.sesion2.carrito.to;

import java.io.Serializable;
import java.util.ArrayList;

public class Ticket implements Serializable {

  private static final long serialVersionUID = 7124933176493493152L;

  ArrayList articulos;
  String cliente;
  double total;
	
  public Ticket() {	
  }
	
  public Ticket(String cliente) {
    this.cliente = cliente;
    this.articulos = new ArrayList();
    this.total = 0.0;
  }

  public Articulo [] getArticulosArray() {
    Articulo [] articulosArray = new Articulo [this.articulos.size()];
    this.articulos.toArray(articulosArray);
    return articulosArray;
  }
	
  public void addArticulo(Articulo art) {
    this.articulos.add(art);
  }

  public ArrayList getArticulos() {
    return articulos;
  }

  public void setArticulos(ArrayList articulos) {
    this.articulos = articulos;
  }

  public String getCliente() {
    return cliente;
  }

  public void setCliente(String cliente) {
    this.cliente = cliente;
  }

  public double getTotal() {
    return total;
  }

  public void setTotal(double total) {
    this.total = total;
  }
	
  public void calcularTotal() {
    this.total = 0.0;
    for(Object o: articulos) {
      Articulo a = (Articulo)o;
      this.total += a.getPrecio();
    }
  }
}
