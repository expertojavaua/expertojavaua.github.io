package es.ua.jtech.servcweb.sesion2.conversion;

import javax.xml.ws.Endpoint;

import es.ua.jtech.servcweb.sesion2.conversion.sw.ConversionSW;

public class Main {

	public static void main(String[] args) {

		Endpoint.publish(
		         "http://localhost:8080/ServicioWeb/Conversion",
		         new ConversionSW());

	}

}
