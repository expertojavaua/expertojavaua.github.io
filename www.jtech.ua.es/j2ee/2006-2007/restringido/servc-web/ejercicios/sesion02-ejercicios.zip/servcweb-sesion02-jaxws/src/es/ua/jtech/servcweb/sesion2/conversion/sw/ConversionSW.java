package es.ua.jtech.servcweb.sesion2.conversion.sw;

import javax.jws.WebService;

@WebService
public class ConversionSW {
	public int euro2ptas(double euro) {
		return (int) (euro * 166.386);
	}

	public double ptas2euro(int ptas) {
		return ((double) ptas) / 166.386;
	}
}