
package es.ua.jtech.servcweb.sesion2.conversion.sw.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "euro2ptas", namespace = "http://sw.conversion.sesion2.servcweb.jtech.ua.es/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "euro2ptas", namespace = "http://sw.conversion.sesion2.servcweb.jtech.ua.es/")
public class Euro2ptas {

    @XmlElement(name = "arg0", namespace = "")
    private double arg0;

    /**
     * 
     * @return
     *     returns double
     */
    public double getArg0() {
        return this.arg0;
    }

    /**
     * 
     * @param arg0
     *     the value for the arg0 property
     */
    public void setArg0(double arg0) {
        this.arg0 = arg0;
    }

}
