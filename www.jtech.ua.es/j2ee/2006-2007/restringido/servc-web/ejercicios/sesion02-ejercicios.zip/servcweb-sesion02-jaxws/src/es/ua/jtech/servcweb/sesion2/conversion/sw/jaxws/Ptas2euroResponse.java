
package es.ua.jtech.servcweb.sesion2.conversion.sw.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "ptas2euroResponse", namespace = "http://sw.conversion.sesion2.servcweb.jtech.ua.es/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ptas2euroResponse", namespace = "http://sw.conversion.sesion2.servcweb.jtech.ua.es/")
public class Ptas2euroResponse {

    @XmlElement(name = "return", namespace = "")
    private double _return;

    /**
     * 
     * @return
     *     returns double
     */
    public double get_return() {
        return this._return;
    }

    /**
     * 
     * @param _return
     *     the value for the _return property
     */
    public void set_return(double _return) {
        this._return = _return;
    }

}
