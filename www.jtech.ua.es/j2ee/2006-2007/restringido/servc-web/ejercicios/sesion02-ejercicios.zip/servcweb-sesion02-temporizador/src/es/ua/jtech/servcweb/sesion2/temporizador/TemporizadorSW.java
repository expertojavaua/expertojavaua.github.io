package es.ua.jtech.servcweb.sesion2.temporizador;

import java.util.Timer;
import java.util.TimerTask;

import javax.jws.*;
import weblogic.jws.CallbackService;
import weblogic.wsee.jws.CallbackInterface;
import weblogic.jws.Callback;

@WebService
public class TemporizadorSW {

  @Callback
  private CallbackSvc callback;

  @WebMethod
  @Oneway()
  public void programa(String mensaje, int segundos) {
    TimerTask tarea = new Temporizador(mensaje);
    Timer timer = new Timer();
    timer.schedule(tarea, segundos * 1000);
  }

  @CallbackService
  public interface CallbackSvc extends CallbackInterface {
    @WebMethod
    public void enviaRespuesta(String mensaje);
  }
	
  class Temporizador extends TimerTask {
    String mensaje;
	
    public Temporizador(String mensaje) {
      this.mensaje = mensaje;
    }
		
    public void run() {
      callback.enviaRespuesta(mensaje);
    }
  }
}