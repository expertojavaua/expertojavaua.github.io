package es.ua.jtech.servcweb.sesion2.conversion.control;
import com.bea.control.ServiceControl;

import org.apache.beehive.controls.api.events.EventSet;
import org.apache.beehive.controls.api.bean.ControlExtension;

@ServiceControl.Location(urls = {"http://services.xmethods.net:80/soap"})
@ServiceControl.HttpSoapProtocol
@ServiceControl.SOAPBinding(style = ServiceControl.SOAPBinding.Style.RPC, use = ServiceControl.SOAPBinding.Use.ENCODED)
@ServiceControl.WSDL(resourcePath = "es/ua/jtech/servcweb/sesion2/conversion/control/CurrencyExchangeService.wsdl", service = "CurrencyExchangeService")
@ControlExtension
public interface CurrencyExchangeServiceControl extends ServiceControl
{
    static final long serialVersionUID = 1L;

    public float getRate(java.lang.String country1_arg,java.lang.String country2_arg);

   /** This event set interface provides support for the onAsyncFailure event.
    */
   @EventSet(unicast=true)
   public interface Callback extends ServiceControl.Callback {};
}