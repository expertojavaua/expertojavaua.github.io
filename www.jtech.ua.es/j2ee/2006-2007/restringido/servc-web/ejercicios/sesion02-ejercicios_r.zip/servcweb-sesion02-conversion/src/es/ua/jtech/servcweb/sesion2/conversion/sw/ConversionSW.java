package es.ua.jtech.servcweb.sesion2.conversion.sw;

import javax.jws.*;
import org.apache.beehive.controls.api.bean.Control;
import es.ua.jtech.servcweb.sesion2.conversion.control.CurrencyExchangeServiceControl;

@WebService
public class ConversionSW {

	@Control
	private CurrencyExchangeServiceControl currencyExchangeServiceControl;

	@WebMethod
	public int euro2ptas(double euros) {
		return (int)(euros*166.386);
	}

	@WebMethod
	public double ptas2euro(int ptas) {
		return ptas/166.386;
	}

	@WebMethod
	public float getRate(java.lang.String country1_arg,
			java.lang.String country2_arg) {
		return currencyExchangeServiceControl.getRate(country1_arg, country2_arg);
	}

	@WebMethod
	public double euro2dolar(double euros) {
		return euros * currencyExchangeServiceControl.getRate("euro", "usa");
	}

	@WebMethod
	public double dolar2euro(double dolares) {
		return dolares * currencyExchangeServiceControl.getRate("usa", "euro");
	}
}