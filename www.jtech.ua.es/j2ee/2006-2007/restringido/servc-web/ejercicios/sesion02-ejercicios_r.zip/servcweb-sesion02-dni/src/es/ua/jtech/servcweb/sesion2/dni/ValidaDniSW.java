package es.ua.jtech.servcweb.sesion2.dni;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.namespace.QName;
import javax.xml.rpc.soap.SOAPFaultException;
import javax.xml.soap.Detail;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFactory;

@WebService
public class ValidaDniSW {

	@WebMethod
	public boolean validarDni(String dni) {
		Pattern pattern = Pattern.compile("[0-9]{8,8}");
		Matcher matcher = pattern.matcher(dni);
		return matcher.matches();
	}

	@WebMethod
	public char obtenerLetra(String dni) {
		if (!validarDni(dni)) {
			lanzarExcepcion("El DNI no es valido");
		}
		String letras = "TRWAGMYFPDXBNJZSQVHLCKE";
		long lDni = Long.parseLong(dni);
		return letras.charAt((int) (lDni % 23));
	}

	@WebMethod
	public boolean validarNif(String nif) {
		if (nif.length() != 9) {
			return false;
		}

		String dni = nif.substring(0, 8);
		return validarDni(dni)
				&& obtenerLetra(dni) == nif.charAt(8);
	}

	private void lanzarExcepcion(String mensaje) {
		Detail detail = null;

		try {
			SOAPFactory soapFactory = SOAPFactory.newInstance();
			detail = soapFactory.createDetail();
		} catch (SOAPException e) {
		}

		QName faultCode = null;
		String faultString = mensaje;
		String faultActor = "Servicio Conversion";
		throw new SOAPFaultException(faultCode, faultString, faultActor, detail);
	}
}