package es.ua.jtech.servcweb.sesion2.hola;

import javax.jws.*;

@WebService
public class HolaMundoSW {

	@WebMethod
	public String hola(String nombre) {
		return "Hola " + nombre;
	}
}