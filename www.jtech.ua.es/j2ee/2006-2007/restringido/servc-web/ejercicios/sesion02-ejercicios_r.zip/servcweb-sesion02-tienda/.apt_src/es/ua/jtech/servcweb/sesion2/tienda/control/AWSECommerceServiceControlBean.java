
package es.ua.jtech.servcweb.sesion2.tienda.control;

import java.beans.*;

import java.lang.reflect.Method;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.HashMap;
import java.util.Map;

import org.apache.beehive.controls.api.bean.*;
import org.apache.beehive.controls.api.context.ControlBeanContext;
import org.apache.beehive.controls.api.properties.PropertyKey;
import org.apache.beehive.controls.api.properties.PropertyMap;
import org.apache.beehive.controls.api.versioning.*;

@SuppressWarnings("all")
public class AWSECommerceServiceControlBean
extends com.bea.control.ServiceControlBean
implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl
{
    static final Method _cartModifyMethod;
    static final Method _cartAddMethod;
    static final Method _multiOperationMethod;
    static final Method _listLookupMethod;
    static final Method _sellerListingSearchMethod;
    static final Method _cartClearMethod;
    static final Method _browseNodeLookupMethod;
    static final Method _itemLookupMethod;
    static final Method _sellerLookupMethod;
    static final Method _similarityLookupMethod;
    static final Method _listSearchMethod;
    static final Method _cartCreateMethod;
    static final Method _cartGetMethod;
    static final Method _itemSearchMethod;
    static final Method _sellerListingLookupMethod;
    static final Method _helpMethod;
    static final Method _customerContentLookupMethod;
    static final Method _transactionLookupMethod;
    static final Method _customerContentSearchMethod;
    static final Method _Callback_onAsyncFailureEvent;
    
    //
    // This HashMap will map from a Method to the array of names for parameters of the
    // method.  This is necessary because parameter name data isn't carried along in the
    // class file, but if available can enable ease of use by referencing parameters by
    // the declared name (vs. by index).
    //
    // This map should be read-only after its initialization in the static block, hence
    // using a plain HashMap is thread-safe.
    //
    static HashMap<Method, String []> _methodParamMap = new HashMap<Method, String []>();
    
    static
    {
        try
        {
            _cartModifyMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("cartModify", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.CartModify.class});
            _methodParamMap.put(_cartModifyMethod, new String [] { "body_arg" });
            _cartAddMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("cartAdd", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.CartAdd.class});
            _methodParamMap.put(_cartAddMethod, new String [] { "body_arg" });
            _multiOperationMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("multiOperation", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.MultiOperation.class});
            _methodParamMap.put(_multiOperationMethod, new String [] { "body_arg" });
            _listLookupMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("listLookup", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.ListLookup.class});
            _methodParamMap.put(_listLookupMethod, new String [] { "body_arg" });
            _sellerListingSearchMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("sellerListingSearch", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.SellerListingSearch.class});
            _methodParamMap.put(_sellerListingSearchMethod, new String [] { "body_arg" });
            _cartClearMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("cartClear", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.CartClear.class});
            _methodParamMap.put(_cartClearMethod, new String [] { "body_arg" });
            _browseNodeLookupMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("browseNodeLookup", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.BrowseNodeLookup.class});
            _methodParamMap.put(_browseNodeLookupMethod, new String [] { "body_arg" });
            _itemLookupMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("itemLookup", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.ItemLookup.class});
            _methodParamMap.put(_itemLookupMethod, new String [] { "body_arg" });
            _sellerLookupMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("sellerLookup", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.SellerLookup.class});
            _methodParamMap.put(_sellerLookupMethod, new String [] { "body_arg" });
            _similarityLookupMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("similarityLookup", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.SimilarityLookup.class});
            _methodParamMap.put(_similarityLookupMethod, new String [] { "body_arg" });
            _listSearchMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("listSearch", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.ListSearch.class});
            _methodParamMap.put(_listSearchMethod, new String [] { "body_arg" });
            _cartCreateMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("cartCreate", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.CartCreate.class});
            _methodParamMap.put(_cartCreateMethod, new String [] { "body_arg" });
            _cartGetMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("cartGet", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.CartGet.class});
            _methodParamMap.put(_cartGetMethod, new String [] { "body_arg" });
            _itemSearchMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("itemSearch", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.ItemSearch.class});
            _methodParamMap.put(_itemSearchMethod, new String [] { "body_arg" });
            _sellerListingLookupMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("sellerListingLookup", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.SellerListingLookup.class});
            _methodParamMap.put(_sellerListingLookupMethod, new String [] { "body_arg" });
            _helpMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("help", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.Help.class});
            _methodParamMap.put(_helpMethod, new String [] { "body_arg" });
            _customerContentLookupMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("customerContentLookup", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.CustomerContentLookup.class});
            _methodParamMap.put(_customerContentLookupMethod, new String [] { "body_arg" });
            _transactionLookupMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("transactionLookup", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.TransactionLookup.class});
            _methodParamMap.put(_transactionLookupMethod, new String [] { "body_arg" });
            _customerContentSearchMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("customerContentSearch", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.CustomerContentSearch.class});
            _methodParamMap.put(_customerContentSearchMethod, new String [] { "body_arg" });
            _Callback_onAsyncFailureEvent = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.Callback.class.getMethod("onAsyncFailure", new Class [] {java.lang.String.class, java.lang.Object[].class});
            _methodParamMap.put(_Callback_onAsyncFailureEvent, new String [] { "arg0", "arg1" });
        }
        catch (NoSuchMethodException __bc_nsme)
        {
            throw new ExceptionInInitializerError(__bc_nsme);
        }
    }
    
    
    
    static
    {
        
    }
    
    
    
    /**
    * This is the public constructor for the class.  A client-defined control ID may
    * be provided.  This ID must be unique within the nesting ControlBeanContext.
    * @param context The containing ControlBeanContext
    * @param id The control identifier (or null to autogenerate a unique value)
    * @param props The initialization Properties for the new instance (or null for defaults)
    */
    public AWSECommerceServiceControlBean(ControlBeanContext context, String id, PropertyMap props)
    {
        this(context, id, props, es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class);
    }
    
    /**
    * This is the public null-arg constructor for this ControlBean.  If a control id
    * is not provided, a unique value will be auto-generated.
    */
    public AWSECommerceServiceControlBean()
    {
        this(null, null, null);
    }
    
    /**
    * This is the protected version that is used by any ControlBean subclass
    */
    protected AWSECommerceServiceControlBean(ControlBeanContext context, String id, PropertyMap props, Class controlClass)
    {
        super(context, id, props, controlClass);
        
        //
        // Register event notifier instances for any EventSets
        //
        setEventNotifier(es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.Callback.class, new CallbackNotifier());
    }
    
    
    /**
    * Returns an array of parameter names for the request method, or null if no parameter
    * data is available.
    */
    protected String [] getParameterNames(Method m)
    {
        // Check the local map for operations on this bean type
        if (_methodParamMap.containsKey(m))
        {
            return _methodParamMap.get(m);
        }
        
        // Delegate up if not found locally
        return super.getParameterNames(m);
    }
    
    /**
    * Implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.cartModify
    */
    public  com.amazon.webservices.awsecommerceservice.x20070514.CartModifyResponse cartModify(com.amazon.webservices.awsecommerceservice.x20070514.CartModify body_arg) 
    {
        Object [] __bc_argArray = new Object[] { body_arg };
        Throwable __bc_thrown = null;
        Extensible __bc_target = (Extensible)ensureControl();
        com.amazon.webservices.awsecommerceservice.x20070514.CartModifyResponse __bc_retval = null;
        
        try
        {
            preInvoke(_cartModifyMethod, __bc_argArray);
            
            __bc_retval =
            (com.amazon.webservices.awsecommerceservice.x20070514.CartModifyResponse)
            __bc_target.invoke(_cartModifyMethod, __bc_argArray)
            ;
        }
        catch (Throwable __bc_t)
        {
            //
            // All exceptions are caught here, so postInvoke processing has visibility into
            // the exception status.  Errors, RuntimExceptions, or declared checked exceptions will
            // be rethrown.
            //
            __bc_thrown = __bc_t;
            
            if (__bc_t instanceof Error) throw (Error)__bc_t;
            else if (__bc_t instanceof RuntimeException) throw (RuntimeException)__bc_t;
            
            throw new UndeclaredThrowableException(__bc_t);
        }
        finally
        {
            Object __bc_rv = __bc_retval;
            postInvoke(_cartModifyMethod, __bc_argArray, __bc_rv, __bc_thrown);
        }
        return __bc_retval;
    }
    
    /**
    * Implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.cartAdd
    */
    public  com.amazon.webservices.awsecommerceservice.x20070514.CartAddResponse cartAdd(com.amazon.webservices.awsecommerceservice.x20070514.CartAdd body_arg) 
    {
        Object [] __bc_argArray = new Object[] { body_arg };
        Throwable __bc_thrown = null;
        Extensible __bc_target = (Extensible)ensureControl();
        com.amazon.webservices.awsecommerceservice.x20070514.CartAddResponse __bc_retval = null;
        
        try
        {
            preInvoke(_cartAddMethod, __bc_argArray);
            
            __bc_retval =
            (com.amazon.webservices.awsecommerceservice.x20070514.CartAddResponse)
            __bc_target.invoke(_cartAddMethod, __bc_argArray)
            ;
        }
        catch (Throwable __bc_t)
        {
            //
            // All exceptions are caught here, so postInvoke processing has visibility into
            // the exception status.  Errors, RuntimExceptions, or declared checked exceptions will
            // be rethrown.
            //
            __bc_thrown = __bc_t;
            
            if (__bc_t instanceof Error) throw (Error)__bc_t;
            else if (__bc_t instanceof RuntimeException) throw (RuntimeException)__bc_t;
            
            throw new UndeclaredThrowableException(__bc_t);
        }
        finally
        {
            Object __bc_rv = __bc_retval;
            postInvoke(_cartAddMethod, __bc_argArray, __bc_rv, __bc_thrown);
        }
        return __bc_retval;
    }
    
    /**
    * Implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.multiOperation
    */
    public  com.amazon.webservices.awsecommerceservice.x20070514.MultiOperationResponse multiOperation(com.amazon.webservices.awsecommerceservice.x20070514.MultiOperation body_arg) 
    {
        Object [] __bc_argArray = new Object[] { body_arg };
        Throwable __bc_thrown = null;
        Extensible __bc_target = (Extensible)ensureControl();
        com.amazon.webservices.awsecommerceservice.x20070514.MultiOperationResponse __bc_retval = null;
        
        try
        {
            preInvoke(_multiOperationMethod, __bc_argArray);
            
            __bc_retval =
            (com.amazon.webservices.awsecommerceservice.x20070514.MultiOperationResponse)
            __bc_target.invoke(_multiOperationMethod, __bc_argArray)
            ;
        }
        catch (Throwable __bc_t)
        {
            //
            // All exceptions are caught here, so postInvoke processing has visibility into
            // the exception status.  Errors, RuntimExceptions, or declared checked exceptions will
            // be rethrown.
            //
            __bc_thrown = __bc_t;
            
            if (__bc_t instanceof Error) throw (Error)__bc_t;
            else if (__bc_t instanceof RuntimeException) throw (RuntimeException)__bc_t;
            
            throw new UndeclaredThrowableException(__bc_t);
        }
        finally
        {
            Object __bc_rv = __bc_retval;
            postInvoke(_multiOperationMethod, __bc_argArray, __bc_rv, __bc_thrown);
        }
        return __bc_retval;
    }
    
    /**
    * Implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.listLookup
    */
    public  com.amazon.webservices.awsecommerceservice.x20070514.ListLookupResponse listLookup(com.amazon.webservices.awsecommerceservice.x20070514.ListLookup body_arg) 
    {
        Object [] __bc_argArray = new Object[] { body_arg };
        Throwable __bc_thrown = null;
        Extensible __bc_target = (Extensible)ensureControl();
        com.amazon.webservices.awsecommerceservice.x20070514.ListLookupResponse __bc_retval = null;
        
        try
        {
            preInvoke(_listLookupMethod, __bc_argArray);
            
            __bc_retval =
            (com.amazon.webservices.awsecommerceservice.x20070514.ListLookupResponse)
            __bc_target.invoke(_listLookupMethod, __bc_argArray)
            ;
        }
        catch (Throwable __bc_t)
        {
            //
            // All exceptions are caught here, so postInvoke processing has visibility into
            // the exception status.  Errors, RuntimExceptions, or declared checked exceptions will
            // be rethrown.
            //
            __bc_thrown = __bc_t;
            
            if (__bc_t instanceof Error) throw (Error)__bc_t;
            else if (__bc_t instanceof RuntimeException) throw (RuntimeException)__bc_t;
            
            throw new UndeclaredThrowableException(__bc_t);
        }
        finally
        {
            Object __bc_rv = __bc_retval;
            postInvoke(_listLookupMethod, __bc_argArray, __bc_rv, __bc_thrown);
        }
        return __bc_retval;
    }
    
    /**
    * Implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.sellerListingSearch
    */
    public  com.amazon.webservices.awsecommerceservice.x20070514.SellerListingSearchResponse sellerListingSearch(com.amazon.webservices.awsecommerceservice.x20070514.SellerListingSearch body_arg) 
    {
        Object [] __bc_argArray = new Object[] { body_arg };
        Throwable __bc_thrown = null;
        Extensible __bc_target = (Extensible)ensureControl();
        com.amazon.webservices.awsecommerceservice.x20070514.SellerListingSearchResponse __bc_retval = null;
        
        try
        {
            preInvoke(_sellerListingSearchMethod, __bc_argArray);
            
            __bc_retval =
            (com.amazon.webservices.awsecommerceservice.x20070514.SellerListingSearchResponse)
            __bc_target.invoke(_sellerListingSearchMethod, __bc_argArray)
            ;
        }
        catch (Throwable __bc_t)
        {
            //
            // All exceptions are caught here, so postInvoke processing has visibility into
            // the exception status.  Errors, RuntimExceptions, or declared checked exceptions will
            // be rethrown.
            //
            __bc_thrown = __bc_t;
            
            if (__bc_t instanceof Error) throw (Error)__bc_t;
            else if (__bc_t instanceof RuntimeException) throw (RuntimeException)__bc_t;
            
            throw new UndeclaredThrowableException(__bc_t);
        }
        finally
        {
            Object __bc_rv = __bc_retval;
            postInvoke(_sellerListingSearchMethod, __bc_argArray, __bc_rv, __bc_thrown);
        }
        return __bc_retval;
    }
    
    /**
    * Implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.cartClear
    */
    public  com.amazon.webservices.awsecommerceservice.x20070514.CartClearResponse cartClear(com.amazon.webservices.awsecommerceservice.x20070514.CartClear body_arg) 
    {
        Object [] __bc_argArray = new Object[] { body_arg };
        Throwable __bc_thrown = null;
        Extensible __bc_target = (Extensible)ensureControl();
        com.amazon.webservices.awsecommerceservice.x20070514.CartClearResponse __bc_retval = null;
        
        try
        {
            preInvoke(_cartClearMethod, __bc_argArray);
            
            __bc_retval =
            (com.amazon.webservices.awsecommerceservice.x20070514.CartClearResponse)
            __bc_target.invoke(_cartClearMethod, __bc_argArray)
            ;
        }
        catch (Throwable __bc_t)
        {
            //
            // All exceptions are caught here, so postInvoke processing has visibility into
            // the exception status.  Errors, RuntimExceptions, or declared checked exceptions will
            // be rethrown.
            //
            __bc_thrown = __bc_t;
            
            if (__bc_t instanceof Error) throw (Error)__bc_t;
            else if (__bc_t instanceof RuntimeException) throw (RuntimeException)__bc_t;
            
            throw new UndeclaredThrowableException(__bc_t);
        }
        finally
        {
            Object __bc_rv = __bc_retval;
            postInvoke(_cartClearMethod, __bc_argArray, __bc_rv, __bc_thrown);
        }
        return __bc_retval;
    }
    
    /**
    * Implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.browseNodeLookup
    */
    public  com.amazon.webservices.awsecommerceservice.x20070514.BrowseNodeLookupResponse browseNodeLookup(com.amazon.webservices.awsecommerceservice.x20070514.BrowseNodeLookup body_arg) 
    {
        Object [] __bc_argArray = new Object[] { body_arg };
        Throwable __bc_thrown = null;
        Extensible __bc_target = (Extensible)ensureControl();
        com.amazon.webservices.awsecommerceservice.x20070514.BrowseNodeLookupResponse __bc_retval = null;
        
        try
        {
            preInvoke(_browseNodeLookupMethod, __bc_argArray);
            
            __bc_retval =
            (com.amazon.webservices.awsecommerceservice.x20070514.BrowseNodeLookupResponse)
            __bc_target.invoke(_browseNodeLookupMethod, __bc_argArray)
            ;
        }
        catch (Throwable __bc_t)
        {
            //
            // All exceptions are caught here, so postInvoke processing has visibility into
            // the exception status.  Errors, RuntimExceptions, or declared checked exceptions will
            // be rethrown.
            //
            __bc_thrown = __bc_t;
            
            if (__bc_t instanceof Error) throw (Error)__bc_t;
            else if (__bc_t instanceof RuntimeException) throw (RuntimeException)__bc_t;
            
            throw new UndeclaredThrowableException(__bc_t);
        }
        finally
        {
            Object __bc_rv = __bc_retval;
            postInvoke(_browseNodeLookupMethod, __bc_argArray, __bc_rv, __bc_thrown);
        }
        return __bc_retval;
    }
    
    /**
    * Implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.itemLookup
    */
    public  com.amazon.webservices.awsecommerceservice.x20070514.ItemLookupResponse itemLookup(com.amazon.webservices.awsecommerceservice.x20070514.ItemLookup body_arg) 
    {
        Object [] __bc_argArray = new Object[] { body_arg };
        Throwable __bc_thrown = null;
        Extensible __bc_target = (Extensible)ensureControl();
        com.amazon.webservices.awsecommerceservice.x20070514.ItemLookupResponse __bc_retval = null;
        
        try
        {
            preInvoke(_itemLookupMethod, __bc_argArray);
            
            __bc_retval =
            (com.amazon.webservices.awsecommerceservice.x20070514.ItemLookupResponse)
            __bc_target.invoke(_itemLookupMethod, __bc_argArray)
            ;
        }
        catch (Throwable __bc_t)
        {
            //
            // All exceptions are caught here, so postInvoke processing has visibility into
            // the exception status.  Errors, RuntimExceptions, or declared checked exceptions will
            // be rethrown.
            //
            __bc_thrown = __bc_t;
            
            if (__bc_t instanceof Error) throw (Error)__bc_t;
            else if (__bc_t instanceof RuntimeException) throw (RuntimeException)__bc_t;
            
            throw new UndeclaredThrowableException(__bc_t);
        }
        finally
        {
            Object __bc_rv = __bc_retval;
            postInvoke(_itemLookupMethod, __bc_argArray, __bc_rv, __bc_thrown);
        }
        return __bc_retval;
    }
    
    /**
    * Implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.sellerLookup
    */
    public  com.amazon.webservices.awsecommerceservice.x20070514.SellerLookupResponse sellerLookup(com.amazon.webservices.awsecommerceservice.x20070514.SellerLookup body_arg) 
    {
        Object [] __bc_argArray = new Object[] { body_arg };
        Throwable __bc_thrown = null;
        Extensible __bc_target = (Extensible)ensureControl();
        com.amazon.webservices.awsecommerceservice.x20070514.SellerLookupResponse __bc_retval = null;
        
        try
        {
            preInvoke(_sellerLookupMethod, __bc_argArray);
            
            __bc_retval =
            (com.amazon.webservices.awsecommerceservice.x20070514.SellerLookupResponse)
            __bc_target.invoke(_sellerLookupMethod, __bc_argArray)
            ;
        }
        catch (Throwable __bc_t)
        {
            //
            // All exceptions are caught here, so postInvoke processing has visibility into
            // the exception status.  Errors, RuntimExceptions, or declared checked exceptions will
            // be rethrown.
            //
            __bc_thrown = __bc_t;
            
            if (__bc_t instanceof Error) throw (Error)__bc_t;
            else if (__bc_t instanceof RuntimeException) throw (RuntimeException)__bc_t;
            
            throw new UndeclaredThrowableException(__bc_t);
        }
        finally
        {
            Object __bc_rv = __bc_retval;
            postInvoke(_sellerLookupMethod, __bc_argArray, __bc_rv, __bc_thrown);
        }
        return __bc_retval;
    }
    
    /**
    * Implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.similarityLookup
    */
    public  com.amazon.webservices.awsecommerceservice.x20070514.SimilarityLookupResponse similarityLookup(com.amazon.webservices.awsecommerceservice.x20070514.SimilarityLookup body_arg) 
    {
        Object [] __bc_argArray = new Object[] { body_arg };
        Throwable __bc_thrown = null;
        Extensible __bc_target = (Extensible)ensureControl();
        com.amazon.webservices.awsecommerceservice.x20070514.SimilarityLookupResponse __bc_retval = null;
        
        try
        {
            preInvoke(_similarityLookupMethod, __bc_argArray);
            
            __bc_retval =
            (com.amazon.webservices.awsecommerceservice.x20070514.SimilarityLookupResponse)
            __bc_target.invoke(_similarityLookupMethod, __bc_argArray)
            ;
        }
        catch (Throwable __bc_t)
        {
            //
            // All exceptions are caught here, so postInvoke processing has visibility into
            // the exception status.  Errors, RuntimExceptions, or declared checked exceptions will
            // be rethrown.
            //
            __bc_thrown = __bc_t;
            
            if (__bc_t instanceof Error) throw (Error)__bc_t;
            else if (__bc_t instanceof RuntimeException) throw (RuntimeException)__bc_t;
            
            throw new UndeclaredThrowableException(__bc_t);
        }
        finally
        {
            Object __bc_rv = __bc_retval;
            postInvoke(_similarityLookupMethod, __bc_argArray, __bc_rv, __bc_thrown);
        }
        return __bc_retval;
    }
    
    /**
    * Implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.listSearch
    */
    public  com.amazon.webservices.awsecommerceservice.x20070514.ListSearchResponse listSearch(com.amazon.webservices.awsecommerceservice.x20070514.ListSearch body_arg) 
    {
        Object [] __bc_argArray = new Object[] { body_arg };
        Throwable __bc_thrown = null;
        Extensible __bc_target = (Extensible)ensureControl();
        com.amazon.webservices.awsecommerceservice.x20070514.ListSearchResponse __bc_retval = null;
        
        try
        {
            preInvoke(_listSearchMethod, __bc_argArray);
            
            __bc_retval =
            (com.amazon.webservices.awsecommerceservice.x20070514.ListSearchResponse)
            __bc_target.invoke(_listSearchMethod, __bc_argArray)
            ;
        }
        catch (Throwable __bc_t)
        {
            //
            // All exceptions are caught here, so postInvoke processing has visibility into
            // the exception status.  Errors, RuntimExceptions, or declared checked exceptions will
            // be rethrown.
            //
            __bc_thrown = __bc_t;
            
            if (__bc_t instanceof Error) throw (Error)__bc_t;
            else if (__bc_t instanceof RuntimeException) throw (RuntimeException)__bc_t;
            
            throw new UndeclaredThrowableException(__bc_t);
        }
        finally
        {
            Object __bc_rv = __bc_retval;
            postInvoke(_listSearchMethod, __bc_argArray, __bc_rv, __bc_thrown);
        }
        return __bc_retval;
    }
    
    /**
    * Implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.cartCreate
    */
    public  com.amazon.webservices.awsecommerceservice.x20070514.CartCreateResponse cartCreate(com.amazon.webservices.awsecommerceservice.x20070514.CartCreate body_arg) 
    {
        Object [] __bc_argArray = new Object[] { body_arg };
        Throwable __bc_thrown = null;
        Extensible __bc_target = (Extensible)ensureControl();
        com.amazon.webservices.awsecommerceservice.x20070514.CartCreateResponse __bc_retval = null;
        
        try
        {
            preInvoke(_cartCreateMethod, __bc_argArray);
            
            __bc_retval =
            (com.amazon.webservices.awsecommerceservice.x20070514.CartCreateResponse)
            __bc_target.invoke(_cartCreateMethod, __bc_argArray)
            ;
        }
        catch (Throwable __bc_t)
        {
            //
            // All exceptions are caught here, so postInvoke processing has visibility into
            // the exception status.  Errors, RuntimExceptions, or declared checked exceptions will
            // be rethrown.
            //
            __bc_thrown = __bc_t;
            
            if (__bc_t instanceof Error) throw (Error)__bc_t;
            else if (__bc_t instanceof RuntimeException) throw (RuntimeException)__bc_t;
            
            throw new UndeclaredThrowableException(__bc_t);
        }
        finally
        {
            Object __bc_rv = __bc_retval;
            postInvoke(_cartCreateMethod, __bc_argArray, __bc_rv, __bc_thrown);
        }
        return __bc_retval;
    }
    
    /**
    * Implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.cartGet
    */
    public  com.amazon.webservices.awsecommerceservice.x20070514.CartGetResponse cartGet(com.amazon.webservices.awsecommerceservice.x20070514.CartGet body_arg) 
    {
        Object [] __bc_argArray = new Object[] { body_arg };
        Throwable __bc_thrown = null;
        Extensible __bc_target = (Extensible)ensureControl();
        com.amazon.webservices.awsecommerceservice.x20070514.CartGetResponse __bc_retval = null;
        
        try
        {
            preInvoke(_cartGetMethod, __bc_argArray);
            
            __bc_retval =
            (com.amazon.webservices.awsecommerceservice.x20070514.CartGetResponse)
            __bc_target.invoke(_cartGetMethod, __bc_argArray)
            ;
        }
        catch (Throwable __bc_t)
        {
            //
            // All exceptions are caught here, so postInvoke processing has visibility into
            // the exception status.  Errors, RuntimExceptions, or declared checked exceptions will
            // be rethrown.
            //
            __bc_thrown = __bc_t;
            
            if (__bc_t instanceof Error) throw (Error)__bc_t;
            else if (__bc_t instanceof RuntimeException) throw (RuntimeException)__bc_t;
            
            throw new UndeclaredThrowableException(__bc_t);
        }
        finally
        {
            Object __bc_rv = __bc_retval;
            postInvoke(_cartGetMethod, __bc_argArray, __bc_rv, __bc_thrown);
        }
        return __bc_retval;
    }
    
    /**
    * Implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.itemSearch
    */
    public  com.amazon.webservices.awsecommerceservice.x20070514.ItemSearchResponse itemSearch(com.amazon.webservices.awsecommerceservice.x20070514.ItemSearch body_arg) 
    {
        Object [] __bc_argArray = new Object[] { body_arg };
        Throwable __bc_thrown = null;
        Extensible __bc_target = (Extensible)ensureControl();
        com.amazon.webservices.awsecommerceservice.x20070514.ItemSearchResponse __bc_retval = null;
        
        try
        {
            preInvoke(_itemSearchMethod, __bc_argArray);
            
            __bc_retval =
            (com.amazon.webservices.awsecommerceservice.x20070514.ItemSearchResponse)
            __bc_target.invoke(_itemSearchMethod, __bc_argArray)
            ;
        }
        catch (Throwable __bc_t)
        {
            //
            // All exceptions are caught here, so postInvoke processing has visibility into
            // the exception status.  Errors, RuntimExceptions, or declared checked exceptions will
            // be rethrown.
            //
            __bc_thrown = __bc_t;
            
            if (__bc_t instanceof Error) throw (Error)__bc_t;
            else if (__bc_t instanceof RuntimeException) throw (RuntimeException)__bc_t;
            
            throw new UndeclaredThrowableException(__bc_t);
        }
        finally
        {
            Object __bc_rv = __bc_retval;
            postInvoke(_itemSearchMethod, __bc_argArray, __bc_rv, __bc_thrown);
        }
        return __bc_retval;
    }
    
    /**
    * Implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.sellerListingLookup
    */
    public  com.amazon.webservices.awsecommerceservice.x20070514.SellerListingLookupResponse sellerListingLookup(com.amazon.webservices.awsecommerceservice.x20070514.SellerListingLookup body_arg) 
    {
        Object [] __bc_argArray = new Object[] { body_arg };
        Throwable __bc_thrown = null;
        Extensible __bc_target = (Extensible)ensureControl();
        com.amazon.webservices.awsecommerceservice.x20070514.SellerListingLookupResponse __bc_retval = null;
        
        try
        {
            preInvoke(_sellerListingLookupMethod, __bc_argArray);
            
            __bc_retval =
            (com.amazon.webservices.awsecommerceservice.x20070514.SellerListingLookupResponse)
            __bc_target.invoke(_sellerListingLookupMethod, __bc_argArray)
            ;
        }
        catch (Throwable __bc_t)
        {
            //
            // All exceptions are caught here, so postInvoke processing has visibility into
            // the exception status.  Errors, RuntimExceptions, or declared checked exceptions will
            // be rethrown.
            //
            __bc_thrown = __bc_t;
            
            if (__bc_t instanceof Error) throw (Error)__bc_t;
            else if (__bc_t instanceof RuntimeException) throw (RuntimeException)__bc_t;
            
            throw new UndeclaredThrowableException(__bc_t);
        }
        finally
        {
            Object __bc_rv = __bc_retval;
            postInvoke(_sellerListingLookupMethod, __bc_argArray, __bc_rv, __bc_thrown);
        }
        return __bc_retval;
    }
    
    /**
    * Implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.help
    */
    public  com.amazon.webservices.awsecommerceservice.x20070514.HelpResponse help(com.amazon.webservices.awsecommerceservice.x20070514.Help body_arg) 
    {
        Object [] __bc_argArray = new Object[] { body_arg };
        Throwable __bc_thrown = null;
        Extensible __bc_target = (Extensible)ensureControl();
        com.amazon.webservices.awsecommerceservice.x20070514.HelpResponse __bc_retval = null;
        
        try
        {
            preInvoke(_helpMethod, __bc_argArray);
            
            __bc_retval =
            (com.amazon.webservices.awsecommerceservice.x20070514.HelpResponse)
            __bc_target.invoke(_helpMethod, __bc_argArray)
            ;
        }
        catch (Throwable __bc_t)
        {
            //
            // All exceptions are caught here, so postInvoke processing has visibility into
            // the exception status.  Errors, RuntimExceptions, or declared checked exceptions will
            // be rethrown.
            //
            __bc_thrown = __bc_t;
            
            if (__bc_t instanceof Error) throw (Error)__bc_t;
            else if (__bc_t instanceof RuntimeException) throw (RuntimeException)__bc_t;
            
            throw new UndeclaredThrowableException(__bc_t);
        }
        finally
        {
            Object __bc_rv = __bc_retval;
            postInvoke(_helpMethod, __bc_argArray, __bc_rv, __bc_thrown);
        }
        return __bc_retval;
    }
    
    /**
    * Implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.customerContentLookup
    */
    public  com.amazon.webservices.awsecommerceservice.x20070514.CustomerContentLookupResponse customerContentLookup(com.amazon.webservices.awsecommerceservice.x20070514.CustomerContentLookup body_arg) 
    {
        Object [] __bc_argArray = new Object[] { body_arg };
        Throwable __bc_thrown = null;
        Extensible __bc_target = (Extensible)ensureControl();
        com.amazon.webservices.awsecommerceservice.x20070514.CustomerContentLookupResponse __bc_retval = null;
        
        try
        {
            preInvoke(_customerContentLookupMethod, __bc_argArray);
            
            __bc_retval =
            (com.amazon.webservices.awsecommerceservice.x20070514.CustomerContentLookupResponse)
            __bc_target.invoke(_customerContentLookupMethod, __bc_argArray)
            ;
        }
        catch (Throwable __bc_t)
        {
            //
            // All exceptions are caught here, so postInvoke processing has visibility into
            // the exception status.  Errors, RuntimExceptions, or declared checked exceptions will
            // be rethrown.
            //
            __bc_thrown = __bc_t;
            
            if (__bc_t instanceof Error) throw (Error)__bc_t;
            else if (__bc_t instanceof RuntimeException) throw (RuntimeException)__bc_t;
            
            throw new UndeclaredThrowableException(__bc_t);
        }
        finally
        {
            Object __bc_rv = __bc_retval;
            postInvoke(_customerContentLookupMethod, __bc_argArray, __bc_rv, __bc_thrown);
        }
        return __bc_retval;
    }
    
    /**
    * Implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.transactionLookup
    */
    public  com.amazon.webservices.awsecommerceservice.x20070514.TransactionLookupResponse transactionLookup(com.amazon.webservices.awsecommerceservice.x20070514.TransactionLookup body_arg) 
    {
        Object [] __bc_argArray = new Object[] { body_arg };
        Throwable __bc_thrown = null;
        Extensible __bc_target = (Extensible)ensureControl();
        com.amazon.webservices.awsecommerceservice.x20070514.TransactionLookupResponse __bc_retval = null;
        
        try
        {
            preInvoke(_transactionLookupMethod, __bc_argArray);
            
            __bc_retval =
            (com.amazon.webservices.awsecommerceservice.x20070514.TransactionLookupResponse)
            __bc_target.invoke(_transactionLookupMethod, __bc_argArray)
            ;
        }
        catch (Throwable __bc_t)
        {
            //
            // All exceptions are caught here, so postInvoke processing has visibility into
            // the exception status.  Errors, RuntimExceptions, or declared checked exceptions will
            // be rethrown.
            //
            __bc_thrown = __bc_t;
            
            if (__bc_t instanceof Error) throw (Error)__bc_t;
            else if (__bc_t instanceof RuntimeException) throw (RuntimeException)__bc_t;
            
            throw new UndeclaredThrowableException(__bc_t);
        }
        finally
        {
            Object __bc_rv = __bc_retval;
            postInvoke(_transactionLookupMethod, __bc_argArray, __bc_rv, __bc_thrown);
        }
        return __bc_retval;
    }
    
    /**
    * Implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.customerContentSearch
    */
    public  com.amazon.webservices.awsecommerceservice.x20070514.CustomerContentSearchResponse customerContentSearch(com.amazon.webservices.awsecommerceservice.x20070514.CustomerContentSearch body_arg) 
    {
        Object [] __bc_argArray = new Object[] { body_arg };
        Throwable __bc_thrown = null;
        Extensible __bc_target = (Extensible)ensureControl();
        com.amazon.webservices.awsecommerceservice.x20070514.CustomerContentSearchResponse __bc_retval = null;
        
        try
        {
            preInvoke(_customerContentSearchMethod, __bc_argArray);
            
            __bc_retval =
            (com.amazon.webservices.awsecommerceservice.x20070514.CustomerContentSearchResponse)
            __bc_target.invoke(_customerContentSearchMethod, __bc_argArray)
            ;
        }
        catch (Throwable __bc_t)
        {
            //
            // All exceptions are caught here, so postInvoke processing has visibility into
            // the exception status.  Errors, RuntimExceptions, or declared checked exceptions will
            // be rethrown.
            //
            __bc_thrown = __bc_t;
            
            if (__bc_t instanceof Error) throw (Error)__bc_t;
            else if (__bc_t instanceof RuntimeException) throw (RuntimeException)__bc_t;
            
            throw new UndeclaredThrowableException(__bc_t);
        }
        finally
        {
            Object __bc_rv = __bc_retval;
            postInvoke(_customerContentSearchMethod, __bc_argArray, __bc_rv, __bc_thrown);
        }
        return __bc_retval;
    }
    
    
    /**
    * A PropertyKey that can be used to access the controlImplementation property of the
    * BaseProperties PropertySet
    */
    public static final PropertyKey ControlImplementationKey = new PropertyKey(org.apache.beehive.controls.api.properties.BaseProperties.class, "controlImplementation");
    
    public synchronized void setControlImplementation(java.lang.String value)
    {
        
        setControlProperty(ControlImplementationKey, value);
    }
    
    public java.lang.String getControlImplementation()
    {
        return (java.lang.String)getControlProperty(ControlImplementationKey);
    }
    
    
    
    
    /**
    * This inner class implements a simple proxy to deliver Callback events
    * back to a register listener.
    */
    protected class CallbackNotifier
    extends org.apache.beehive.controls.runtime.bean.UnicastEventNotifier
    implements es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.Callback, java.io.Serializable
    {
        private static final long serialVersionUID = 1L;
        
        public void onAsyncFailure(java.lang.String arg0, java.lang.Object[] arg1) 
        {
            Throwable __bc_thrown = null;
            
            CallbackNotifier __bc_notifier = (CallbackNotifier)getEventNotifier(es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.Callback.class);
            
            es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.Callback __bc_listener = (es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.Callback)__bc_notifier.getListener();
            
            //
            // If an event listener has been registered, then deliver the event
            //
            if (__bc_listener != null)
            {
                Object [] __bc_argArray = new Object[] {arg0, arg1};
                try
                {
                    __bc_listener.onAsyncFailure(arg0, arg1);
                }
                catch (Throwable __bc_t)
                {
                    //
                    // All exceptions are caught here, so postEvent processing has visibility into
                    // the exception status.  Errors, RuntimExceptions, or declared checked exceptions will
                    // be rethrown.
                    //
                    __bc_thrown = __bc_t;
                    
                    if (__bc_t instanceof Error) throw (Error)__bc_t;
                    else if (__bc_t instanceof RuntimeException) throw (RuntimeException)__bc_t;
                    
                    throw new UndeclaredThrowableException(__bc_t);
                }
            }
        }
        
    }
    
    /**
    * Registers a new listener for Callback events on the bean.
    */
    public synchronized void addCallbackListener(es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.Callback listener)
    throws java.util.TooManyListenersException
    {
        CallbackNotifier __bc_notifier = (CallbackNotifier)getEventNotifier(es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.Callback.class);
        __bc_notifier.addListener(listener);
    }
    
    /**
    * Unregisters an existing listener for Callback events on the bean.
    */
    public synchronized void removeCallbackListener(es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.Callback listener)
    {
        CallbackNotifier __bc_notifier = (CallbackNotifier)getEventNotifier(es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.Callback.class);
        __bc_notifier.removeListener(listener);
    }
    
    /**
    * Returns the  array of registered listeners for Callback events on the bean, or
    * an empty array if no listener has been registered
    */
    public synchronized es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.Callback [] getCallbackListeners()
    {
        CallbackNotifier __bc_notifier = (CallbackNotifier)getEventNotifier(es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.Callback.class);
        es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.Callback [] __bc_listeners = new es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.Callback[__bc_notifier.getListenerCount()];
        __bc_notifier.getListeners(__bc_listeners);
        return __bc_listeners;
    }
    
    /**
    * The _annotCache maintains a lookup cache from AnnotatedElements to an associated
    * PropertyMap.  This enables these maps to be shared across multiple beans.
    */
    static private HashMap __bc_annotCache = new HashMap();
    
    protected Map getPropertyMapCache() { return __bc_annotCache; }
    
    private static final long serialVersionUID = 1L;
}
