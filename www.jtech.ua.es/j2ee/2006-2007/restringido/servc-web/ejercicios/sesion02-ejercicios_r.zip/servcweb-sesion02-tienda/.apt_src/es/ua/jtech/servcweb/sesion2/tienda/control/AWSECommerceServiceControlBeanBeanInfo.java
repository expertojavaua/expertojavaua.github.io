package es.ua.jtech.servcweb.sesion2.tienda.control;

import java.beans.BeanDescriptor;
import java.beans.EventSetDescriptor;
import java.beans.IntrospectionException;
import java.beans.MethodDescriptor;
import java.beans.ParameterDescriptor;
import java.beans.PropertyDescriptor;
import java.beans.PropertyEditor;
import java.lang.reflect.Method;
import java.util.HashMap;

import org.apache.beehive.controls.api.ControlException;
import org.apache.beehive.controls.runtime.bean.BeanPersistenceDelegate;
import org.apache.beehive.controls.runtime.packaging.ControlEventSetDescriptor;

@SuppressWarnings("all")
public class AWSECommerceServiceControlBeanBeanInfo
extends com.bea.control.ServiceControlBeanBeanInfo
{
    static final Method _cartModifyMethod;
    static final Method _cartAddMethod;
    static final Method _multiOperationMethod;
    static final Method _listLookupMethod;
    static final Method _sellerListingSearchMethod;
    static final Method _cartClearMethod;
    static final Method _browseNodeLookupMethod;
    static final Method _itemLookupMethod;
    static final Method _sellerLookupMethod;
    static final Method _similarityLookupMethod;
    static final Method _listSearchMethod;
    static final Method _cartCreateMethod;
    static final Method _cartGetMethod;
    static final Method _itemSearchMethod;
    static final Method _sellerListingLookupMethod;
    static final Method _helpMethod;
    static final Method _customerContentLookupMethod;
    static final Method _transactionLookupMethod;
    static final Method _customerContentSearchMethod;
    static final Method _Callback_onAsyncFailureEvent;
    
    //
    // This HashMap will map from a Method to the array of names for parameters of the
    // method.  This is necessary because parameter name data isn't carried along in the
    // class file, but if available can enable ease of use by referencing parameters by
    // the declared name (vs. by index).
    //
    // This map should be read-only after its initialization in the static block, hence
    // using a plain HashMap is thread-safe.
    //
    static HashMap<Method, String []> _methodParamMap = new HashMap<Method, String []>();
    
    static
    {
        try
        {
            _cartModifyMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("cartModify", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.CartModify.class});
            _methodParamMap.put(_cartModifyMethod, new String [] { "body_arg" });
            _cartAddMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("cartAdd", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.CartAdd.class});
            _methodParamMap.put(_cartAddMethod, new String [] { "body_arg" });
            _multiOperationMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("multiOperation", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.MultiOperation.class});
            _methodParamMap.put(_multiOperationMethod, new String [] { "body_arg" });
            _listLookupMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("listLookup", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.ListLookup.class});
            _methodParamMap.put(_listLookupMethod, new String [] { "body_arg" });
            _sellerListingSearchMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("sellerListingSearch", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.SellerListingSearch.class});
            _methodParamMap.put(_sellerListingSearchMethod, new String [] { "body_arg" });
            _cartClearMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("cartClear", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.CartClear.class});
            _methodParamMap.put(_cartClearMethod, new String [] { "body_arg" });
            _browseNodeLookupMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("browseNodeLookup", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.BrowseNodeLookup.class});
            _methodParamMap.put(_browseNodeLookupMethod, new String [] { "body_arg" });
            _itemLookupMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("itemLookup", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.ItemLookup.class});
            _methodParamMap.put(_itemLookupMethod, new String [] { "body_arg" });
            _sellerLookupMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("sellerLookup", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.SellerLookup.class});
            _methodParamMap.put(_sellerLookupMethod, new String [] { "body_arg" });
            _similarityLookupMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("similarityLookup", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.SimilarityLookup.class});
            _methodParamMap.put(_similarityLookupMethod, new String [] { "body_arg" });
            _listSearchMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("listSearch", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.ListSearch.class});
            _methodParamMap.put(_listSearchMethod, new String [] { "body_arg" });
            _cartCreateMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("cartCreate", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.CartCreate.class});
            _methodParamMap.put(_cartCreateMethod, new String [] { "body_arg" });
            _cartGetMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("cartGet", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.CartGet.class});
            _methodParamMap.put(_cartGetMethod, new String [] { "body_arg" });
            _itemSearchMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("itemSearch", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.ItemSearch.class});
            _methodParamMap.put(_itemSearchMethod, new String [] { "body_arg" });
            _sellerListingLookupMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("sellerListingLookup", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.SellerListingLookup.class});
            _methodParamMap.put(_sellerListingLookupMethod, new String [] { "body_arg" });
            _helpMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("help", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.Help.class});
            _methodParamMap.put(_helpMethod, new String [] { "body_arg" });
            _customerContentLookupMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("customerContentLookup", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.CustomerContentLookup.class});
            _methodParamMap.put(_customerContentLookupMethod, new String [] { "body_arg" });
            _transactionLookupMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("transactionLookup", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.TransactionLookup.class});
            _methodParamMap.put(_transactionLookupMethod, new String [] { "body_arg" });
            _customerContentSearchMethod = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.class.getMethod("customerContentSearch", new Class [] {com.amazon.webservices.awsecommerceservice.x20070514.CustomerContentSearch.class});
            _methodParamMap.put(_customerContentSearchMethod, new String [] { "body_arg" });
            _Callback_onAsyncFailureEvent = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.Callback.class.getMethod("onAsyncFailure", new Class [] {java.lang.String.class, java.lang.Object[].class});
            _methodParamMap.put(_Callback_onAsyncFailureEvent, new String [] { "arg0", "arg1" });
        }
        catch (NoSuchMethodException __bc_nsme)
        {
            throw new ExceptionInInitializerError(__bc_nsme);
        }
    }
    
    /**
    * Default null-arg constructor used to create a new BeanInfo instance
    */
    public AWSECommerceServiceControlBeanBeanInfo()
    {
        super(es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControlBean.class);
    }
    
    /**
    * Protected constructor used if this BeanInfo class is extended.
    */
    protected AWSECommerceServiceControlBeanBeanInfo(Class beanClass)
    {
        super(beanClass);
    }
    
    // java.beans.BeanInfo.getBeanDescriptor
    public BeanDescriptor getBeanDescriptor()
    {
        BeanDescriptor bd = new BeanDescriptor(es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControlBean.class);
        bd.setName( "AWSECommerceServiceControlBean" );
        bd.setDisplayName( "AWSECommerceServiceControlBean" );
        
        //
        // The org.apache.beehive.controls.runtime.bean.BeanPersistenceDelegate class
        // implements the XMLDecode delegation model for all Control JavaBean types. It
        // provides optimized XML persistance based upon the Control runtime architecture.
        // The 'persistenceDelegate' attribute of a BeanDescriptor is used by XMLEncoder to
        // locate a delegate for a particular JavaBean type.
        //
        bd.setValue("persistenceDelegate", new BeanPersistenceDelegate());
        
        return bd;
    }
    
    /**
    * Stores MethodDescriptor descriptors for this bean and its superclasses into
    * an array, starting at the specified index
    */
    protected void initMethodDescriptors(MethodDescriptor [] methodDescriptors, int index)
    throws java.beans.IntrospectionException
    {
        String [] __bc_paramNames;
        ParameterDescriptor [] __bc_paramDescriptors;
        MethodDescriptor md;
        
        //
        // Declare MethodDescriptor for cartModify(body_arg)
        //
        __bc_paramNames = _methodParamMap.get(_cartModifyMethod);
        __bc_paramDescriptors = new ParameterDescriptor[__bc_paramNames.length];
        for (int j = 0; j < __bc_paramNames.length; j++)
        {
            __bc_paramDescriptors[j] = new ParameterDescriptor();
            __bc_paramDescriptors[j].setName(__bc_paramNames[j]);
            __bc_paramDescriptors[j].setDisplayName(__bc_paramNames[j]);
        }
        md = new MethodDescriptor(_cartModifyMethod, __bc_paramDescriptors);
        methodDescriptors[index++] = md;
        
        //
        // Declare MethodDescriptor for cartAdd(body_arg)
        //
        __bc_paramNames = _methodParamMap.get(_cartAddMethod);
        __bc_paramDescriptors = new ParameterDescriptor[__bc_paramNames.length];
        for (int j = 0; j < __bc_paramNames.length; j++)
        {
            __bc_paramDescriptors[j] = new ParameterDescriptor();
            __bc_paramDescriptors[j].setName(__bc_paramNames[j]);
            __bc_paramDescriptors[j].setDisplayName(__bc_paramNames[j]);
        }
        md = new MethodDescriptor(_cartAddMethod, __bc_paramDescriptors);
        methodDescriptors[index++] = md;
        
        //
        // Declare MethodDescriptor for multiOperation(body_arg)
        //
        __bc_paramNames = _methodParamMap.get(_multiOperationMethod);
        __bc_paramDescriptors = new ParameterDescriptor[__bc_paramNames.length];
        for (int j = 0; j < __bc_paramNames.length; j++)
        {
            __bc_paramDescriptors[j] = new ParameterDescriptor();
            __bc_paramDescriptors[j].setName(__bc_paramNames[j]);
            __bc_paramDescriptors[j].setDisplayName(__bc_paramNames[j]);
        }
        md = new MethodDescriptor(_multiOperationMethod, __bc_paramDescriptors);
        methodDescriptors[index++] = md;
        
        //
        // Declare MethodDescriptor for listLookup(body_arg)
        //
        __bc_paramNames = _methodParamMap.get(_listLookupMethod);
        __bc_paramDescriptors = new ParameterDescriptor[__bc_paramNames.length];
        for (int j = 0; j < __bc_paramNames.length; j++)
        {
            __bc_paramDescriptors[j] = new ParameterDescriptor();
            __bc_paramDescriptors[j].setName(__bc_paramNames[j]);
            __bc_paramDescriptors[j].setDisplayName(__bc_paramNames[j]);
        }
        md = new MethodDescriptor(_listLookupMethod, __bc_paramDescriptors);
        methodDescriptors[index++] = md;
        
        //
        // Declare MethodDescriptor for sellerListingSearch(body_arg)
        //
        __bc_paramNames = _methodParamMap.get(_sellerListingSearchMethod);
        __bc_paramDescriptors = new ParameterDescriptor[__bc_paramNames.length];
        for (int j = 0; j < __bc_paramNames.length; j++)
        {
            __bc_paramDescriptors[j] = new ParameterDescriptor();
            __bc_paramDescriptors[j].setName(__bc_paramNames[j]);
            __bc_paramDescriptors[j].setDisplayName(__bc_paramNames[j]);
        }
        md = new MethodDescriptor(_sellerListingSearchMethod, __bc_paramDescriptors);
        methodDescriptors[index++] = md;
        
        //
        // Declare MethodDescriptor for cartClear(body_arg)
        //
        __bc_paramNames = _methodParamMap.get(_cartClearMethod);
        __bc_paramDescriptors = new ParameterDescriptor[__bc_paramNames.length];
        for (int j = 0; j < __bc_paramNames.length; j++)
        {
            __bc_paramDescriptors[j] = new ParameterDescriptor();
            __bc_paramDescriptors[j].setName(__bc_paramNames[j]);
            __bc_paramDescriptors[j].setDisplayName(__bc_paramNames[j]);
        }
        md = new MethodDescriptor(_cartClearMethod, __bc_paramDescriptors);
        methodDescriptors[index++] = md;
        
        //
        // Declare MethodDescriptor for browseNodeLookup(body_arg)
        //
        __bc_paramNames = _methodParamMap.get(_browseNodeLookupMethod);
        __bc_paramDescriptors = new ParameterDescriptor[__bc_paramNames.length];
        for (int j = 0; j < __bc_paramNames.length; j++)
        {
            __bc_paramDescriptors[j] = new ParameterDescriptor();
            __bc_paramDescriptors[j].setName(__bc_paramNames[j]);
            __bc_paramDescriptors[j].setDisplayName(__bc_paramNames[j]);
        }
        md = new MethodDescriptor(_browseNodeLookupMethod, __bc_paramDescriptors);
        methodDescriptors[index++] = md;
        
        //
        // Declare MethodDescriptor for itemLookup(body_arg)
        //
        __bc_paramNames = _methodParamMap.get(_itemLookupMethod);
        __bc_paramDescriptors = new ParameterDescriptor[__bc_paramNames.length];
        for (int j = 0; j < __bc_paramNames.length; j++)
        {
            __bc_paramDescriptors[j] = new ParameterDescriptor();
            __bc_paramDescriptors[j].setName(__bc_paramNames[j]);
            __bc_paramDescriptors[j].setDisplayName(__bc_paramNames[j]);
        }
        md = new MethodDescriptor(_itemLookupMethod, __bc_paramDescriptors);
        methodDescriptors[index++] = md;
        
        //
        // Declare MethodDescriptor for sellerLookup(body_arg)
        //
        __bc_paramNames = _methodParamMap.get(_sellerLookupMethod);
        __bc_paramDescriptors = new ParameterDescriptor[__bc_paramNames.length];
        for (int j = 0; j < __bc_paramNames.length; j++)
        {
            __bc_paramDescriptors[j] = new ParameterDescriptor();
            __bc_paramDescriptors[j].setName(__bc_paramNames[j]);
            __bc_paramDescriptors[j].setDisplayName(__bc_paramNames[j]);
        }
        md = new MethodDescriptor(_sellerLookupMethod, __bc_paramDescriptors);
        methodDescriptors[index++] = md;
        
        //
        // Declare MethodDescriptor for similarityLookup(body_arg)
        //
        __bc_paramNames = _methodParamMap.get(_similarityLookupMethod);
        __bc_paramDescriptors = new ParameterDescriptor[__bc_paramNames.length];
        for (int j = 0; j < __bc_paramNames.length; j++)
        {
            __bc_paramDescriptors[j] = new ParameterDescriptor();
            __bc_paramDescriptors[j].setName(__bc_paramNames[j]);
            __bc_paramDescriptors[j].setDisplayName(__bc_paramNames[j]);
        }
        md = new MethodDescriptor(_similarityLookupMethod, __bc_paramDescriptors);
        methodDescriptors[index++] = md;
        
        //
        // Declare MethodDescriptor for listSearch(body_arg)
        //
        __bc_paramNames = _methodParamMap.get(_listSearchMethod);
        __bc_paramDescriptors = new ParameterDescriptor[__bc_paramNames.length];
        for (int j = 0; j < __bc_paramNames.length; j++)
        {
            __bc_paramDescriptors[j] = new ParameterDescriptor();
            __bc_paramDescriptors[j].setName(__bc_paramNames[j]);
            __bc_paramDescriptors[j].setDisplayName(__bc_paramNames[j]);
        }
        md = new MethodDescriptor(_listSearchMethod, __bc_paramDescriptors);
        methodDescriptors[index++] = md;
        
        //
        // Declare MethodDescriptor for cartCreate(body_arg)
        //
        __bc_paramNames = _methodParamMap.get(_cartCreateMethod);
        __bc_paramDescriptors = new ParameterDescriptor[__bc_paramNames.length];
        for (int j = 0; j < __bc_paramNames.length; j++)
        {
            __bc_paramDescriptors[j] = new ParameterDescriptor();
            __bc_paramDescriptors[j].setName(__bc_paramNames[j]);
            __bc_paramDescriptors[j].setDisplayName(__bc_paramNames[j]);
        }
        md = new MethodDescriptor(_cartCreateMethod, __bc_paramDescriptors);
        methodDescriptors[index++] = md;
        
        //
        // Declare MethodDescriptor for cartGet(body_arg)
        //
        __bc_paramNames = _methodParamMap.get(_cartGetMethod);
        __bc_paramDescriptors = new ParameterDescriptor[__bc_paramNames.length];
        for (int j = 0; j < __bc_paramNames.length; j++)
        {
            __bc_paramDescriptors[j] = new ParameterDescriptor();
            __bc_paramDescriptors[j].setName(__bc_paramNames[j]);
            __bc_paramDescriptors[j].setDisplayName(__bc_paramNames[j]);
        }
        md = new MethodDescriptor(_cartGetMethod, __bc_paramDescriptors);
        methodDescriptors[index++] = md;
        
        //
        // Declare MethodDescriptor for itemSearch(body_arg)
        //
        __bc_paramNames = _methodParamMap.get(_itemSearchMethod);
        __bc_paramDescriptors = new ParameterDescriptor[__bc_paramNames.length];
        for (int j = 0; j < __bc_paramNames.length; j++)
        {
            __bc_paramDescriptors[j] = new ParameterDescriptor();
            __bc_paramDescriptors[j].setName(__bc_paramNames[j]);
            __bc_paramDescriptors[j].setDisplayName(__bc_paramNames[j]);
        }
        md = new MethodDescriptor(_itemSearchMethod, __bc_paramDescriptors);
        methodDescriptors[index++] = md;
        
        //
        // Declare MethodDescriptor for sellerListingLookup(body_arg)
        //
        __bc_paramNames = _methodParamMap.get(_sellerListingLookupMethod);
        __bc_paramDescriptors = new ParameterDescriptor[__bc_paramNames.length];
        for (int j = 0; j < __bc_paramNames.length; j++)
        {
            __bc_paramDescriptors[j] = new ParameterDescriptor();
            __bc_paramDescriptors[j].setName(__bc_paramNames[j]);
            __bc_paramDescriptors[j].setDisplayName(__bc_paramNames[j]);
        }
        md = new MethodDescriptor(_sellerListingLookupMethod, __bc_paramDescriptors);
        methodDescriptors[index++] = md;
        
        //
        // Declare MethodDescriptor for help(body_arg)
        //
        __bc_paramNames = _methodParamMap.get(_helpMethod);
        __bc_paramDescriptors = new ParameterDescriptor[__bc_paramNames.length];
        for (int j = 0; j < __bc_paramNames.length; j++)
        {
            __bc_paramDescriptors[j] = new ParameterDescriptor();
            __bc_paramDescriptors[j].setName(__bc_paramNames[j]);
            __bc_paramDescriptors[j].setDisplayName(__bc_paramNames[j]);
        }
        md = new MethodDescriptor(_helpMethod, __bc_paramDescriptors);
        methodDescriptors[index++] = md;
        
        //
        // Declare MethodDescriptor for customerContentLookup(body_arg)
        //
        __bc_paramNames = _methodParamMap.get(_customerContentLookupMethod);
        __bc_paramDescriptors = new ParameterDescriptor[__bc_paramNames.length];
        for (int j = 0; j < __bc_paramNames.length; j++)
        {
            __bc_paramDescriptors[j] = new ParameterDescriptor();
            __bc_paramDescriptors[j].setName(__bc_paramNames[j]);
            __bc_paramDescriptors[j].setDisplayName(__bc_paramNames[j]);
        }
        md = new MethodDescriptor(_customerContentLookupMethod, __bc_paramDescriptors);
        methodDescriptors[index++] = md;
        
        //
        // Declare MethodDescriptor for transactionLookup(body_arg)
        //
        __bc_paramNames = _methodParamMap.get(_transactionLookupMethod);
        __bc_paramDescriptors = new ParameterDescriptor[__bc_paramNames.length];
        for (int j = 0; j < __bc_paramNames.length; j++)
        {
            __bc_paramDescriptors[j] = new ParameterDescriptor();
            __bc_paramDescriptors[j].setName(__bc_paramNames[j]);
            __bc_paramDescriptors[j].setDisplayName(__bc_paramNames[j]);
        }
        md = new MethodDescriptor(_transactionLookupMethod, __bc_paramDescriptors);
        methodDescriptors[index++] = md;
        
        //
        // Declare MethodDescriptor for customerContentSearch(body_arg)
        //
        __bc_paramNames = _methodParamMap.get(_customerContentSearchMethod);
        __bc_paramDescriptors = new ParameterDescriptor[__bc_paramNames.length];
        for (int j = 0; j < __bc_paramNames.length; j++)
        {
            __bc_paramDescriptors[j] = new ParameterDescriptor();
            __bc_paramDescriptors[j].setName(__bc_paramNames[j]);
            __bc_paramDescriptors[j].setDisplayName(__bc_paramNames[j]);
        }
        md = new MethodDescriptor(_customerContentSearchMethod, __bc_paramDescriptors);
        methodDescriptors[index++] = md;
        
        
        //
        // Add method descriptors from parent BeanInfo
        //
        super.initMethodDescriptors(methodDescriptors, index);
    }
    
    public MethodDescriptor [] getMethodDescriptors()
    {
        MethodDescriptor [] __bc_methodDescriptors = new MethodDescriptor[53];
        try
        {
            initMethodDescriptors(__bc_methodDescriptors, 0);
        }
        catch (java.beans.IntrospectionException __bc_ie)
        {
            throw new ControlException("Unable to create MethodDescriptor", __bc_ie);
        }
        return __bc_methodDescriptors;
    }
    
    /**
    * Stores PropertyDescriptor descriptors for this bean and its superclasses into
    * an array, starting at the specified index
    */
    protected void initPropertyDescriptors(PropertyDescriptor [] propDescriptors, int index)
    throws java.beans.IntrospectionException
    {
        PropertyDescriptor pd;
        
        pd = new PropertyDescriptor( "controlImplementation" , es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControlBean.class, "getControlImplementation", "setControlImplementation");
        propDescriptors[index++] = pd;
        
        
        //
        // Add property descriptors from parent BeanInfo
        //
        super.initPropertyDescriptors(propDescriptors, index);
    }
    
    // java.beans.BeanInfo.getPropertyDescriptors
    public PropertyDescriptor [] getPropertyDescriptors()
    {
        PropertyDescriptor [] __bc_propDescriptors = new PropertyDescriptor[20];
        try
        {
            initPropertyDescriptors(__bc_propDescriptors, 0);
        }
        catch (java.beans.IntrospectionException __bc_ie)
        {
            throw new ControlException("Unable to create PropertyDescriptor", __bc_ie);
        }
        return __bc_propDescriptors;
    }
    
    //
    // Adds the EventDescriptors for Callback to the EventDescriptor array, starting
    // at index
    //
    protected void initCallbackEvents(MethodDescriptor [] eventDescriptors, int index)
    {
        String [] __bc_paramNames;
        ParameterDescriptor [] __bc_paramDescriptors;
        MethodDescriptor md;
        
        //
        // Build a method descriptor for each event method in the event set
        //
        
        //
        // Declare MethodDescriptor for onAsyncFailure(arg0, arg1)
        //
        __bc_paramNames = _methodParamMap.get(_Callback_onAsyncFailureEvent);
        __bc_paramDescriptors = new ParameterDescriptor[__bc_paramNames.length];
        for (int k = 0; k < __bc_paramNames.length; k++)
        {
            __bc_paramDescriptors[k] = new ParameterDescriptor();
            __bc_paramDescriptors[k].setName(__bc_paramNames[k]);
            __bc_paramDescriptors[k].setDisplayName(__bc_paramNames[k]);
        }
        md = new MethodDescriptor(_Callback_onAsyncFailureEvent, __bc_paramDescriptors);
        eventDescriptors[index++] = md;
        
    }
    
    
    protected void initEventSetDescriptors(EventSetDescriptor [] eventSetDescriptors, int index)
    throws java.beans.IntrospectionException
    {
        MethodDescriptor [] __bc_eventDescriptors;
        EventSetDescriptor __bc_esd;
        Method __bc_addListener, __bc_removeListener, __bc_getListeners;
        Class __bc_eventIntf;
        
        __bc_eventIntf = es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl.Callback.class;
        
        //
        // Find the add/remove listener methods
        //
        try
        {
            __bc_addListener =
            es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControlBean.class.getDeclaredMethod("addCallbackListener",
            new Class [] { __bc_eventIntf });
            __bc_removeListener =
            es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControlBean.class.getDeclaredMethod("removeCallbackListener",
            new Class [] { __bc_eventIntf });
            __bc_getListeners =
            es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControlBean.class.getDeclaredMethod("getCallbackListeners",
            new Class [] {});
        }
        catch (NoSuchMethodException __bc_nsme)
        {
            // This is moderately lame, but there is no checked exception declared for this
            // method.  This could only happen as a result of a mismatch between bean class
            // and introspector codegen.
            throw new ControlException("Unable to locate listener method", __bc_nsme);
        }
        
        //
        // Build the MethodDescriptor array contain all event set events
        //
        __bc_eventDescriptors = new MethodDescriptor[1];
        initCallbackEvents(__bc_eventDescriptors, 0);
        
        try
        {
            __bc_esd = new ControlEventSetDescriptor(localizeString("callback"),
            __bc_eventIntf, __bc_eventDescriptors, __bc_addListener, __bc_removeListener, __bc_getListeners);
            __bc_esd.setUnicast(true);
        }
        catch (IntrospectionException __bc_ie)
        {
            throw new ControlException("Unable to create EventDescriptor", __bc_ie);
        }
        eventSetDescriptors[index++] = __bc_esd;
        
        
        //
        // Add event set descriptors from parent BeanInfo
        //
        super.initEventSetDescriptors(eventSetDescriptors, index);
    }
    
    // java.beans.BeanInfo.getEventSetDescriptors
    public EventSetDescriptor [] getEventSetDescriptors()
    {
        EventSetDescriptor [] __bc_eventSetDescriptors = new EventSetDescriptor[1];
        try
        {
            initEventSetDescriptors(__bc_eventSetDescriptors, 0);
        }
        catch (java.beans.IntrospectionException __bc_ie)
        {
            throw new ControlException("Unable to create EventSetDescriptor", __bc_ie);
        }
        return __bc_eventSetDescriptors;
    }
}
