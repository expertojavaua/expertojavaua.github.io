
package es.ua.jtech.servcweb.sesion2.tienda.sw;

import java.lang.reflect.Field;
import org.apache.beehive.controls.api.ControlException;
import org.apache.beehive.controls.api.bean.Controls;
import org.apache.beehive.controls.api.versioning.VersionRequired;
import org.apache.beehive.controls.api.context.ControlBeanContext;
import org.apache.beehive.controls.runtime.bean.EventAdaptor;
import org.apache.beehive.controls.runtime.bean.AdaptorPersistenceDelegate;

@SuppressWarnings("all")
public class TiendaDvdSWClientInitializer
extends org.apache.beehive.controls.runtime.bean.ClientInitializer
{
    static final Field _AWSECommerceServiceControl1Field;
    static
    {
        try
        {
            _AWSECommerceServiceControl1Field = es.ua.jtech.servcweb.sesion2.tienda.sw.TiendaDvdSW.class.getDeclaredField("AWSECommerceServiceControl1");
            _AWSECommerceServiceControl1Field.setAccessible(true);
        }
        catch (NoSuchFieldException __bc_nsfe)
        {
            throw new ExceptionInInitializerError(__bc_nsfe);
        }
    }
    
    
    private static void initializeFields(ControlBeanContext cbc,
    es.ua.jtech.servcweb.sesion2.tienda.sw.TiendaDvdSW client)
    {
        try
        {
            String __bc_id;
            //
            // Initialize any nested controls used by the client
            //
            __bc_id = "AWSECommerceServiceControl1";
            es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControlBean _AWSECommerceServiceControl1 = (cbc == null ? null : (es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControlBean)cbc.getBean(__bc_id));
            if (_AWSECommerceServiceControl1 == null)
            _AWSECommerceServiceControl1 = (es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControlBean) Controls.instantiate(es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControlBean.class, getAnnotationMap(cbc, _AWSECommerceServiceControl1Field), cbc, __bc_id );
            
            
            _AWSECommerceServiceControl1Field.set(client, _AWSECommerceServiceControl1);
        }
        catch (RuntimeException __bc_re) { throw __bc_re; }
        catch (Exception __bc_e)
        {
            __bc_e.printStackTrace();
            throw new ControlException("Initializer failure", __bc_e);
        }
    }
    
    public static void initialize(ControlBeanContext cbc, es.ua.jtech.servcweb.sesion2.tienda.sw.TiendaDvdSW client)
    {
        
        initializeFields( cbc, client );
    }
}
