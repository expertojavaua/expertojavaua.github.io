package es.ua.jtech.servcweb.sesion2.tienda.control;
import com.bea.control.ServiceControl;

import org.apache.beehive.controls.api.events.EventSet;
import org.apache.beehive.controls.api.bean.ControlExtension;

@ServiceControl.Location(urls = {"http://soap.amazon.com/onca/soap?Service=AWSECommerceService"})
@ServiceControl.HttpSoapProtocol
@ServiceControl.SOAPBinding(style = ServiceControl.SOAPBinding.Style.DOCUMENT, use = ServiceControl.SOAPBinding.Use.LITERAL, parameterStyle = ServiceControl.SOAPBinding.ParameterStyle.BARE)
@ServiceControl.WSDL(resourcePath = "es/ua/jtech/servcweb/sesion2/tienda/control/AWSECommerceService.wsdl", service = "AWSECommerceService")
@ControlExtension
public interface AWSECommerceServiceControl extends ServiceControl
{
    static final long serialVersionUID = 1L;

    public com.amazon.webservices.awsecommerceservice.x20070514.BrowseNodeLookupResponse browseNodeLookup(com.amazon.webservices.awsecommerceservice.x20070514.BrowseNodeLookup body_arg);

    public com.amazon.webservices.awsecommerceservice.x20070514.CartAddResponse cartAdd(com.amazon.webservices.awsecommerceservice.x20070514.CartAdd body_arg);

    public com.amazon.webservices.awsecommerceservice.x20070514.CartClearResponse cartClear(com.amazon.webservices.awsecommerceservice.x20070514.CartClear body_arg);

    public com.amazon.webservices.awsecommerceservice.x20070514.CartCreateResponse cartCreate(com.amazon.webservices.awsecommerceservice.x20070514.CartCreate body_arg);

    public com.amazon.webservices.awsecommerceservice.x20070514.CartGetResponse cartGet(com.amazon.webservices.awsecommerceservice.x20070514.CartGet body_arg);

    public com.amazon.webservices.awsecommerceservice.x20070514.CartModifyResponse cartModify(com.amazon.webservices.awsecommerceservice.x20070514.CartModify body_arg);

    public com.amazon.webservices.awsecommerceservice.x20070514.CustomerContentLookupResponse customerContentLookup(com.amazon.webservices.awsecommerceservice.x20070514.CustomerContentLookup body_arg);

    public com.amazon.webservices.awsecommerceservice.x20070514.CustomerContentSearchResponse customerContentSearch(com.amazon.webservices.awsecommerceservice.x20070514.CustomerContentSearch body_arg);

    public com.amazon.webservices.awsecommerceservice.x20070514.HelpResponse help(com.amazon.webservices.awsecommerceservice.x20070514.Help body_arg);

    public com.amazon.webservices.awsecommerceservice.x20070514.ItemLookupResponse itemLookup(com.amazon.webservices.awsecommerceservice.x20070514.ItemLookup body_arg);

    public com.amazon.webservices.awsecommerceservice.x20070514.ItemSearchResponse itemSearch(com.amazon.webservices.awsecommerceservice.x20070514.ItemSearch body_arg);

    public com.amazon.webservices.awsecommerceservice.x20070514.ListLookupResponse listLookup(com.amazon.webservices.awsecommerceservice.x20070514.ListLookup body_arg);

    public com.amazon.webservices.awsecommerceservice.x20070514.ListSearchResponse listSearch(com.amazon.webservices.awsecommerceservice.x20070514.ListSearch body_arg);

    public com.amazon.webservices.awsecommerceservice.x20070514.MultiOperationResponse multiOperation(com.amazon.webservices.awsecommerceservice.x20070514.MultiOperation body_arg);

    public com.amazon.webservices.awsecommerceservice.x20070514.SellerListingLookupResponse sellerListingLookup(com.amazon.webservices.awsecommerceservice.x20070514.SellerListingLookup body_arg);

    public com.amazon.webservices.awsecommerceservice.x20070514.SellerListingSearchResponse sellerListingSearch(com.amazon.webservices.awsecommerceservice.x20070514.SellerListingSearch body_arg);

    public com.amazon.webservices.awsecommerceservice.x20070514.SellerLookupResponse sellerLookup(com.amazon.webservices.awsecommerceservice.x20070514.SellerLookup body_arg);

    public com.amazon.webservices.awsecommerceservice.x20070514.SimilarityLookupResponse similarityLookup(com.amazon.webservices.awsecommerceservice.x20070514.SimilarityLookup body_arg);

    public com.amazon.webservices.awsecommerceservice.x20070514.TransactionLookupResponse transactionLookup(com.amazon.webservices.awsecommerceservice.x20070514.TransactionLookup body_arg);

   /** This event set interface provides support for the onAsyncFailure event.
    */
   @EventSet(unicast=true)
   public interface Callback extends ServiceControl.Callback {};
}