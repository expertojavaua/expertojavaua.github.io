package es.ua.jtech.servcweb.sesion2.tienda.sw;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.apache.beehive.controls.api.bean.Control;

import com.amazon.webservices.awsecommerceservice.x20070514.ItemAttributes;
import com.amazon.webservices.awsecommerceservice.x20070514.ItemSearch;
import com.amazon.webservices.awsecommerceservice.x20070514.ItemSearchRequest;
import com.amazon.webservices.awsecommerceservice.x20070514.ItemSearchResponse;
import com.amazon.webservices.awsecommerceservice.x20070514.Item_Element;
import com.amazon.webservices.awsecommerceservice.x20070514.Items;

import es.ua.jtech.servcweb.sesion2.tienda.control.AWSECommerceServiceControl;
import es.ua.jtech.servcweb.sesion2.tienda.to.DatosPelicula;

@WebService
public class TiendaDvdSW {

	final static DatosPelicula[] peliculas = {
	    new DatosPelicula("Mulholland Drive", "David Lynch", 26.96f),
	    new DatosPelicula("Carretera perdida", "David Lynch", 18.95f),
	    new DatosPelicula("Twin Peaks", "David Lynch", 46.95f),
	    new DatosPelicula("Telefono rojo", "Stanley Kubrick", 15.95f),
	    new DatosPelicula("Barry Lyndon", "Stanley Kubrick", 24.95f),
	    new DatosPelicula("La naranja mec�nica", "Stanley Kubrick", 22.95f) 
	};
	@Control
	private AWSECommerceServiceControl AWSECommerceServiceControl1;
	
	@WebMethod
	public DatosPelicula [] buscaDirector(String director) {
		director = director.toLowerCase();
		   
		ArrayList<DatosPelicula> list = new ArrayList<DatosPelicula>();
		   
		for (DatosPelicula pelicula : peliculas) {
		  if (pelicula.getDirector().toLowerCase().indexOf(director) != -1) {
		    list.add(pelicula);
		  }
		}
		   
		DatosPelicula [] result = new DatosPelicula[list.size()];
		list.toArray(result);
		   
		return result;
	}

	@WebMethod
	public DatosPelicula [] buscaDirectorImportacion(String director) {
		ItemSearch itemSearch = new ItemSearch();
		itemSearch.setAWSAccessKeyId("15JCR9XWMPTGV91JC1R2");

		ItemSearchRequest shared = new ItemSearchRequest();
		shared.setSearchIndex("DVD");
		shared.setDirector(director);
		shared.setResponseGroup(new String [] {"Offers", "Medium"});

		itemSearch.setShared(shared);
		
		ItemSearchResponse response = AWSECommerceServiceControl1.itemSearch(itemSearch);

		Items [] listaResultados = response.getItems();
		
		ArrayList<DatosPelicula> listaPeliculas = new ArrayList<DatosPelicula>();
		
		for(Items resultado: listaResultados) {
		    Item_Element [] listaArticulos = resultado.getItem();
		    for(Item_Element articulo: listaArticulos) {
		        ItemAttributes atributos = articulo.getItemAttributes();

		        DatosPelicula pelicula = new DatosPelicula();
		        
		        pelicula.setTitulo(atributos.getTitle());

		        String listaDirectores = "";
		        String [] directores = atributos.getDirector();
		        if(directores!=null) {
			        for(String nombreDirector: directores) {
			        	listaDirectores += nombreDirector + "; ";
			        }		        	
			        pelicula.setDirector(listaDirectores);
		        } else {
		        	pelicula.setDirector(director);
		        }

		        pelicula.setPrecio(atributos.getListPrice()!=null?
		                atributos.getListPrice().getAmount().floatValue()/100:
		                -1);
		        
		        listaPeliculas.add(pelicula);
		    }
		}
		
		DatosPelicula [] resultado = new DatosPelicula[listaPeliculas.size()];
		listaPeliculas.toArray(resultado);
		
		return resultado;
	}
}