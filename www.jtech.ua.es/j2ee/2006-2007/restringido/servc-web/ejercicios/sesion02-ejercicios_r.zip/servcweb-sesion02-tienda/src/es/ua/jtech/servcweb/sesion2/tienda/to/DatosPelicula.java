package es.ua.jtech.servcweb.sesion2.tienda.to;

public class DatosPelicula {
	  private String titulo;
	  private String director;
	  private float precio;
	   
	  public DatosPelicula() {}
	   
	  public DatosPelicula(String titulo, String director, float precio) {
	    this.titulo = titulo;
	    this.director = director;
	    this.precio = precio;
	  }

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	  
	}
