package es.ua.jtech.servdaplic.jdbc;

import javax.sql.DataSource;
import java.sql.*;
import javax.naming.*;
import java.util.Hashtable;

public class MuestraUsuarios {
	private DataSource ds;
	
	public void getDataSource() {
		if (ds == null) {
			// Aqu� es donde ten�is que obtener la fuente de datos del servidor
		}
	}
	
	/**
	 * Muestra un listado de los usuarios en nuestra aplicación
	 */
	public void doListado () {
		try {
			Connection con = ds.getConnection(); 
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("Select * from usuarios");
			System.out.println("Login\t FechaNac\t Localidad");
			while (rs.next()) {
				System.out.println(rs.getString("login")+"\t "+rs.getDate("fechaNac")+"\t "+
						rs.getString("localidad"));
			}
			con.close();
		}
		catch(SQLException sqle) {System.out.println(sqle);}
	}
	
    public static void main(String [] args) {
    	MuestraUsuarios ls = new MuestraUsuarios();
    	
    	ls.getDataSource();
    	ls.doListado();
    }
}
