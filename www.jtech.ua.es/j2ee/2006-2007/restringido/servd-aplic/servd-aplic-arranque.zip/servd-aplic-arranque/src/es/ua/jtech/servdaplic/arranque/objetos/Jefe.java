package es.ua.jtech.servdaplic.arranque.objetos;

public class Jefe implements java.io.Serializable {
	private static final long serialVersionUID = 6605847701047663306L;
	String name;

	public Jefe() {
		name = "Miguel Cazorla";
	}

	public String getName() {
		return name;
	}

}