package es.ua.jtech.servdaplic.arranque.objetos;

public class Presidente implements java.io.Serializable {
	private static final long serialVersionUID = 7217948043113606963L;
	String name;

	public Presidente() {
		name = "Domingo Gallardo";
	}

}