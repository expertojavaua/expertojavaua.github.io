package es.ua.jtech.servdaplic.arranque.objetos;

public class Propietario implements java.io.Serializable {
	private static final long serialVersionUID = 3889002844762228344L;
	String name;

	public Propietario() {
		name = "Otto Colomina";
	}

}