package es.ua.jtech.servdaplic.arranque.startup;

import es.ua.jtech.servdaplic.arranque.objetos.*;
import javax.naming.InitialContext;
import javax.naming.Context;


public class bindObjects  {
	public bindObjects() {}

	public static void main (String[] params)
	{
		System.out.println("");
		System.out.println("");
		System.out.println("Nombre de la clase de arranque: bindObjects");
		System.out.println("");
		System.out.println("");

		Jefe jefe = new Jefe();
		Propietario propietario = new Propietario();
		Presidente presidente = new Presidente();

		try
		{
			InitialContext ic = new InitialContext();
			ic.createSubcontext("com");

			Context context = (Context) ic.lookup("com");
			context.createSubcontext("bea");

			context = (Context) ic.lookup("com.bea");
			context.createSubcontext("ejecutivos");

			context = (Context) ic.lookup("com.bea.ejecutivos");

			context.bind("Ejecutivo en jefe", jefe);
			context.bind("Propietario", propietario);
			context.bind("Presidente", presidente);

		} catch (Exception e) {
			System.out.println("Ocurrio el error: " + e);
		}
	}
}