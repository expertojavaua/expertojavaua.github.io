package es.ua.jtech.servdweb.sesion1.cliente;

import java.net.*;
import java.io.*;

class CliHTTP {
	
   public static final int DEFAULT_PORT = 80;	
   private Socket conexion;
   private InputStream respuesta;
   private OutputStream peticion;
  
   
   public CliHTTP(String servidor, int puerto) 
                      throws UnknownHostException, IOException {
   	  conexion = new Socket(servidor, puerto);
   	  peticion = conexion.getOutputStream();
   	  respuesta = conexion.getInputStream();
   }
   
   		
   public CliHTTP(String servidor) throws UnknownHostException, IOException {
      this(servidor,DEFAULT_PORT);         	
   }
   
   
   public void enviarPeticion(String pet) throws IOException {
   	  int i;
   	  
   	  for(i=0;i<pet.length();i++)
         peticion.write(pet.charAt(i));
   	  peticion.flush();
   }
   
   public String recibirRespuesta() throws IOException {
   	  StringBuffer buf;
   	  int leido;
   	  
   	  buf=new StringBuffer();
   	  leido = respuesta.read();
   	  while (leido !=-1) { 
   	  	 buf.append((char)leido);
   	     leido = respuesta.read();
   	  }
   	  return buf.toString();	 	   	  	   	  
   }		
}	