package es.ua.jtech.servdweb.sesion1.cliente;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.io.*;
import java.net.*;

class ClienteHTTP extends JFrame implements ActionListener {
   
   private final static String DEFAULT_PORT="80";
   private JTextArea textoPeticion, textoRespuesta;
   private JTextField textoHost, textoPuerto;
   private JButton botonEnviar, botonConectar;
   private JLabel etiqCon;
   CliHTTP conexion;
      	   
   public ClienteHTTP() {
      super("Cliente HTTP");      
      crearGUI();
      setVisible(true);      	
   }
   
   
   private void crearGUI() {
      Dimension tamPantalla;
      JPanel panelGlobal;
      Container panelCon, boxHost, boxPuerto, boxCon;
            
      //hacer que la ventana ocupe la mitad del ancho y alto de la pantalla
      tamPantalla = Toolkit.getDefaultToolkit().getScreenSize();
      setSize(tamPantalla.width/2, tamPantalla.height/2);
      
      //hacer que se salga de la aplicaci�n cuando se cierre la ventana
      addWindowListener(new WindowAdapter() {
      	                      public void windowClosing(WindowEvent e) {
      	                      	 System.exit(0);
      	                      }
      	                    });	
      	                    
      //panel para datos de la conexion
      panelCon = Box.createVerticalBox();
      boxHost = Box.createHorizontalBox();
      boxHost.add(new JLabel("Host:"));
      textoHost = new JTextField(); 
      boxHost.add(textoHost);
      boxPuerto = Box.createHorizontalBox();
      boxPuerto.add(new JLabel("Puerto:"));
      textoPuerto = new JTextField(DEFAULT_PORT);
      boxPuerto.add(textoPuerto);
      boxCon = Box.createHorizontalBox();
      botonConectar = new JButton("Conectar");
      boxCon.add(botonConectar);
      etiqCon = new JLabel("");
      panelCon.add(boxHost);
      panelCon.add(boxPuerto);
      panelCon.add(boxCon);
      panelCon.add(etiqCon);
      
      
      Border borde = BorderFactory.createEtchedBorder();
      JPanel panelES = new JPanel();
      panelES.setLayout(new BoxLayout(panelES, BoxLayout.Y_AXIS));
      
      textoPeticion = new JTextArea();
      textoPeticion.setRows(6);
      textoPeticion.setEnabled(false);
      JScrollPane sc = new JScrollPane(textoPeticion);
      sc.setBorder(BorderFactory.createTitledBorder(borde, "Peticion del cliente"));
      panelES.add(sc);
      
      botonEnviar = new JButton("Enviar");
      botonEnviar.setEnabled(false);
      Container boxEnviar = Box.createHorizontalBox();
      boxEnviar.add(botonEnviar);
	  panelES.add(boxEnviar);      
      
      textoRespuesta = new JTextArea();
      textoRespuesta.setRows(6);
      textoRespuesta.setEditable(false);
      sc = new JScrollPane(textoRespuesta);
      sc.setBorder(BorderFactory.createTitledBorder(borde, "Respuesta del servidor"));
      panelES.add(sc);
      
      //crear contenedor global
      panelGlobal = new JPanel();
      panelGlobal.setLayout(new BorderLayout());
      panelGlobal.add(panelCon, BorderLayout.NORTH);
      panelGlobal.add(panelES, BorderLayout.CENTER);
	  setContentPane(panelGlobal);
	  
      //manejo de eventos
      botonConectar.addActionListener(this);
      botonEnviar.addActionListener(this);
   }
   
   
   public void actionPerformed(ActionEvent e) {
   	 
   	 if (e.getActionCommand().equals("Conectar")) 
   	    conectar();
   	 else if (e.getActionCommand().equals("Enviar"))
   	    comunicar();
       	    
   }
   

   private void conectar() {
   	    int puerto;   	       	    
   	    
   	    //intentar conectar y comprobar errores
   	 	try {
   	 	   puerto = Integer.parseInt(textoPuerto.getText());
   	       conexion = new CliHTTP(textoHost.getText(), puerto);
   		   //la conexion se ha establecido
   	 	   JOptionPane.showMessageDialog(null, "Conexi�n establecida");	
   		   //habilitar controles GUI para poder enviar petici�n
   		   textoPeticion.setEnabled(true);
   		   botonEnviar.setEnabled(true); 
   		   //deshabilitar el boton de conectar
   		   botonConectar.setEnabled(false);
   		}
   		catch(NumberFormatException exc) {
   		   JOptionPane.showMessageDialog(null, "Error en el numero de puerto");	
   		}
   		catch (UnknownHostException exc2) {
   		   JOptionPane.showMessageDialog(null, "Host desconocido: " + textoHost.getText());	   			
   		} 
   		catch (IOException exc3) {
   		   JOptionPane.showMessageDialog(null, "error al hacer la conexion");	   			
   		}
   		
   }
   	
   private void comunicar() {
   	  //deshabilitar boton enviar, ya que el socket se cierra
   	  botonEnviar.setEnabled(false);
   	  //habilitar bot�n para conectar de nuevo
   	  botonConectar.setEnabled(true);
   	
      try {
      	 conexion.enviarPeticion(textoPeticion.getText());
      	 textoRespuesta.setText(conexion.recibirRespuesta());      	
      }
      catch (IOException e) {
      	 JOptionPane.showMessageDialog(null, "error de entrada/salida");
      }	
   	
   }
   
   public static void main(String args[]) {
   	  new ClienteHTTP();   	
   }	
	
}	
