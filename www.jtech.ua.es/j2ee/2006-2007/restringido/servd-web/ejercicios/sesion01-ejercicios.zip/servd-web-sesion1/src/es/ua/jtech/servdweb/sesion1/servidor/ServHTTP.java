package es.ua.jtech.servdweb.sesion1.servidor;

import java.net.*;
import java.io.*;

class ServHTTP {
	
   public static final int DEFAULT_PORT = 80;	
   private Socket conexion;
   private InputStream peticion;
   private OutputStream respuesta;
  
   
   public ServHTTP() throws IOException {
      this(DEFAULT_PORT);      
   }
   
   public ServHTTP(int puerto) throws UnknownHostException, IOException {
      ServerSocket serv;
      
      serv = new ServerSocket(puerto);      
   	  conexion = serv.accept();
   	  peticion = conexion.getInputStream();
   	  respuesta = conexion.getOutputStream();
   }
   
      
   public void enviarRespuesta(String res) throws IOException {
      PrintWriter salida = new PrintWriter(respuesta);
      salida.println(res);
      salida.flush();
      salida.close();
   }
   
   public String recibirPeticion() throws IOException {
   	  StringBuffer buf;
      BufferedReader entrada;
      String linLeida;
      int numBytes;
   	  
   	  numBytes = 0;
   	  entrada = new BufferedReader(new InputStreamReader(peticion));   	  
   	  buf=new StringBuffer();
   	  linLeida = entrada.readLine();
   	  while (!linLeida.equals("")) { 
   	  	 buf.append(linLeida + "\n");
   	  	 if (linLeida.indexOf("Content-Length")!=-1) {
   	  	 	numBytes = Integer.parseInt(linLeida.substring(16));
   	  	 }	
   	  	 
   	     linLeida = entrada.readLine();
   	  }
   	  buf.append(linLeida + "\n");   	  
   	  if (numBytes>0)
   	     for(int i=0;i<numBytes;i++)
   	        buf.append((char)entrada.read());
            
      return buf.toString();	 	   	  	   	  
   }		
}	