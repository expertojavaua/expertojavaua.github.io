DROP DATABASE IF EXISTS authority;
CREATE DATABASE authority;
USE authority;


#
# Table structure for table 'user_roles'
#

DROP TABLE IF EXISTS user_roles;
CREATE TABLE user_roles (
  login varchar(20) default '0',
  rol varchar(20) default '0'
) TYPE=MyISAM;



#
# Dumping data for table 'user_roles'
#

INSERT INTO user_roles (login, rol) VALUES("j2ee", "conversor");


#
# Table structure for table 'users'
#

DROP TABLE IF EXISTS users;
CREATE TABLE users (
  login varchar(20) NOT NULL default '0',
  password varchar(20) default NULL,
  PRIMARY KEY  (login),
  UNIQUE KEY login (login),
  KEY login_2 (login)
) TYPE=MyISAM;



#
# Dumping data for table 'users'
#

INSERT INTO users (login, password) VALUES("j2ee", "j2ee");
