/*
 * Created on 07-nov-2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.jtech.servdweb.sesion4;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.naming.*;
import java.sql.*;
import javax.sql.*;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class BDServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res) 
				throws ServletException, IOException {

		try
		{

			PrintStream out = new PrintStream(res.getOutputStream());

			out.println("<HTML>");
			out.println("<HEAD>");
			out.println("<TITLE>Resultado</TITLE>");
			out.println("</HEAD>");
			out.println("<BODY>");
			
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");
			DataSource ds = (DataSource)envCtx.lookup("jdbc/prueba");
	
			Connection conn = ds.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM datos");
			while (rs.next())
			{
				String nombre = rs.getString("nombre");
				String desc = rs.getString("descripcion");
				out.println("Nombre = '" + nombre + "', descripcion = '" + desc + "'<br/>");
			}
			conn.close();
		
			out.println("</BODY>");
			out.println("</HTML>");
			out.close();
		} catch (Exception ex) { ex.printStackTrace(); }
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
					throws ServletException, IOException  {
		this.doGet(req, res);
	}
}
