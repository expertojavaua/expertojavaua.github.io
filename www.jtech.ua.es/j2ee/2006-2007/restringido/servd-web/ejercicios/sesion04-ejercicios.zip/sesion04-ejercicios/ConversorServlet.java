/*
 * Created on 07-nov-2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.jtech.servdweb.sesion4;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ConversorServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res) 
				throws ServletException, IOException {

		boolean correcto = false;
		float euros = 0.0f;
		int ptas = 0;

		String snum = req.getParameter("numero");
		try {
			euros = Float.parseFloat(snum);
			ptas = (int)(euros * 166.386);
			correcto = true; 
		} catch(NumberFormatException e) {
			correcto = false;
		}

		PrintStream out = new PrintStream(res.getOutputStream());

		out.println("<HTML>");
		out.println("<HEAD>");
		out.println("<TITLE>Resultado</TITLE>");
		out.println("</HEAD>");
		out.println("<BODY>");

		if(correcto) {
			out.println("<H1>Resultado</H1>");
			out.println("<P>" + euros + " euros son <B>" + ptas + "</B> Ptas</P>");
			out.println("<A HREF=\"" + req.getContextPath() + "/index.htm\">Calcular otra cantidad</A>");
		} else {
			out.println("<H1>Error</H1>");
			out.println("<P>Debe introducir un numero</P>");			
			out.println("<A HREF=\"" + req.getContextPath() + "/index.htm\">Volver atras</A>");
		}

		out.println("</BODY>");
		out.println("</HTML>");
		out.close();
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
					throws ServletException, IOException  {
		this.doGet(req, res);
	}
}
