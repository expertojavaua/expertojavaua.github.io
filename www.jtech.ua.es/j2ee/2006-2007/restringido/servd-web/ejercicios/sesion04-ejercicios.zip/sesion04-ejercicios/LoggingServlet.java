/*
 * Created on 07-nov-2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.jtech.servdweb.sesion4;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.commons.logging.*;


/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class LoggingServlet extends HttpServlet {

	static Log logger = LogFactory.getLog(LoggingServlet.class);

	public void doGet(HttpServletRequest req, HttpServletResponse res) 
				throws ServletException, IOException {
		
		logger.info("El servlet de prueba de logging ha sido llamado");
		PrintStream out = new PrintStream(res.getOutputStream());

		out.println("<HTML>");
		out.println("<HEAD>");
		out.println("<TITLE>Resultado</TITLE>");
		out.println("</HEAD>");
		out.println("<BODY>");
		out.println("<H1>Servlet de logging de prueba</H1>");
		out.close();

		logger.warn("El servlet ha finalizado la peticion");
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
					throws ServletException, IOException  {
		this.doGet(req, res);
	}
}
