/*
 * Created on 07-nov-2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.jtech.servdweb.sesion4;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class PruebaServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res) 
				throws ServletException, IOException {
		
		PrintStream out = new PrintStream(res.getOutputStream());
		
		HttpSession ses = req.getSession(true);
		ses.setAttribute("miVariable", "prueba");

		out.println("<HTML>");
		out.println("<HEAD>");
		out.println("<TITLE>Resultado</TITLE>");
		out.println("</HEAD>");
		out.println("<BODY>");
		out.println("<H1>Servlet de logging de prueba</H1>");
		out.close();
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
					throws ServletException, IOException  {
		this.doGet(req, res);
	}
}
