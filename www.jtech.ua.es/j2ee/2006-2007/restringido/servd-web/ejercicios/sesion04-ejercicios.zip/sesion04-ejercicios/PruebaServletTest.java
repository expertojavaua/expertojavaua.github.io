package es.ua.jtech.servdweb.sesion4;

import org.apache.cactus.ServletTestCase;

public class PruebaServletTest extends ServletTestCase 
{
	public void testGet()
	{
		PruebaServlet ps = new PruebaServlet();
		try
		{
			ps.doGet(request, response);
			assertEquals((String)(session.getAttribute("miVariable")), "prueba");
		} catch (Exception ex) {
			assertTrue(1 == 0);
		}
	}
}
