package es.ua.jtech;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ComentariosDAO {
	private static String INSERT_SQL = "INSERT INTO comentarios VALUES(?,?,?)";
	private static String LIST_SQL = "SELECT * FROM comentarios ORDER BY fecha DESC";
	
	public List<Comentario> listarComentarios() {
		Connection con = null;
		List<Comentario> lista = new ArrayList<Comentario>();
		try {
			con = FuenteDatos.getInstance().getConnection();
			Statement s = con.createStatement();
			ResultSet rs = s.executeQuery(LIST_SQL);
			while (rs.next()) {
				Comentario c = new Comentario();
				c.setAutor(rs.getString("autor"));
				c.setTexto(rs.getString("texto"));
				c.setFecha(rs.getDate("fecha"));
				lista.add(c);
			}
			return lista;
		} catch (SQLException e1) {
			System.out.println(e1);
			return lista;
		}	
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				System.out.println(e);
			}			
		}
		
	}
	
	public void InsertarComentario(Comentario c) {
		Connection con = null;
		try {
			con = FuenteDatos.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement(INSERT_SQL);
			ps.setString(1, c.getAutor());
			ps.setString(2, c.getTexto());
			ps.setTimestamp(3, new java.sql.Timestamp(c.getFecha().getTime()));
			ps.executeUpdate();
		} catch (SQLException e1) {
			System.out.println(e1);
		}	
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				System.out.println(e);
			}			
		}
	}
}
