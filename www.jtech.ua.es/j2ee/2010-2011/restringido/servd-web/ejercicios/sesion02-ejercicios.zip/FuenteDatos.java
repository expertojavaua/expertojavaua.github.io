package es.ua.jtech;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class FuenteDatos {
	private static FuenteDatos me = null;
	private static DataSource ds = null;
	
	private FuenteDatos() {
		//TODO: instanciar la variable ds buscando el DataSource con JNDI
	}
	
	public static FuenteDatos getInstance() {
		if (me==null)
			me = new FuenteDatos();
		return me;
	}
	
	public Connection getConnection() throws SQLException {
		return ds.getConnection();
	}

}
