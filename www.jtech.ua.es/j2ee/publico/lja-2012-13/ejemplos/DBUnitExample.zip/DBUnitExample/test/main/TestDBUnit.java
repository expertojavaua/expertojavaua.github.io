package main;

import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;

import junit.framework.Assert;

import org.apache.commons.io.FileUtils;
import org.dbunit.Assertion;
import org.dbunit.IDatabaseTester;
import org.dbunit.JdbcDatabaseTester;
import org.dbunit.database.DatabaseConfig;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.database.QueryDataSet;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.dataset.xml.FlatXmlDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.dbunit.ext.mysql.MySqlDataTypeFactory;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestDBUnit {
    //Clase a probar
	private CustomerFactory _customerFactory;
    public static final String TABLE_CUSTOMER = "customer";

    private IDatabaseTester databaseTester;

	@Before
	public void setUp() throws Exception {
		// fijamos los datos para acceder a la BD
		databaseTester = new JdbcDatabaseTester("com.mysql.jdbc.Driver",
        		"jdbc:mysql://localhost/DBUNIT", "root", "");
        
		// inicializamos el dataset 
        FlatXmlDataSetBuilder builder = new FlatXmlDataSetBuilder();
        IDataSet dataSet = builder.build(this.getClass().getResourceAsStream("/customer-init.xml"));
                
        databaseTester.setDataSet(dataSet);

        // llamamos a la operacin por defecto setUpOperation
        databaseTester.onSetup();

        _customerFactory = CustomerFactory.getInstance();
	}
	
	 @Test
	 public void testInsert() throws Exception {
	        // insertamos un cliente en la BD
	        Customer customer = _customerFactory.create(1,"John", "Smith");
	        customer.setStreet("1 Main Street");
	        customer.setCity("Anycity");
	        //mtodo a probar
	        _customerFactory.insert(customer); 

	        // recuperamos la conexin con la BD
	        IDatabaseConnection connection = databaseTester.getConnection();
	        
	        // configuramos la conexin como de tipo mysal
	        DatabaseConfig dbconfig = connection.getConfig();
	        dbconfig.setProperty("http://www.dbunit.org/properties/datatypeFactory", new MySqlDataTypeFactory());
	        
	        //obtenemos los valores reales de la tabla a partir de la conexin
	        IDataSet databaseDataSet = connection.createDataSet();
	        ITable actualTable = databaseDataSet.getTable("customer");

	        // introducimos los valores esperados desde customer-expected.xml
	        /* Alternativa 1 */
	        FlatXmlDataSetBuilder builder = new FlatXmlDataSetBuilder();
	        IDataSet expectedDataSet = builder.build(this.getClass().getResourceAsStream("/customer-expected.xml"));	        
	        /* fin alternativa 1*/
	        
	        /* Alternativa 2
	        DataFileLoader loader = new FlatXmlDataFileLoader();
	        IDataSet expectedDataSet = loader.load("/customer-expected.xml");	        
	        fin alternativa 2*/
	        
	        ITable expectedTable = expectedDataSet.getTable("customer");

	        //comparamos la tabla esperada con la real
	        Assertion.assertEquals(expectedTable, actualTable);

	    }
	 
	 @Test
	 public void testDelete() throws Exception {
	        // borramos un cliente de la BD
	        Customer customer = _customerFactory.create(1,"John", "Smith");
	        customer.setStreet("1 Main Street");
	        customer.setCity("Anycity");
	        _customerFactory.insert(customer);
	        //mtodo a probar
	        _customerFactory.delete(customer); 

	        // recuperamos la conexin con la BD
	        IDatabaseConnection connection = databaseTester.getConnection();
	        
	        // configuramos la conexin como de tipo mysal
	        DatabaseConfig dbconfig = connection.getConfig();
	        dbconfig.setProperty("http://www.dbunit.org/properties/datatypeFactory", new MySqlDataTypeFactory());
	        
	        //obtenemos el nmero de elementos reales de la tabla customer
	        IDataSet databaseDataSet = connection.createDataSet();
	        int rowCount = databaseDataSet.getTable("customer").getRowCount();
	        
	        //el nmero de elementos tiene que ser cero
	        Assert.assertEquals(0, rowCount);
	    }

		//Ejecutamos una query y comparamos los resultados
		@Test
		public void testCompareQuery() throws Exception {
			
			Customer customer = _customerFactory.create(1,"John", "Smith");
	        customer.setStreet("1 Main Street");
	        customer.setCity("Anycity");
	        _customerFactory.insert(customer);
	        
	        customer = _customerFactory.create(2, "Marie", "Curie");
	        customer.setStreet("67 Second Street");
	        customer.setCity("Paris");
	        _customerFactory.insert(customer);
	        
	        IDatabaseConnection connection = databaseTester.getConnection();
	        
	        DatabaseConfig dbconfig = connection.getConfig();
	        dbconfig.setProperty("http://www.dbunit.org/properties/datatypeFactory", new MySqlDataTypeFactory());
	        
	        FlatXmlDataSetBuilder builder = new FlatXmlDataSetBuilder();
	        IDataSet expectedDataSet = builder.build(this.getClass().getResourceAsStream("/customer-expected.xml"));
	        
	        /* Podemos comparar datasets */		
	        QueryDataSet queryDataSet = new QueryDataSet(connection);
	        queryDataSet.addTable(TABLE_CUSTOMER, "SELECT * FROM customer WHERE lastname = 'Smith'");
	        Assertion.assertEquals(expectedDataSet, queryDataSet);
	        
	        /* Otra posibilidad: podemos comparar tablas */
	        ITable actualQueryData = connection.createQueryTable(TABLE_CUSTOMER, "SELECT * FROM customer WHERE lastname = 'Smith'");
	        ITable expectedTable = expectedDataSet.getTable("customer");
	        Assertion.assertEquals(expectedTable, actualQueryData);
			
		}
		
	    //Exportamos los datos de la BD a un fichero XML
		@Test
		public void testExportData() throws Exception {
			// insertamos los datos en la BD 
	        Customer customer = _customerFactory.create(1,"John", "Smith");
	        customer.setStreet("1 Main Street");
	        customer.setCity("Anycity");
	        _customerFactory.insert(customer);
	        
	        customer = _customerFactory.create(2, "Marie", "Curie");
	        customer.setStreet("67 Second Street");
	        customer.setCity("Paris");
	        _customerFactory.insert(customer);
	        
	        customer = _customerFactory.create(3, "Jacques", "Bertrand");
	        customer.setStreet("103 Third Street");
	        customer.setCity("London");
	        _customerFactory.insert(customer);
	        
	        customer = _customerFactory.create(4, "Mario", "Martinez");
	        customer.setStreet("5 Fourth Street");
	        customer.setCity("Spain");
	        _customerFactory.insert(customer);
	        
	        IDatabaseConnection connection = databaseTester.getConnection();
	        
	        DatabaseConfig dbconfig = connection.getConfig();
	        dbconfig.setProperty("http://www.dbunit.org/properties/datatypeFactory", new MySqlDataTypeFactory());
	   	
			IDataSet databaseDataSet = connection.createDataSet(new String[] {TABLE_CUSTOMER} );
			       		
			URL url = IDatabaseTester.class.getResource("/customer-input-data.xml");
			Assert.assertNotNull(url);
			File inputFile = new File(url.getPath());
			File outputFile = new File("customer-output-data.xml");
			FlatXmlDataSet.write(databaseDataSet, new FileOutputStream(outputFile));
			
			Assert.assertEquals(FileUtils.readFileToString(inputFile, "UTF8"), 
					           FileUtils.readFileToString(outputFile, "UTF8"));
		} 

		@After
		public void tearDown() throws Exception {
			databaseTester.onTearDown();
		}
}