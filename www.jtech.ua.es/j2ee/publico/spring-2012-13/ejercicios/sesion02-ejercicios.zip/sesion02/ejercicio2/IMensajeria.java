package es.ua.jtech.spring.negocio;

public interface IMensajeria {
    void enviarAvisoPedido(int idProducto, int unidades);
}
