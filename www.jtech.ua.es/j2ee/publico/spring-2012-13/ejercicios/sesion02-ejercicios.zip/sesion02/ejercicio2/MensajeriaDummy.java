/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package es.ua.jtech.spring.negocio;

import es.ua.jtech.spring.PedidosException;
import org.springframework.stereotype.Service;


@Service
public class MensajeriaDummy implements IMensajeria {
    private static boolean ok = true;

    public void enviarAvisoPedido(int idProducto, int unidades) throws PedidosException {
        if (MensajeriaDummy.ok)
            System.out.println(new java.util.Date() + ": aviso de pedido enviado..." +
                    unidades + " unidades del producto " + idProducto);
        else
            throw new PedidosException("No se puede enviar aviso");
    }

    public static boolean isOk() {
        return MensajeriaDummy.ok;
    }

    public static void setOk(boolean ok) {
        MensajeriaDummy.ok = ok;
    }

  
}
