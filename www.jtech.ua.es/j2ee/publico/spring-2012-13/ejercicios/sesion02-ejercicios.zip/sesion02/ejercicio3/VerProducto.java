package es.ua.jtech.spring.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import es.ua.jtech.spring.ProductoEntity;
import es.ua.jtech.spring.datos.IProductosDAO;

@WebServlet("/verProducto")
public class VerProducto extends HttpServlet {

	private static final long serialVersionUID = 780361686776789966L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		WebApplicationContext wac = WebApplicationContextUtils.getWebApplicationContext(this.getServletContext());
		IProductosDAO pdao = wac.getBean(IProductosDAO.class);
		
		ProductoEntity prod = pdao.buscarProducto(Integer.parseInt(request.getParameter("id")));
		
		PrintWriter pw = response.getWriter();
		pw.println("<html>");
		pw.println("<head><title>Datos del producto</title></head>");
		pw.println("<body>");
		pw.println("<body>");
		pw.println("<h1>Datos del producto</h1>");
		pw.println("<strong>Cod:</strong>");
		pw.println(prod.getId());
		pw.println("<br>");
		pw.println("<strong>Nombre:</strong>");
		pw.println(prod.getNombre());
		pw.println("<br>");
		pw.println("</body> </html>");
		pw.close();
	}
	
	
	

}
