package es.ua.jtech.amigosspring.modelo;

public enum Sexo {
	hombre,
	mujer,
	indiferente
}
